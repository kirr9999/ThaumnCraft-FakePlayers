package thaumcraft.codechicken.lib.util;

public interface Copyable<T> {
   T copy();
}
