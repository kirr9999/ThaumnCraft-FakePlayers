package thaumcraft.api.aspects;

import thaumcraft.api.aspects.IAspectContainer;

public interface IAspectSource extends IAspectContainer {
}
