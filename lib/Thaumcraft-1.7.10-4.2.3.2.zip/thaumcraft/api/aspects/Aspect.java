package thaumcraft.api.aspects;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedHashMap;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.StatCollector;
import org.apache.commons.lang3.text.WordUtils;

public class Aspect {
   String tag;
   Aspect[] components;
   int color;
   private String chatcolor;
   ResourceLocation image;
   int blend;
   public static LinkedHashMap<String, Aspect> aspects = new LinkedHashMap();
   public static final Aspect AIR = new Aspect("aer", 16777086, "e", 1);
   public static final Aspect EARTH = new Aspect("terra", 5685248, "2", 1);
   public static final Aspect FIRE = new Aspect("ignis", 16734721, "c", 1);
   public static final Aspect WATER = new Aspect("aqua", 3986684, "3", 1);
   public static final Aspect ORDER = new Aspect("ordo", 14013676, "7", 1);
   public static final Aspect ENTROPY = new Aspect("perditio", 4210752, "8", 771);
   public static final Aspect VOID;
   public static final Aspect LIGHT;
   public static final Aspect WEATHER;
   public static final Aspect MOTION;
   public static final Aspect COLD;
   public static final Aspect CRYSTAL;
   public static final Aspect LIFE;
   public static final Aspect POISON;
   public static final Aspect ENERGY;
   public static final Aspect EXCHANGE;
   public static final Aspect METAL;
   public static final Aspect DEATH;
   public static final Aspect FLIGHT;
   public static final Aspect DARKNESS;
   public static final Aspect SOUL;
   public static final Aspect HEAL;
   public static final Aspect TRAVEL;
   public static final Aspect ELDRITCH;
   public static final Aspect MAGIC;
   public static final Aspect AURA;
   public static final Aspect TAINT;
   public static final Aspect SLIME;
   public static final Aspect PLANT;
   public static final Aspect TREE;
   public static final Aspect BEAST;
   public static final Aspect FLESH;
   public static final Aspect UNDEAD;
   public static final Aspect MIND;
   public static final Aspect SENSES;
   public static final Aspect MAN;
   public static final Aspect CROP;
   public static final Aspect MINE;
   public static final Aspect TOOL;
   public static final Aspect HARVEST;
   public static final Aspect WEAPON;
   public static final Aspect ARMOR;
   public static final Aspect HUNGER;
   public static final Aspect GREED;
   public static final Aspect CRAFT;
   public static final Aspect CLOTH;
   public static final Aspect MECHANISM;
   public static final Aspect TRAP;

   public Aspect(String tag, int color, Aspect[] components, ResourceLocation image, int blend) {
      if(aspects.containsKey(tag)) {
         throw new IllegalArgumentException(tag + " already registered!");
      } else {
         this.tag = tag;
         this.components = components;
         this.color = color;
         this.image = image;
         this.blend = blend;
         aspects.put(tag, this);
      }
   }

   public Aspect(String tag, int color, Aspect[] components) {
      this(tag, color, components, new ResourceLocation("thaumcraft", "textures/aspects/" + tag.toLowerCase() + ".png"), 1);
   }

   public Aspect(String tag, int color, Aspect[] components, int blend) {
      this(tag, color, components, new ResourceLocation("thaumcraft", "textures/aspects/" + tag.toLowerCase() + ".png"), blend);
   }

   public Aspect(String tag, int color, String chatcolor, int blend) {
      this(tag, color, (Aspect[])null, blend);
      this.setChatcolor(chatcolor);
   }

   public int getColor() {
      return this.color;
   }

   public String getName() {
      return WordUtils.capitalizeFully(this.tag);
   }

   public String getLocalizedDescription() {
      return StatCollector.translateToLocal("tc.aspect." + this.tag);
   }

   public String getTag() {
      return this.tag;
   }

   public void setTag(String tag) {
      this.tag = tag;
   }

   public Aspect[] getComponents() {
      return this.components;
   }

   public void setComponents(Aspect[] components) {
      this.components = components;
   }

   public ResourceLocation getImage() {
      return this.image;
   }

   public static Aspect getAspect(String tag) {
      return (Aspect)aspects.get(tag);
   }

   public int getBlend() {
      return this.blend;
   }

   public void setBlend(int blend) {
      this.blend = blend;
   }

   public boolean isPrimal() {
      return this.getComponents() == null || this.getComponents().length != 2;
   }

   public static ArrayList<Aspect> getPrimalAspects() {
      ArrayList primals = new ArrayList();
      Collection pa = aspects.values();
      Iterator i$ = pa.iterator();

      while(i$.hasNext()) {
         Aspect aspect = (Aspect)i$.next();
         if(aspect.isPrimal()) {
            primals.add(aspect);
         }
      }

      return primals;
   }

   public static ArrayList<Aspect> getCompoundAspects() {
      ArrayList compounds = new ArrayList();
      Collection pa = aspects.values();
      Iterator i$ = pa.iterator();

      while(i$.hasNext()) {
         Aspect aspect = (Aspect)i$.next();
         if(!aspect.isPrimal()) {
            compounds.add(aspect);
         }
      }

      return compounds;
   }

   public String getChatcolor() {
      return this.chatcolor;
   }

   public void setChatcolor(String chatcolor) {
      this.chatcolor = chatcolor;
   }

   static {
      VOID = new Aspect("vacuos", 8947848, new Aspect[]{AIR, ENTROPY}, 771);
      LIGHT = new Aspect("lux", 16774755, new Aspect[]{AIR, FIRE});
      WEATHER = new Aspect("tempestas", 16777215, new Aspect[]{AIR, WATER});
      MOTION = new Aspect("motus", 13487348, new Aspect[]{AIR, ORDER});
      COLD = new Aspect("gelum", 14811135, new Aspect[]{FIRE, ENTROPY});
      CRYSTAL = new Aspect("vitreus", 8454143, new Aspect[]{EARTH, ORDER});
      LIFE = new Aspect("victus", 14548997, new Aspect[]{WATER, EARTH});
      POISON = new Aspect("venenum", 9039872, new Aspect[]{WATER, ENTROPY});
      ENERGY = new Aspect("potentia", 12648447, new Aspect[]{ORDER, FIRE});
      EXCHANGE = new Aspect("permutatio", 5735255, new Aspect[]{ENTROPY, ORDER});
      METAL = new Aspect("metallum", 11908557, new Aspect[]{EARTH, CRYSTAL});
      DEATH = new Aspect("mortuus", 8943496, new Aspect[]{LIFE, ENTROPY});
      FLIGHT = new Aspect("volatus", 15198167, new Aspect[]{AIR, MOTION});
      DARKNESS = new Aspect("tenebrae", 2236962, new Aspect[]{VOID, LIGHT});
      SOUL = new Aspect("spiritus", 15461371, new Aspect[]{LIFE, DEATH});
      HEAL = new Aspect("sano", 16723764, new Aspect[]{LIFE, ORDER});
      TRAVEL = new Aspect("iter", 14702683, new Aspect[]{MOTION, EARTH});
      ELDRITCH = new Aspect("alienis", 8409216, new Aspect[]{VOID, DARKNESS});
      MAGIC = new Aspect("praecantatio", 9896128, new Aspect[]{VOID, ENERGY});
      AURA = new Aspect("auram", 16761087, new Aspect[]{MAGIC, AIR});
      TAINT = new Aspect("vitium", 8388736, new Aspect[]{MAGIC, ENTROPY});
      SLIME = new Aspect("limus", 129024, new Aspect[]{LIFE, WATER});
      PLANT = new Aspect("herba", 109568, new Aspect[]{LIFE, EARTH});
      TREE = new Aspect("arbor", 8873265, new Aspect[]{AIR, PLANT});
      BEAST = new Aspect("bestia", 10445833, new Aspect[]{MOTION, LIFE});
      FLESH = new Aspect("corpus", 15615885, new Aspect[]{DEATH, BEAST});
      UNDEAD = new Aspect("exanimis", 3817472, new Aspect[]{MOTION, DEATH});
      MIND = new Aspect("cognitio", 16761523, new Aspect[]{FIRE, SOUL});
      SENSES = new Aspect("sensus", 1038847, new Aspect[]{AIR, SOUL});
      MAN = new Aspect("humanus", 16766912, new Aspect[]{BEAST, MIND});
      CROP = new Aspect("messis", 14791537, new Aspect[]{PLANT, MAN});
      MINE = new Aspect("perfodio", 14471896, new Aspect[]{MAN, EARTH});
      TOOL = new Aspect("instrumentum", 4210926, new Aspect[]{MAN, ORDER});
      HARVEST = new Aspect("meto", 15641986, new Aspect[]{CROP, TOOL});
      WEAPON = new Aspect("telum", 12603472, new Aspect[]{TOOL, FIRE});
      ARMOR = new Aspect("tutamen", '샀', new Aspect[]{TOOL, EARTH});
      HUNGER = new Aspect("fames", 10093317, new Aspect[]{LIFE, VOID});
      GREED = new Aspect("lucrum", 15121988, new Aspect[]{MAN, HUNGER});
      CRAFT = new Aspect("fabrico", 8428928, new Aspect[]{MAN, TOOL});
      CLOTH = new Aspect("pannus", 15395522, new Aspect[]{TOOL, BEAST});
      MECHANISM = new Aspect("machina", 8421536, new Aspect[]{MOTION, TOOL});
      TRAP = new Aspect("vinculum", 10125440, new Aspect[]{MOTION, ENTROPY});
   }
}
