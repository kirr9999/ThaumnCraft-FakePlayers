package thaumcraft.api;

public interface IScribeTools {
}
