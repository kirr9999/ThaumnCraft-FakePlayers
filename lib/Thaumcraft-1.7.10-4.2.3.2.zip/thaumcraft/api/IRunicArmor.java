package thaumcraft.api;

import net.minecraft.item.ItemStack;

public interface IRunicArmor {
   int getRunicCharge(ItemStack var1);
}
