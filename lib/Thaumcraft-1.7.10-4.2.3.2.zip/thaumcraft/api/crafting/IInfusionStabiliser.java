package thaumcraft.api.crafting;

import net.minecraft.world.World;

public interface IInfusionStabiliser {
   boolean canStabaliseInfusion(World var1, int var2, int var3, int var4);
}
