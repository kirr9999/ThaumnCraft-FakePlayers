package thaumcraft.api.crafting;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import net.minecraft.block.Block;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.IInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.world.World;
import net.minecraftforge.oredict.OreDictionary;
import thaumcraft.api.ThaumcraftApiHelper;
import thaumcraft.api.aspects.AspectList;
import thaumcraft.api.crafting.IArcaneRecipe;

public class ShapedArcaneRecipe implements IArcaneRecipe {
   private static final int MAX_CRAFT_GRID_WIDTH = 3;
   private static final int MAX_CRAFT_GRID_HEIGHT = 3;
   public ItemStack output;
   public Object[] input;
   public AspectList aspects;
   public String research;
   public int width;
   public int height;
   private boolean mirrored;

   public ShapedArcaneRecipe(String research, Block result, AspectList aspects, Object... recipe) {
      this(research, new ItemStack(result), aspects, recipe);
   }

   public ShapedArcaneRecipe(String research, Item result, AspectList aspects, Object... recipe) {
      this(research, new ItemStack(result), aspects, recipe);
   }

   public ShapedArcaneRecipe(String research, ItemStack result, AspectList aspects, Object... recipe) {
      this.output = null;
      this.input = null;
      this.aspects = null;
      this.width = 0;
      this.height = 0;
      this.mirrored = true;
      this.output = result.copy();
      this.research = research;
      this.aspects = aspects;
      String shape = "";
      int idx = 0;
      if(recipe[idx] instanceof Boolean) {
         this.mirrored = ((Boolean)recipe[idx]).booleanValue();
         if(recipe[idx + 1] instanceof Object[]) {
            recipe = (Object[])((Object[])recipe[idx + 1]);
         } else {
            idx = 1;
         }
      }

      int arr$;
      int len$;
      String var15;
      if(recipe[idx] instanceof String[]) {
         String[] itemMap = (String[])((String[])recipe[idx++]);
         String[] x = itemMap;
         arr$ = itemMap.length;

         for(len$ = 0; len$ < arr$; ++len$) {
            String i$ = x[len$];
            this.width = i$.length();
            shape = shape + i$;
         }

         this.height = itemMap.length;
      } else {
         while(recipe[idx] instanceof String) {
            var15 = (String)recipe[idx++];
            shape = shape + var15;
            this.width = var15.length();
            ++this.height;
         }
      }

      if(this.width * this.height != shape.length()) {
         var15 = "Invalid shaped ore recipe: ";
         Object[] var19 = recipe;
         arr$ = recipe.length;

         for(len$ = 0; len$ < arr$; ++len$) {
            Object var25 = var19[len$];
            var15 = var15 + var25 + ", ";
         }

         var15 = var15 + this.output;
         throw new RuntimeException(var15);
      } else {
         HashMap var16;
         for(var16 = new HashMap(); idx < recipe.length; idx += 2) {
            Character var17 = (Character)recipe[idx];
            Object var20 = recipe[idx + 1];
            if(var20 instanceof ItemStack) {
               var16.put(var17, ((ItemStack)var20).copy());
            } else if(var20 instanceof Item) {
               var16.put(var17, new ItemStack((Item)var20));
            } else if(var20 instanceof Block) {
               var16.put(var17, new ItemStack((Block)var20, 1, 32767));
            } else {
               if(!(var20 instanceof String)) {
                  String var22 = "Invalid shaped ore recipe: ";
                  Object[] var23 = recipe;
                  int chr = recipe.length;

                  for(int i$1 = 0; i$1 < chr; ++i$1) {
                     Object tmp = var23[i$1];
                     var22 = var22 + tmp + ", ";
                  }

                  var22 = var22 + this.output;
                  throw new RuntimeException(var22);
               }

               var16.put(var17, OreDictionary.getOres((String)var20));
            }
         }

         this.input = new Object[this.width * this.height];
         int var18 = 0;
         char[] var21 = shape.toCharArray();
         len$ = var21.length;

         for(int var24 = 0; var24 < len$; ++var24) {
            char var26 = var21[var24];
            this.input[var18++] = var16.get(Character.valueOf(var26));
         }

      }
   }

   public ItemStack getCraftingResult(IInventory var1) {
      return this.output.copy();
   }

   public int getRecipeSize() {
      return this.input.length;
   }

   public ItemStack getRecipeOutput() {
      return this.output;
   }

   public boolean matches(IInventory inv, World world, EntityPlayer player) {
      if(this.research.length() > 0 && !ThaumcraftApiHelper.isResearchComplete(player.getCommandSenderName(), this.research)) {
         return false;
      } else {
         for(int x = 0; x <= 3 - this.width; ++x) {
            for(int y = 0; y <= 3 - this.height; ++y) {
               if(this.checkMatch(inv, x, y, false)) {
                  return true;
               }

               if(this.mirrored && this.checkMatch(inv, x, y, true)) {
                  return true;
               }
            }
         }

         return false;
      }
   }

   private boolean checkMatch(IInventory inv, int startX, int startY, boolean mirror) {
      for(int x = 0; x < 3; ++x) {
         for(int y = 0; y < 3; ++y) {
            int subX = x - startX;
            int subY = y - startY;
            Object target = null;
            if(subX >= 0 && subY >= 0 && subX < this.width && subY < this.height) {
               if(mirror) {
                  target = this.input[this.width - subX - 1 + subY * this.width];
               } else {
                  target = this.input[subX + subY * this.width];
               }
            }

            ItemStack slot = ThaumcraftApiHelper.getStackInRowAndColumn(inv, x, y);
            if(target instanceof ItemStack) {
               if(!this.checkItemEquals((ItemStack)target, slot)) {
                  return false;
               }
            } else if(target instanceof ArrayList) {
               boolean matched = false;

               ItemStack item;
               for(Iterator i$ = ((ArrayList)target).iterator(); i$.hasNext(); matched = matched || this.checkItemEquals(item, slot)) {
                  item = (ItemStack)i$.next();
               }

               if(!matched) {
                  return false;
               }
            } else if(target == null && slot != null) {
               return false;
            }
         }
      }

      return true;
   }

   private boolean checkItemEquals(ItemStack target, ItemStack input) {
      return (input != null || target == null) && (input == null || target != null)?target.getItem() == input.getItem() && (!target.hasTagCompound() || ThaumcraftApiHelper.areItemStackTagsEqualForCrafting(input, target)) && (target.getItemDamage() == 32767 || target.getItemDamage() == input.getItemDamage()):false;
   }

   public ShapedArcaneRecipe setMirrored(boolean mirror) {
      this.mirrored = mirror;
      return this;
   }

   public Object[] getInput() {
      return this.input;
   }

   public AspectList getAspects() {
      return this.aspects;
   }

   public AspectList getAspects(IInventory inv) {
      return this.aspects;
   }

   public String getResearch() {
      return this.research;
   }
}
