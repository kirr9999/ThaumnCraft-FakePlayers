package thaumcraft.api;

import cpw.mods.fml.common.API;

// $FF: synthetic class
@API(
   owner = "Thaumcraft",
   apiVersion = "4.2.2.0",
   provides = "Thaumcraft|API"
)
interface package-info {
}
