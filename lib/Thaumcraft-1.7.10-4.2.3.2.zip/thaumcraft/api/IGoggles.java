package thaumcraft.api;

import net.minecraft.entity.EntityLivingBase;
import net.minecraft.item.ItemStack;

public interface IGoggles {
   boolean showIngamePopups(ItemStack var1, EntityLivingBase var2);
}
