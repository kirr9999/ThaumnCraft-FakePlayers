package thaumcraft.api;

public interface IRepairable {
}
