package thaumcraft.api.nodes;

import net.minecraft.entity.EntityLivingBase;
import net.minecraft.item.ItemStack;

public interface IRevealer {
   boolean showNodes(ItemStack var1, EntityLivingBase var2);
}
