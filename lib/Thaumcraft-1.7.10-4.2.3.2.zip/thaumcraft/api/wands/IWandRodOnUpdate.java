package thaumcraft.api.wands;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;

public interface IWandRodOnUpdate {
   void onUpdate(ItemStack var1, EntityPlayer var2);
}
