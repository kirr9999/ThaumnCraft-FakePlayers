package thaumcraft.client.renderers.models.gear;

import java.awt.Color;
import net.minecraft.block.Block;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityClientPlayerMP;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.client.renderer.ItemRenderer;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.client.renderer.RenderBlocks;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.renderer.texture.TextureMap;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.item.ItemStack;
import net.minecraft.util.IIcon;
import net.minecraft.util.MathHelper;
import org.lwjgl.opengl.GL11;
import thaumcraft.client.lib.UtilsFX;
import thaumcraft.client.renderers.block.BlockRenderer;
import thaumcraft.common.Thaumcraft;
import thaumcraft.common.items.wands.ItemWandCasting;

public class ModelWand extends ModelBase {
   ModelRenderer Rod;
   ModelRenderer Focus;
   ModelRenderer Cap;
   ModelRenderer CapBottom;
   private final RenderBlocks renderBlocks = new RenderBlocks();

   public ModelWand() {
      this.textureWidth = 32;
      this.textureHeight = 32;
      this.Cap = new ModelRenderer(this, 0, 0);
      this.Cap.addBox(-1.0F, -1.0F, -1.0F, 2, 2, 2);
      this.Cap.setRotationPoint(0.0F, 0.0F, 0.0F);
      this.Cap.setTextureSize(64, 32);
      this.Cap.mirror = true;
      this.setRotation(this.Cap, 0.0F, 0.0F, 0.0F);
      this.CapBottom = new ModelRenderer(this, 0, 0);
      this.CapBottom.addBox(-1.0F, -1.0F, -1.0F, 2, 2, 2);
      this.CapBottom.setRotationPoint(0.0F, 20.0F, 0.0F);
      this.CapBottom.setTextureSize(64, 32);
      this.CapBottom.mirror = true;
      this.setRotation(this.CapBottom, 0.0F, 0.0F, 0.0F);
      this.Rod = new ModelRenderer(this, 0, 8);
      this.Rod.addBox(-1.0F, -1.0F, -1.0F, 2, 18, 2);
      this.Rod.setRotationPoint(0.0F, 2.0F, 0.0F);
      this.Rod.setTextureSize(64, 32);
      this.Rod.mirror = true;
      this.setRotation(this.Rod, 0.0F, 0.0F, 0.0F);
      this.Focus = new ModelRenderer(this, 0, 0);
      this.Focus.addBox(-3.0F, -6.0F, -3.0F, 6, 6, 6);
      this.Focus.setRotationPoint(0.0F, 0.0F, 0.0F);
      this.Focus.setTextureSize(64, 32);
      this.Focus.mirror = true;
      this.setRotation(this.Focus, 0.0F, 0.0F, 0.0F);
   }

   public void render(ItemStack wandStack) {
      if(RenderManager.instance.renderEngine != null) {
         ItemWandCasting wand = (ItemWandCasting)wandStack.getItem();
         ItemStack focusStack = wand.getFocusItem(wandStack);
         EntityClientPlayerMP player = Minecraft.getMinecraft().thePlayer;
         boolean staff = wand.isStaff(wandStack);
         boolean runes = wand.hasRunes(wandStack);
         Minecraft.getMinecraft().renderEngine.bindTexture(wand.getRod(wandStack).getTexture());
         GL11.glPushMatrix();
         if(staff) {
            GL11.glTranslated(0.0D, 0.2D, 0.0D);
         }

         GL11.glPushMatrix();
         int j;
         int k;
         int l;
         if(wand.getRod(wandStack).isGlowing()) {
            j = (int)(200.0F + MathHelper.sin((float)player.ticksExisted) * 5.0F + 5.0F);
            k = j % 65536;
            l = j / 65536;
            OpenGlHelper.setLightmapTextureCoords(OpenGlHelper.lightmapTexUnit, (float)k / 1.0F, (float)l / 1.0F);
         }

         if(staff) {
            GL11.glTranslated(0.0D, -0.1D, 0.0D);
            GL11.glScaled(1.2D, 2.0D, 1.2D);
         }

         this.Rod.render(0.0625F);
         if(wand.getRod(wandStack).isGlowing()) {
            j = player.getBrightnessForRender(0.0F);
            k = j % 65536;
            l = j / 65536;
            OpenGlHelper.setLightmapTextureCoords(OpenGlHelper.lightmapTexUnit, (float)k / 1.0F, (float)l / 1.0F);
         }

         GL11.glPopMatrix();
         Minecraft.getMinecraft().renderEngine.bindTexture(wand.getCap(wandStack).getTexture());
         GL11.glPushMatrix();
         if(staff) {
            GL11.glScaled(1.3D, 1.1D, 1.3D);
         } else {
            GL11.glScaled(1.2D, 1.0D, 1.2D);
         }

         if(wand.isSceptre(wandStack)) {
            GL11.glPushMatrix();
            GL11.glScaled(1.3D, 1.3D, 1.3D);
            this.Cap.render(0.0625F);
            GL11.glPopMatrix();
            GL11.glPushMatrix();
            GL11.glTranslated(0.0D, 0.3D, 0.0D);
            GL11.glScaled(1.0D, 0.66D, 1.0D);
            this.Cap.render(0.0625F);
            GL11.glPopMatrix();
         } else {
            this.Cap.render(0.0625F);
         }

         if(staff) {
            GL11.glTranslated(0.0D, 0.225D, 0.0D);
            GL11.glPushMatrix();
            GL11.glScaled(1.0D, 0.66D, 1.0D);
            this.Cap.render(0.0625F);
            GL11.glPopMatrix();
            GL11.glTranslated(0.0D, 0.65D, 0.0D);
         }

         this.CapBottom.render(0.0625F);
         GL11.glPopMatrix();
         int var19;
         int var20;
         if(wand.getFocus(wandStack) != null) {
            if(wand.getFocus(wandStack).getOrnament(focusStack) != null) {
               GL11.glPushMatrix();
               GL11.glRotatef(180.0F, 1.0F, 0.0F, 0.0F);
               Tessellator var13 = Tessellator.instance;
               IIcon var15 = wand.getFocus(wandStack).getOrnament(focusStack);
               float var18 = var15.getMaxU();
               float rot = var15.getMinV();
               float a = var15.getMinU();
               float rune = var15.getMaxV();
               RenderManager.instance.renderEngine.bindTexture(TextureMap.locationItemsTexture);
               GL11.glPushMatrix();
               GL11.glTranslatef(-0.25F, -0.1F, 0.0275F);
               GL11.glScaled(0.5D, 0.5D, 0.5D);
               ItemRenderer.renderItemIn2D(var13, var18, rot, a, rune, var15.getIconWidth(), var15.getIconHeight(), 0.1F);
               GL11.glPopMatrix();
               GL11.glPushMatrix();
               GL11.glRotatef(90.0F, 0.0F, 1.0F, 0.0F);
               GL11.glTranslatef(-0.25F, -0.1F, 0.0275F);
               GL11.glScaled(0.5D, 0.5D, 0.5D);
               ItemRenderer.renderItemIn2D(var13, var18, rot, a, rune, var15.getIconWidth(), var15.getIconHeight(), 0.1F);
               GL11.glPopMatrix();
               GL11.glPopMatrix();
            }

            float var14 = 0.95F;
            if(wand.getFocus(wandStack).getFocusDepthLayerIcon(focusStack) != null) {
               GL11.glPushMatrix();
               if(staff) {
                  GL11.glTranslatef(0.0F, -0.15F, 0.0F);
                  GL11.glScaled(0.165D, 0.1765D, 0.165D);
               } else {
                  GL11.glTranslatef(0.0F, -0.09F, 0.0F);
                  GL11.glScaled(0.16D, 0.16D, 0.16D);
               }

               Minecraft.getMinecraft().renderEngine.bindTexture(TextureMap.locationItemsTexture);
               this.renderBlocks.setRenderBoundsFromBlock(Blocks.stone);
               BlockRenderer.drawFaces(this.renderBlocks, (Block)null, wand.getFocus(wandStack).getFocusDepthLayerIcon(focusStack), false);
               GL11.glPopMatrix();
               var14 = 0.6F;
            }

            if(Thaumcraft.isHalloween) {
               UtilsFX.bindTexture("textures/models/spec_h.png");
            } else {
               UtilsFX.bindTexture("textures/models/wand.png");
            }

            GL11.glPushMatrix();
            if(staff) {
               GL11.glTranslatef(0.0F, -0.0475F, 0.0F);
               GL11.glScaled(0.525D, 0.5525D, 0.525D);
            } else {
               GL11.glScaled(0.5D, 0.5D, 0.5D);
            }

            Color var17 = new Color(wand.getFocus(wandStack).getFocusColor(focusStack));
            GL11.glColor4f((float)var17.getRed() / 255.0F, (float)var17.getGreen() / 255.0F, (float)var17.getBlue() / 255.0F, var14);
            l = (int)(195.0F + MathHelper.sin((float)player.ticksExisted / 3.0F) * 10.0F + 10.0F);
            var19 = l % 65536;
            var20 = l / 65536;
            OpenGlHelper.setLightmapTextureCoords(OpenGlHelper.lightmapTexUnit, (float)var19 / 1.0F, (float)var20 / 1.0F);
            this.Focus.render(0.0625F);
            GL11.glPopMatrix();
         }

         short var16;
         if(wand.isSceptre(wandStack)) {
            GL11.glPushMatrix();
            var16 = 200;
            k = var16 % 65536;
            l = var16 / 65536;
            OpenGlHelper.setLightmapTextureCoords(OpenGlHelper.lightmapTexUnit, (float)k / 1.0F, (float)l / 1.0F);
            GL11.glBlendFunc(770, 1);

            for(var19 = 0; var19 < 10; ++var19) {
               GL11.glPushMatrix();
               GL11.glRotated((double)(36 * var19 + player.ticksExisted), 0.0D, 1.0D, 0.0D);
               this.drawRune(0.16D, -0.009999999776482582D, -0.125D, var19, player);
               GL11.glPopMatrix();
            }

            GL11.glBlendFunc(770, 771);
            GL11.glPopMatrix();
         }

         if(runes) {
            GL11.glPushMatrix();
            var16 = 200;
            k = var16 % 65536;
            l = var16 / 65536;
            OpenGlHelper.setLightmapTextureCoords(OpenGlHelper.lightmapTexUnit, (float)k / 1.0F, (float)l / 1.0F);
            GL11.glBlendFunc(770, 1);

            for(var19 = 0; var19 < 4; ++var19) {
               GL11.glRotated(90.0D, 0.0D, 1.0D, 0.0D);

               for(var20 = 0; var20 < 14; ++var20) {
                  int var21 = (var20 + var19 * 3) % 16;
                  this.drawRune(0.36D + (double)var20 * 0.14D, -0.009999999776482582D, -0.08D, var21, player);
               }
            }

            GL11.glBlendFunc(770, 771);
            GL11.glPopMatrix();
         }

         GL11.glPopMatrix();
      }
   }

   private void drawRune(double x, double y, double z, int rune, EntityPlayer player) {
      GL11.glPushMatrix();
      UtilsFX.bindTexture("textures/misc/script.png");
      float r = MathHelper.sin((float)(player.ticksExisted + rune * 5) / 5.0F) * 0.1F + 0.88F;
      float g = MathHelper.sin((float)(player.ticksExisted + rune * 5) / 7.0F) * 0.1F + 0.63F;
      float alpha = MathHelper.sin((float)(player.ticksExisted + rune * 5) / 10.0F) * 0.2F;
      GL11.glColor4f(r, g, 0.2F, alpha + 0.6F);
      GL11.glRotated(90.0D, 0.0D, 0.0D, 1.0D);
      GL11.glTranslated(x, y, z);
      Tessellator tessellator = Tessellator.instance;
      float var8 = 0.0625F * (float)rune;
      float var9 = var8 + 0.0625F;
      float var10 = 0.0F;
      float var11 = 1.0F;
      tessellator.startDrawingQuads();
      tessellator.setColorRGBA_F(r, g, 0.2F, alpha + 0.6F);
      tessellator.addVertexWithUV(-0.06D - (double)(alpha / 40.0F), 0.06D + (double)(alpha / 40.0F), 0.0D, (double)var9, (double)var11);
      tessellator.addVertexWithUV(0.06D + (double)(alpha / 40.0F), 0.06D + (double)(alpha / 40.0F), 0.0D, (double)var9, (double)var10);
      tessellator.addVertexWithUV(0.06D + (double)(alpha / 40.0F), -0.06D - (double)(alpha / 40.0F), 0.0D, (double)var8, (double)var10);
      tessellator.addVertexWithUV(-0.06D - (double)(alpha / 40.0F), -0.06D - (double)(alpha / 40.0F), 0.0D, (double)var8, (double)var11);
      tessellator.draw();
      GL11.glPopMatrix();
   }

   private void setRotation(ModelRenderer model, float x, float y, float z) {
      model.rotateAngleX = x;
      model.rotateAngleY = y;
      model.rotateAngleZ = z;
   }

   public void setRotationAngles(float f, float f1, float f2, float f3, float f4, float f5) {
      super.setRotationAngles(f, f1, f2, f3, f4, f5, (Entity)null);
   }
}
