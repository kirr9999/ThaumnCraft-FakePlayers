package thaumcraft.client.renderers.block;

import cpw.mods.fml.client.registry.ISimpleBlockRenderingHandler;
import net.minecraft.block.Block;
import net.minecraft.client.renderer.RenderBlocks;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.util.IIcon;
import net.minecraft.util.MathHelper;
import net.minecraft.world.IBlockAccess;
import net.minecraftforge.common.util.ForgeDirection;
import net.minecraftforge.fluids.BlockFluidBase;
import thaumcraft.common.blocks.BlockFluxGas;
import thaumcraft.common.config.ConfigBlocks;

public class BlockGasRenderer implements ISimpleBlockRenderingHandler {
   public static BlockGasRenderer instance = new BlockGasRenderer();
   static final float LIGHT_Y_NEG = 0.5F;
   static final float LIGHT_Y_POS = 1.0F;
   static final float LIGHT_XZ_NEG = 0.8F;
   static final float LIGHT_XZ_POS = 0.6F;
   static final double RENDER_OFFSET = 0.0010000000474974513D;

   public float getFluidHeightAverage(float[] flow) {
      float total = 0.0F;
      int count = 0;
      float end = 0.0F;

      for(int i = 0; i < flow.length; ++i) {
         if(flow[i] >= 0.875F && end != 1.0F) {
            end = flow[i];
         }

         if(flow[i] >= 0.0F) {
            total += flow[i];
            ++count;
         }
      }

      if(end == 0.0F) {
         end = total / (float)count;
      }

      return end;
   }

   public float getFluidHeightForRender(IBlockAccess world, int x, int y, int z, BlockFluxGas block) {
      if(world.getBlock(x, y, z) == block) {
         if(world.getBlock(x, y - block.getDensityDir(), z).getMaterial().isLiquid()) {
            return 1.0F;
         }

         if(world.getBlockMetadata(x, y, z) == block.getMaxRenderHeightMeta()) {
            return 0.875F;
         }
      }

      return !world.getBlock(x, y, z).getMaterial().isSolid() && world.getBlock(x, y - block.getDensityDir(), z) == block?1.0F:block.getQuantaPercentage(world, x, y, z) * 0.875F;
   }

   public void renderInventoryBlock(Block block, int metadata, int modelID, RenderBlocks renderer) {
   }

   public boolean renderWorldBlock(IBlockAccess world, int x, int y, int z, Block block, int modelId, RenderBlocks renderer) {
      if(!(block instanceof BlockFluxGas)) {
         return false;
      } else {
         Tessellator tessellator = Tessellator.instance;
         int color = block.colorMultiplier(world, x, y, z);
         float red = (float)(color >> 16 & 255) / 255.0F;
         float green = (float)(color >> 8 & 255) / 255.0F;
         float blue = (float)(color & 255) / 255.0F;
         BlockFluxGas theFluid = (BlockFluxGas)block;
         int bMeta = world.getBlockMetadata(x, y, z);
         if(!world.isSideSolid(x, y + theFluid.getDensityDir(), z, ForgeDirection.DOWN, false)) {
            tessellator.setBrightness(block.getMixedBrightnessForBlock(world, x, y, z));
            tessellator.setColorOpaque_F(1.0F * red, 1.0F * green, 1.0F * blue);
            block.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
            renderer.setRenderBoundsFromBlock(block);
            renderer.renderStandardBlock(block, x, y, z);
            renderer.clearOverrideBlockTexture();
            renderer.setRenderBoundsFromBlock(block);
            return true;
         } else {
            boolean renderTop = world.getBlock(x, y - theFluid.getDensityDir(), z) != theFluid;
            boolean renderBottom = block.shouldSideBeRendered(world, x, y + theFluid.getDensityDir(), z, 0) && world.getBlock(x, y + theFluid.getDensityDir(), z) != theFluid;
            boolean[] renderSides = new boolean[]{block.shouldSideBeRendered(world, x, y, z - 1, 2), block.shouldSideBeRendered(world, x, y, z + 1, 3), block.shouldSideBeRendered(world, x - 1, y, z, 4), block.shouldSideBeRendered(world, x + 1, y, z, 5)};
            if(!renderTop && !renderBottom && !renderSides[0] && !renderSides[1] && !renderSides[2] && !renderSides[3]) {
               return false;
            } else {
               boolean rendered = false;
               float flow11 = this.getFluidHeightForRender(world, x, y, z, theFluid);
               double heightNW;
               double heightSW;
               double heightSE;
               double heightNE;
               float x2;
               if(flow11 != 1.0F) {
                  float rises = this.getFluidHeightForRender(world, x - 1, y, z - 1, theFluid);
                  float side = this.getFluidHeightForRender(world, x - 1, y, z, theFluid);
                  x2 = this.getFluidHeightForRender(world, x - 1, y, z + 1, theFluid);
                  float z2 = this.getFluidHeightForRender(world, x, y, z - 1, theFluid);
                  float iconFlow = this.getFluidHeightForRender(world, x, y, z + 1, theFluid);
                  float ty1 = this.getFluidHeightForRender(world, x + 1, y, z - 1, theFluid);
                  float flow21 = this.getFluidHeightForRender(world, x + 1, y, z, theFluid);
                  float tx1 = this.getFluidHeightForRender(world, x + 1, y, z + 1, theFluid);
                  heightNW = (double)this.getFluidHeightAverage(new float[]{rises, side, z2, flow11});
                  heightSW = (double)this.getFluidHeightAverage(new float[]{side, x2, iconFlow, flow11});
                  heightSE = (double)this.getFluidHeightAverage(new float[]{iconFlow, flow21, tx1, flow11});
                  heightNE = (double)this.getFluidHeightAverage(new float[]{z2, ty1, flow21, flow11});
               } else {
                  heightNW = (double)flow11;
                  heightSW = (double)flow11;
                  heightSE = (double)flow11;
                  heightNE = (double)flow11;
               }

               boolean var51 = theFluid.getDensityDir() == 1;
               double ty2;
               double tx2;
               double tz1;
               double tz2;
               float v1Flow;
               float v2Flow;
               double var58;
               double var59;
               if(renderer.renderAllFaces || renderTop) {
                  rendered = true;
                  IIcon var52 = block.getIcon(1, bMeta);
                  x2 = (float)BlockFluidBase.getFlowDirection(world, x, y, z);
                  if(x2 > -999.0F) {
                     var52 = block.getIcon(2, bMeta);
                  }

                  heightNW -= 0.0010000000474974513D;
                  heightSW -= 0.0010000000474974513D;
                  heightSE -= 0.0010000000474974513D;
                  heightNE -= 0.0010000000474974513D;
                  double u1Flow;
                  double var55;
                  if(x2 < -999.0F) {
                     var58 = (double)var52.getInterpolatedU(0.0D);
                     tz1 = (double)var52.getInterpolatedV(0.0D);
                     var55 = var58;
                     tx2 = (double)var52.getInterpolatedV(16.0D);
                     ty2 = (double)var52.getInterpolatedU(16.0D);
                     u1Flow = tx2;
                     var59 = ty2;
                     tz2 = tz1;
                  } else {
                     v1Flow = MathHelper.sin(x2) * 0.25F;
                     v2Flow = MathHelper.cos(x2) * 0.25F;
                     var58 = (double)var52.getInterpolatedU((double)(8.0F + (-v2Flow - v1Flow) * 16.0F));
                     tz1 = (double)var52.getInterpolatedV((double)(8.0F + (-v2Flow + v1Flow) * 16.0F));
                     var55 = (double)var52.getInterpolatedU((double)(8.0F + (-v2Flow + v1Flow) * 16.0F));
                     tx2 = (double)var52.getInterpolatedV((double)(8.0F + (v2Flow + v1Flow) * 16.0F));
                     ty2 = (double)var52.getInterpolatedU((double)(8.0F + (v2Flow + v1Flow) * 16.0F));
                     u1Flow = (double)var52.getInterpolatedV((double)(8.0F + (v2Flow - v1Flow) * 16.0F));
                     var59 = (double)var52.getInterpolatedU((double)(8.0F + (v2Flow - v1Flow) * 16.0F));
                     tz2 = (double)var52.getInterpolatedV((double)(8.0F + (-v2Flow - v1Flow) * 16.0F));
                  }

                  tessellator.setBrightness(block.getMixedBrightnessForBlock(world, x, y, z));
                  tessellator.setColorOpaque_F(1.0F * red, 1.0F * green, 1.0F * blue);
                  if(!var51) {
                     tessellator.addVertexWithUV((double)(x + 0), (double)y + heightNW, (double)(z + 0), var58, tz1);
                     tessellator.addVertexWithUV((double)(x + 0), (double)y + heightSW, (double)(z + 1), var55, tx2);
                     tessellator.addVertexWithUV((double)(x + 1), (double)y + heightSE, (double)(z + 1), ty2, u1Flow);
                     tessellator.addVertexWithUV((double)(x + 1), (double)y + heightNE, (double)(z + 0), var59, tz2);
                  } else {
                     tessellator.addVertexWithUV((double)(x + 1), (double)(y + 1) - heightNE, (double)(z + 0), var59, tz2);
                     tessellator.addVertexWithUV((double)(x + 1), (double)(y + 1) - heightSE, (double)(z + 1), ty2, u1Flow);
                     tessellator.addVertexWithUV((double)(x + 0), (double)(y + 1) - heightSW, (double)(z + 1), var55, tx2);
                     tessellator.addVertexWithUV((double)(x + 0), (double)(y + 1) - heightNW, (double)(z + 0), var58, tz1);
                  }
               }

               if(renderer.renderAllFaces || renderBottom) {
                  rendered = true;
                  tessellator.setBrightness(block.getMixedBrightnessForBlock(world, x, y - 1, z));
                  if(!var51) {
                     tessellator.setColorOpaque_F(0.5F * red, 0.5F * green, 0.5F * blue);
                     renderer.renderFaceYNeg(block, (double)x, (double)y + 0.0010000000474974513D, (double)z, block.getIcon(0, bMeta));
                  } else {
                     tessellator.setColorOpaque_F(1.0F * red, 1.0F * green, 1.0F * blue);
                     renderer.renderFaceYPos(block, (double)x, (double)y + 0.0010000000474974513D, (double)z, block.getIcon(1, bMeta));
                  }
               }

               for(int var53 = 0; var53 < 4; ++var53) {
                  int var54 = x;
                  int var57 = z;
                  switch(var53) {
                  case 0:
                     var57 = z - 1;
                     break;
                  case 1:
                     var57 = z + 1;
                     break;
                  case 2:
                     var54 = x - 1;
                     break;
                  case 3:
                     var54 = x + 1;
                  }

                  IIcon var56 = block.getIcon(var53 + 2, bMeta);
                  if(renderer.renderAllFaces || renderSides[var53]) {
                     rendered = true;
                     if(var53 == 0) {
                        var58 = heightNW;
                        ty2 = heightNE;
                        var59 = (double)x;
                        tx2 = (double)(x + 1);
                        tz1 = (double)z + 0.0010000000474974513D;
                        tz2 = (double)z + 0.0010000000474974513D;
                     } else if(var53 == 1) {
                        var58 = heightSE;
                        ty2 = heightSW;
                        var59 = (double)(x + 1);
                        tx2 = (double)x;
                        tz1 = (double)(z + 1) - 0.0010000000474974513D;
                        tz2 = (double)(z + 1) - 0.0010000000474974513D;
                     } else if(var53 == 2) {
                        var58 = heightSW;
                        ty2 = heightNW;
                        var59 = (double)x + 0.0010000000474974513D;
                        tx2 = (double)x + 0.0010000000474974513D;
                        tz1 = (double)(z + 1);
                        tz2 = (double)z;
                     } else {
                        var58 = heightNE;
                        ty2 = heightSE;
                        var59 = (double)(x + 1) - 0.0010000000474974513D;
                        tx2 = (double)(x + 1) - 0.0010000000474974513D;
                        tz1 = (double)z;
                        tz2 = (double)(z + 1);
                     }

                     float var60 = var56.getInterpolatedU(0.0D);
                     float u2Flow = var56.getInterpolatedU(8.0D);
                     v1Flow = var56.getInterpolatedV((1.0D - var58) * 16.0D * 0.5D);
                     v2Flow = var56.getInterpolatedV((1.0D - ty2) * 16.0D * 0.5D);
                     float v3Flow = var56.getInterpolatedV(8.0D);
                     tessellator.setBrightness(block.getMixedBrightnessForBlock(world, var54, y, var57));
                     float sideLighting = 1.0F;
                     if(var53 < 2) {
                        sideLighting = 0.8F;
                     } else {
                        sideLighting = 0.6F;
                     }

                     tessellator.setColorOpaque_F(1.0F * sideLighting * red, 1.0F * sideLighting * green, 1.0F * sideLighting * blue);
                     if(!var51) {
                        tessellator.addVertexWithUV(var59, (double)y + var58, tz1, (double)var60, (double)v1Flow);
                        tessellator.addVertexWithUV(tx2, (double)y + ty2, tz2, (double)u2Flow, (double)v2Flow);
                        tessellator.addVertexWithUV(tx2, (double)(y + 0), tz2, (double)u2Flow, (double)v3Flow);
                        tessellator.addVertexWithUV(var59, (double)(y + 0), tz1, (double)var60, (double)v3Flow);
                     } else {
                        tessellator.addVertexWithUV(var59, (double)(y + 1 - 0), tz1, (double)var60, (double)v3Flow);
                        tessellator.addVertexWithUV(tx2, (double)(y + 1 - 0), tz2, (double)u2Flow, (double)v3Flow);
                        tessellator.addVertexWithUV(tx2, (double)(y + 1) - ty2, tz2, (double)u2Flow, (double)v2Flow);
                        tessellator.addVertexWithUV(var59, (double)(y + 1) - var58, tz1, (double)var60, (double)v1Flow);
                     }
                  }
               }

               renderer.renderMinY = 0.0D;
               renderer.renderMaxY = 1.0D;
               return rendered;
            }
         }
      }
   }

   public boolean shouldRender3DInInventory(int modelId) {
      return false;
   }

   public int getRenderId() {
      return ConfigBlocks.blockFluxGasRI;
   }
}
