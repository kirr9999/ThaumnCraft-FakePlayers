package thaumcraft.client.renderers.entity;

import java.util.Random;
import net.minecraft.client.entity.AbstractClientPlayer;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.entity.Render;
import net.minecraft.entity.Entity;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.opengl.GL11;
import thaumcraft.client.fx.ParticleEngine;
import thaumcraft.client.lib.UtilsFX;
import thaumcraft.common.blocks.BlockCustomOreItem;

public class RenderEldritchOrb extends Render {
   private Random random = new Random();

   public RenderEldritchOrb() {
      this.shadowSize = 0.0F;
   }

   public void renderEntityAt(Entity entity, double x, double y, double z, float fq, float pticks) {
      Tessellator tessellator = Tessellator.instance;
      this.random.setSeed(187L);
      GL11.glPushMatrix();
      RenderHelper.disableStandardItemLighting();
      float f1 = (float)entity.ticksExisted / 80.0F;
      float f3 = 0.9F;
      float f2 = 0.0F;
      Random random = new Random((long)entity.getEntityId());
      GL11.glTranslatef((float)x, (float)y, (float)z);
      GL11.glDisable(3553);
      GL11.glShadeModel(7425);
      GL11.glEnable(3042);
      GL11.glBlendFunc(770, 1);
      GL11.glDisable(3008);
      GL11.glEnable(2884);
      GL11.glDepthMask(false);
      GL11.glPushMatrix();

      float f5;
      float f6;
      for(int f4 = 0; f4 < 12; ++f4) {
         GL11.glRotatef(random.nextFloat() * 360.0F, 1.0F, 0.0F, 0.0F);
         GL11.glRotatef(random.nextFloat() * 360.0F, 0.0F, 1.0F, 0.0F);
         GL11.glRotatef(random.nextFloat() * 360.0F, 0.0F, 0.0F, 1.0F);
         GL11.glRotatef(random.nextFloat() * 360.0F, 1.0F, 0.0F, 0.0F);
         GL11.glRotatef(random.nextFloat() * 360.0F, 0.0F, 1.0F, 0.0F);
         GL11.glRotatef(random.nextFloat() * 360.0F + f1 * 360.0F, 0.0F, 0.0F, 1.0F);
         tessellator.startDrawing(6);
         f5 = random.nextFloat() * 20.0F + 5.0F + f2 * 10.0F;
         f6 = random.nextFloat() * 2.0F + 1.0F + f2 * 2.0F;
         f5 /= 30.0F / ((float)Math.min(entity.ticksExisted, 10) / 10.0F);
         f6 /= 30.0F / ((float)Math.min(entity.ticksExisted, 10) / 10.0F);
         tessellator.setColorRGBA_I(16777215, (int)(255.0F * (1.0F - f2)));
         tessellator.addVertex(0.0D, 0.0D, 0.0D);
         tessellator.setColorRGBA_I(BlockCustomOreItem.colors[5], 0);
         tessellator.addVertex(-0.866D * (double)f6, (double)f5, (double)(-0.5F * f6));
         tessellator.addVertex(0.866D * (double)f6, (double)f5, (double)(-0.5F * f6));
         tessellator.addVertex(0.0D, (double)f5, (double)(1.0F * f6));
         tessellator.addVertex(-0.866D * (double)f6, (double)f5, (double)(-0.5F * f6));
         tessellator.draw();
      }

      GL11.glPopMatrix();
      GL11.glDepthMask(true);
      GL11.glDisable(2884);
      GL11.glDisable(3042);
      GL11.glShadeModel(7424);
      GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
      GL11.glEnable(3553);
      GL11.glEnable(3008);
      RenderHelper.enableStandardItemLighting();
      GL11.glPopMatrix();
      GL11.glPushMatrix();
      GL11.glTranslated(x, y, z);
      GL11.glEnable(3042);
      GL11.glBlendFunc(770, 771);
      UtilsFX.bindTexture(ParticleEngine.particleTexture);
      f2 = (float)(entity.ticksExisted % 13) / 16.0F;
      f3 = f2 + 0.0624375F;
      float var20 = 0.1875F;
      f5 = var20 + 0.0624375F;
      f6 = 1.0F;
      float f7 = 0.5F;
      float f8 = 0.5F;
      GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
      GL11.glRotatef(180.0F - this.renderManager.playerViewY, 0.0F, 1.0F, 0.0F);
      GL11.glRotatef(-this.renderManager.playerViewX, 1.0F, 0.0F, 0.0F);
      GL11.glScalef(1.0F, 1.0F, 1.0F);
      tessellator.startDrawingQuads();
      tessellator.setNormal(0.0F, 1.0F, 0.0F);
      tessellator.addVertexWithUV((double)(0.0F - f7), (double)(0.0F - f8), 0.0D, (double)f2, (double)f5);
      tessellator.addVertexWithUV((double)(f6 - f7), (double)(0.0F - f8), 0.0D, (double)f3, (double)f5);
      tessellator.addVertexWithUV((double)(f6 - f7), (double)(1.0F - f8), 0.0D, (double)f3, (double)var20);
      tessellator.addVertexWithUV((double)(0.0F - f7), (double)(1.0F - f8), 0.0D, (double)f2, (double)var20);
      tessellator.draw();
      GL11.glDisable(3042);
      GL11.glDisable('耺');
      GL11.glPopMatrix();
   }

   public void doRender(Entity entity, double d, double d1, double d2, float f, float f1) {
      this.renderEntityAt(entity, d, d1, d2, f, f1);
   }

   protected ResourceLocation getEntityTexture(Entity entity) {
      return AbstractClientPlayer.locationStevePng;
   }
}
