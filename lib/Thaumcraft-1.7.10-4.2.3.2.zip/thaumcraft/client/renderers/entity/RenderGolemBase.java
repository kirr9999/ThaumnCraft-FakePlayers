package thaumcraft.client.renderers.entity;

import java.awt.Color;
import net.minecraft.block.Block;
import net.minecraft.client.entity.AbstractClientPlayer;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.renderer.ItemRenderer;
import net.minecraft.client.renderer.RenderBlocks;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.entity.RenderLiving;
import net.minecraft.client.renderer.texture.TextureMap;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.util.IIcon;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.client.IItemRenderer;
import net.minecraftforge.client.MinecraftForgeClient;
import net.minecraftforge.client.IItemRenderer.ItemRenderType;
import net.minecraftforge.client.IItemRenderer.ItemRendererHelper;
import net.minecraftforge.client.model.AdvancedModelLoader;
import net.minecraftforge.client.model.IModelCustom;
import net.minecraftforge.fluids.Fluid;
import net.minecraftforge.fluids.FluidRegistry;
import org.lwjgl.opengl.GL11;
import thaumcraft.client.lib.UtilsFX;
import thaumcraft.client.renderers.models.entities.ModelGolem;
import thaumcraft.client.renderers.models.entities.ModelGolemAccessories;
import thaumcraft.common.blocks.ItemJarFilled;
import thaumcraft.common.config.ConfigItems;
import thaumcraft.common.entities.golems.EntityGolemBase;
import thaumcraft.common.entities.golems.EnumGolemType;

public class RenderGolemBase extends RenderLiving {
   ModelBase damage;
   ModelBase accessories;
   private static final ResourceLocation BUCKET = new ResourceLocation("thaumcraft", "textures/models/bucket.obj");
   IIcon icon = null;
   private IModelCustom model;
   private static final ResourceLocation clay = new ResourceLocation("thaumcraft", "textures/models/golem_clay.png");
   private static final ResourceLocation stone = new ResourceLocation("thaumcraft", "textures/models/golem_stone.png");
   private static final ResourceLocation wood = new ResourceLocation("thaumcraft", "textures/models/golem_wood.png");
   private static final ResourceLocation tallow = new ResourceLocation("thaumcraft", "textures/models/golem_tallow.png");
   private static final ResourceLocation iron = new ResourceLocation("thaumcraft", "textures/models/golem_iron.png");
   private static final ResourceLocation straw = new ResourceLocation("thaumcraft", "textures/models/golem_straw.png");
   private static final ResourceLocation flesh = new ResourceLocation("thaumcraft", "textures/models/golem_flesh.png");
   private static final ResourceLocation thaumium = new ResourceLocation("thaumcraft", "textures/models/golem_thaumium.png");

   public RenderGolemBase(ModelBase par1ModelBase) {
      super(par1ModelBase, 0.25F);
      if(par1ModelBase instanceof ModelGolem) {
         ModelGolem mg = new ModelGolem(false);
         mg.pass = 2;
         this.damage = mg;
      }

      this.accessories = new ModelGolemAccessories(0.0F, 30.0F);
      this.model = AdvancedModelLoader.loadModel(BUCKET);
   }

   public void render(EntityGolemBase e, double par2, double par4, double par6, float par8, float par9) {
      super.doRender(e, par2, par4, par6, par8, par9);
   }

   protected int shouldRenderPass(EntityLivingBase entity, int pass, float par3) {
      if(pass == 0) {
         String deco = ((EntityGolemBase)entity).getGolemDecoration();
         float f1;
         if(((EntityGolemBase)entity).getCore() > -1) {
            GL11.glPushMatrix();
            GL11.glRotatef(180.0F, 1.0F, 0.0F, 0.0F);
            GL11.glTranslatef(0.0875F, -0.96F, 0.15F + (deco.contains("P")?0.03F:0.0F));
            GL11.glScaled(0.175D, 0.175D, 0.175D);
            GL11.glRotatef(180.0F, 0.0F, 1.0F, 0.0F);
            Tessellator upgrades = Tessellator.instance;
            IIcon shift = ConfigItems.itemGolemCore.getIconFromDamage(((EntityGolemBase)entity).getCore());
            float a = shift.getMaxU();
            float tessellator = shift.getMinV();
            float icon = shift.getMinU();
            f1 = shift.getMaxV();
            this.renderManager.renderEngine.bindTexture(TextureMap.locationItemsTexture);
            ItemRenderer.renderItemIn2D(upgrades, a, tessellator, icon, f1, shift.getIconWidth(), shift.getIconHeight(), 0.2F);
            GL11.glPopMatrix();
         }

         int var14 = ((EntityGolemBase)entity).upgrades.length;
         float var15 = 0.08F;
         GL11.glPushMatrix();
         GL11.glEnable(3042);
         GL11.glBlendFunc(770, 771);

         for(int var16 = 0; var16 < var14; ++var16) {
            GL11.glPushMatrix();
            GL11.glRotatef(180.0F, 1.0F, 0.0F, 0.0F);
            GL11.glTranslatef(-0.05F - var15 * (float)(var14 - 1) / 2.0F + var15 * (float)var16, -1.106F, 0.099F);
            GL11.glScaled(0.1D, 0.1D, 0.1D);
            Tessellator var17 = Tessellator.instance;
            IIcon var18 = ConfigItems.itemGolemUpgrade.getIconFromDamage(((EntityGolemBase)entity).getUpgrade(var16));
            f1 = var18.getMaxU();
            float f2 = var18.getMinV();
            float f3 = var18.getMinU();
            float f4 = var18.getMaxV();
            this.renderManager.renderEngine.bindTexture(TextureMap.locationItemsTexture);
            var17.startDrawingQuads();
            var17.setNormal(0.0F, 0.0F, 1.0F);
            var17.addVertexWithUV(0.0D, 0.0D, 0.0D, (double)f1, (double)f4);
            var17.addVertexWithUV(1.0D, 0.0D, 0.0D, (double)f3, (double)f4);
            var17.addVertexWithUV(1.0D, 1.0D, 0.0D, (double)f3, (double)f2);
            var17.addVertexWithUV(0.0D, 1.0D, 0.0D, (double)f1, (double)f2);
            var17.draw();
            GL11.glPopMatrix();
         }

         GL11.glDisable(3042);
         GL11.glPopMatrix();
      } else {
         if(pass == 1 && (((EntityGolemBase)entity).getGolemDecoration().length() > 0 || ((EntityGolemBase)entity).advanced)) {
            UtilsFX.bindTexture("textures/models/golem_decoration.png");
            this.setRenderPassModel(this.accessories);
            return 1;
         }

         if(pass == 2 && ((EntityGolemBase)entity).getHealthPercentage() < 1.0F) {
            UtilsFX.bindTexture("textures/models/golem_damage.png");
            this.setRenderPassModel(this.damage);
            GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F - ((EntityGolemBase)entity).getHealthPercentage());
            return 2;
         }
      }

      return -1;
   }

   protected void renderWithSway(EntityGolemBase e, float par2, float par3, float par4) {
      super.rotateCorpse(e, par2, par3, par4);
      if((double)e.limbSwingAmount >= 0.01D) {
         float var5 = 13.0F;
         float var6 = e.limbSwing - e.limbSwingAmount * (1.0F - par4) + 6.0F;
         float var7 = (Math.abs(var6 % var5 - var5 * 0.5F) - var5 * 0.25F) / (var5 * 0.25F);
         GL11.glRotatef(6.5F * var7, 0.0F, 0.0F, 1.0F);
      }

   }

   protected void renderCarriedItems(EntityGolemBase e, float par2) {
      ItemStack var3 = e.getCarriedForDisplay();
      float fill;
      float q;
      float b;
      float f8;
      if(e.getCore() == 11) {
         GL11.glPushMatrix();
         GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
         float fluid = 0.66F;
         this.renderManager.renderEngine.bindTexture(TextureMap.locationItemsTexture);
         GL11.glRotatef(5.0F + 90.0F * ((ModelGolem)this.mainModel).golemRightArm.rotateAngleX / 3.1415927F, 1.0F, 0.0F, 0.0F);
         GL11.glTranslatef(-0.26875F, 1.6F, -0.53F);
         GL11.glRotatef(90.0F, 0.0F, -1.0F, 0.0F);
         GL11.glRotatef(30.0F, 0.0F, 0.0F, -1.0F);
         GL11.glScalef(fluid, -fluid, fluid);
         IIcon max = Items.fishing_rod.func_94597_g();
         fill = max.getMinU();
         q = max.getMaxU();
         b = max.getMinV();
         f8 = max.getMaxV();
         Tessellator.instance.setColorRGBA_F(1.0F, 1.0F, 1.0F, 1.0F);
         ItemRenderer.renderItemIn2D(Tessellator.instance, q, b, fill, f8, max.getIconWidth(), max.getIconHeight(), 0.0625F);
         GL11.glScaled(1.0D, 1.0D, 1.0D);
         GL11.glPopMatrix();
      }

      if(var3 != null && e.deathTime == 0 && e.getCore() != 5) {
         GL11.glPushMatrix();
         GL11.glScaled(0.4D, 0.4D, 0.4D);
         IItemRenderer var18 = MinecraftForgeClient.getItemRenderer(var3, ItemRenderType.EQUIPPED);
         boolean var20 = var18 != null && var18.shouldUseRenderHelper(ItemRenderType.EQUIPPED, var3, ItemRendererHelper.BLOCK_3D);
         if(var3.getItem() instanceof ItemBlock && (var20 || RenderBlocks.renderItemIn3d(Block.getBlockFromItem(var3.getItem()).getRenderType()))) {
            GL11.glTranslatef(0.0F, 2.5F, -1.25F);
            GL11.glRotatef(180.0F, 1.0F, 0.0F, 0.0F);
         } else if(var3.getItem() instanceof ItemJarFilled) {
            GL11.glTranslatef(0.0F, 2.5F, -1.0F);
            if(e.getCore() == 6) {
               double var21 = 0.5D + (double)Math.min(64, e.getCarryLimit()) / 128.0D;
               GL11.glScaled(var21, var21, var21);
            }

            GL11.glTranslatef(-0.5F, 0.0F, -0.8F);
            GL11.glRotatef(180.0F, 1.0F, 0.0F, 0.0F);
            GL11.glRotatef(180.0F, 0.0F, 1.0F, 0.0F);
            GL11.glRotatef(335.0F, 0.0F, 0.0F, -1.0F);
            GL11.glRotatef(50.0F, 0.0F, -1.0F, 0.0F);
         } else {
            GL11.glTranslatef(-0.5F, 2.5F, -1.25F);
            GL11.glRotatef(180.0F, 1.0F, 0.0F, 0.0F);
            if(!var3.getItem().requiresMultipleRenderPasses()) {
               GL11.glRotatef(180.0F, 0.0F, 1.0F, 0.0F);
               GL11.glRotatef(335.0F, 0.0F, 0.0F, -1.0F);
               GL11.glRotatef(50.0F, 0.0F, -1.0F, 0.0F);
            }
         }

         if(var3.getItem().requiresMultipleRenderPasses()) {
            int renderPass = 0;

            do {
               IIcon icon = var3.getItem().getIcon(var3, renderPass);
               if(icon != null) {
                  Color color = new Color(var3.getItem().getColorFromItemStack(var3, renderPass));
                  GL11.glColor3ub((byte)color.getRed(), (byte)color.getGreen(), (byte)color.getBlue());
                  float f = icon.getMinU();
                  float f1 = icon.getMaxU();
                  float f2 = icon.getMinV();
                  float f3 = icon.getMaxV();
                  ItemRenderer.renderItemIn2D(Tessellator.instance, f1, f2, f, f3, icon.getIconWidth(), icon.getIconHeight(), 0.0625F);
                  GL11.glColor3f(1.0F, 1.0F, 1.0F);
               }

               ++renderPass;
            } while(renderPass < var3.getItem().getRenderPasses(var3.getItemDamage()));
         } else {
            int var22 = var3.getItem().getColorFromItemStack(var3, 0);
            b = (float)(var22 >> 16 & 255) / 255.0F;
            f8 = (float)(var22 >> 8 & 255) / 255.0F;
            q = (float)(var22 & 255) / 255.0F;
            GL11.glColor4f(b, f8, q, 1.0F);
            this.renderManager.itemRenderer.renderItem(e, var3, 0);
         }

         GL11.glScaled(1.0D, 1.0D, 1.0D);
         GL11.glPopMatrix();
      } else if(e.getCore() == 5) {
         GL11.glPushMatrix();
         GL11.glScaled(0.4D, 0.4D, 0.4D);
         GL11.glTranslatef(0.0F, 3.0F, -1.1F);
         GL11.glRotatef(90.0F, 1.0F, 0.0F, 0.0F);
         UtilsFX.bindTexture("textures/models/bucket.png");
         this.model.renderPart("Bucket");
         if(e.getCarriedForDisplay() != null) {
            Fluid var17 = FluidRegistry.getFluid(Item.getIdFromItem(e.getCarriedForDisplay().getItem()));
            float var19 = (float)Math.max(e.getCarriedForDisplay().getItemDamage(), e.getFluidCarryLimit());
            fill = (float)e.getCarriedForDisplay().getItemDamage() / var19;
            if(var17 != null) {
               GL11.glTranslatef(0.0F, 0.0F, 0.2F + 0.8F * fill);
               GL11.glScaled(0.8D, 0.8D, 0.8D);
               this.icon = var17.getIcon();
               int var23 = 15728640 | var17.getLuminosity() << 4;
               int var24 = Math.max(e.getBrightnessForRender(par2), var23);
               UtilsFX.renderQuadCenteredFromIcon(true, this.icon, 1.0F, 1.0F, 1.0F, 1.0F, var24, 771, 1.0F);
            }
         }

         GL11.glPopMatrix();
      }

   }

   protected void renderEquippedItems(EntityLivingBase par1EntityLiving, float par2) {
      this.renderCarriedItems((EntityGolemBase)par1EntityLiving, par2);
   }

   protected void rotateCorpse(EntityLivingBase par1EntityLiving, float par2, float par3, float par4) {
      this.renderWithSway((EntityGolemBase)par1EntityLiving, par2, par3, par4);
   }

   public void doRender(EntityLiving par1EntityLiving, double par2, double par4, double par6, float par8, float par9) {
      this.render((EntityGolemBase)par1EntityLiving, par2, par4, par6, par8, par9);
   }

   public void doRender(Entity par1Entity, double par2, double par4, double par6, float par8, float par9) {
      this.render((EntityGolemBase)par1Entity, par2, par4, par6, par8, par9);
   }

   protected ResourceLocation getEntityTexture(Entity entity) {
      switch(RenderGolemBase.SyntheticClass_1.$SwitchMap$thaumcraft$common$entities$golems$EnumGolemType[((EntityGolemBase)entity).getGolemType().ordinal()]) {
      case 1:
         return straw;
      case 2:
         return wood;
      case 3:
         return clay;
      case 4:
         return stone;
      case 5:
         return iron;
      case 6:
         return tallow;
      case 7:
         return flesh;
      case 8:
         return thaumium;
      default:
         return AbstractClientPlayer.locationStevePng;
      }
   }

   // $FF: synthetic class
   static class SyntheticClass_1 {
      // $FF: synthetic field
      static final int[] $SwitchMap$thaumcraft$common$entities$golems$EnumGolemType = new int[EnumGolemType.values().length];

      static {
         try {
            $SwitchMap$thaumcraft$common$entities$golems$EnumGolemType[EnumGolemType.STRAW.ordinal()] = 1;
         } catch (NoSuchFieldError var8) {
            ;
         }

         try {
            $SwitchMap$thaumcraft$common$entities$golems$EnumGolemType[EnumGolemType.WOOD.ordinal()] = 2;
         } catch (NoSuchFieldError var7) {
            ;
         }

         try {
            $SwitchMap$thaumcraft$common$entities$golems$EnumGolemType[EnumGolemType.CLAY.ordinal()] = 3;
         } catch (NoSuchFieldError var6) {
            ;
         }

         try {
            $SwitchMap$thaumcraft$common$entities$golems$EnumGolemType[EnumGolemType.STONE.ordinal()] = 4;
         } catch (NoSuchFieldError var5) {
            ;
         }

         try {
            $SwitchMap$thaumcraft$common$entities$golems$EnumGolemType[EnumGolemType.IRON.ordinal()] = 5;
         } catch (NoSuchFieldError var4) {
            ;
         }

         try {
            $SwitchMap$thaumcraft$common$entities$golems$EnumGolemType[EnumGolemType.TALLOW.ordinal()] = 6;
         } catch (NoSuchFieldError var3) {
            ;
         }

         try {
            $SwitchMap$thaumcraft$common$entities$golems$EnumGolemType[EnumGolemType.FLESH.ordinal()] = 7;
         } catch (NoSuchFieldError var2) {
            ;
         }

         try {
            $SwitchMap$thaumcraft$common$entities$golems$EnumGolemType[EnumGolemType.THAUMIUM.ordinal()] = 8;
         } catch (NoSuchFieldError var1) {
            ;
         }

      }
   }
}
