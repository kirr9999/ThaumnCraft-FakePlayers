package thaumcraft.client.renderers.tile;

import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.client.renderer.entity.RenderItem;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.renderer.tileentity.TileEntitySpecialRenderer;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.client.model.AdvancedModelLoader;
import net.minecraftforge.client.model.IModelCustom;
import org.lwjgl.opengl.GL11;
import thaumcraft.client.lib.UtilsFX;
import thaumcraft.common.config.Config;
import thaumcraft.common.config.ConfigItems;
import thaumcraft.common.tiles.TileEldritchAltar;

public class TileEldritchCapRenderer extends TileEntitySpecialRenderer {
   private IModelCustom model;
   private static final ResourceLocation CAP = new ResourceLocation("thaumcraft", "textures/models/obelisk_cap.obj");
   private String tex = "textures/models/obelisk_cap.png";
   private String tex2 = "textures/models/obelisk_cap_2.png";
   private ItemStack eye = null;
   EntityItem entityitem = null;

   public TileEldritchCapRenderer(String texture) {
      this.tex = texture;
      this.model = AdvancedModelLoader.loadModel(CAP);
   }

   public TileEldritchCapRenderer() {
      this.model = AdvancedModelLoader.loadModel(CAP);
   }

   public void renderTileEntityAt(TileEntity te, double x, double y, double z, float f) {
      String tempTex = this.tex;
      GL11.glPushMatrix();
      int a;
      if(te.getWorldObj() != null) {
         a = te.getBlockType().getMixedBrightnessForBlock(te.getWorldObj(), te.xCoord, te.yCoord, te.zCoord);
         int k = a % 65536;
         int l = a / 65536;
         OpenGlHelper.setLightmapTextureCoords(OpenGlHelper.lightmapTexUnit, (float)k / 1.0F, (float)l / 1.0F);
         if(te.getWorldObj().provider.dimensionId == Config.dimensionOuterId) {
            tempTex = this.tex2;
         }
      }

      GL11.glPushMatrix();
      UtilsFX.bindTexture(tempTex);
      GL11.glTranslated(x + 0.5D, y, z + 0.5D);
      GL11.glRotated(90.0D, -1.0D, 0.0D, 0.0D);
      this.model.renderPart("Cap");
      GL11.glPopMatrix();
      if(te.getWorldObj() != null && te instanceof TileEldritchAltar && ((TileEldritchAltar)te).getEyes() > 0) {
         GL11.glPushMatrix();
         GL11.glTranslatef((float)x + 0.5F, (float)y + 0.0F, (float)z + 0.5F);
         if(this.entityitem == null || this.eye == null) {
            this.eye = new ItemStack(ConfigItems.itemEldritchObject, 1, 0);
            this.entityitem = new EntityItem(te.getWorldObj(), 0.0D, 0.0D, 0.0D, this.eye);
            this.entityitem.hoverStart = 0.0F;
         }

         if(this.entityitem != null && this.eye != null) {
            for(a = 0; a < ((TileEldritchAltar)te).getEyes(); ++a) {
               GL11.glPushMatrix();
               GL11.glRotated((double)(a * 90), 0.0D, 1.0D, 0.0D);
               GL11.glTranslatef(0.46F, 0.2F, 0.0F);
               GL11.glRotated(90.0D, 0.0D, 1.0D, 0.0D);
               GL11.glRotated(18.0D, -1.0D, 0.0D, 0.0D);
               RenderItem.renderInFrame = true;
               RenderManager.instance.renderEntityWithPosYaw(this.entityitem, 0.0D, 0.0D, 0.0D, 0.0F, 0.0F);
               RenderItem.renderInFrame = false;
               GL11.glPopMatrix();
            }
         }

         GL11.glPopMatrix();
      }

      GL11.glPopMatrix();
   }
}
