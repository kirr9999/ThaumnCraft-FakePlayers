package thaumcraft.client.renderers.tile;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import net.minecraft.block.Block;
import net.minecraft.client.model.ModelChest;
import net.minecraft.client.renderer.tileentity.TileEntitySpecialRenderer;
import net.minecraft.tileentity.TileEntity;
import org.lwjgl.opengl.GL11;
import thaumcraft.client.lib.UtilsFX;
import thaumcraft.common.tiles.TileChestHungry;

@SideOnly(Side.CLIENT)
public class TileChestHungryRenderer extends TileEntitySpecialRenderer {
   private ModelChest chestModel = new ModelChest();

   public void renderTileEntityChestAt(TileChestHungry chest, double par2, double par4, double par6, float par8) {
      boolean var9 = false;
      int var91;
      if(!chest.hasWorldObj()) {
         var91 = 0;
      } else {
         Block var14 = chest.getBlockType();
         var91 = chest.getBlockMetadata();
      }

      ModelChest var141 = this.chestModel;
      UtilsFX.bindTexture("textures/models/chesthungry.png");
      GL11.glPushMatrix();
      GL11.glEnable('耺');
      GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
      GL11.glTranslatef((float)par2, (float)par4 + 1.0F, (float)par6 + 1.0F);
      GL11.glScalef(1.0F, -1.0F, -1.0F);
      GL11.glTranslatef(0.5F, 0.5F, 0.5F);
      short var11 = 0;
      if(var91 == 2) {
         var11 = 180;
      }

      if(var91 == 3) {
         var11 = 0;
      }

      if(var91 == 4) {
         var11 = 90;
      }

      if(var91 == 5) {
         var11 = -90;
      }

      GL11.glRotatef((float)var11, 0.0F, 1.0F, 0.0F);
      GL11.glTranslatef(-0.5F, -0.5F, -0.5F);
      float var12 = chest.prevLidAngle + (chest.lidAngle - chest.prevLidAngle) * par8;
      var12 = 1.0F - var12;
      var12 = 1.0F - var12 * var12 * var12;
      var141.chestLid.rotateAngleX = -(var12 * 3.1415927F / 2.0F);
      var141.renderAll();
      GL11.glDisable('耺');
      GL11.glPopMatrix();
      GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
   }

   public void renderTileEntityAt(TileEntity par1TileEntity, double par2, double par4, double par6, float par8) {
      this.renderTileEntityChestAt((TileChestHungry)par1TileEntity, par2, par4, par6, par8);
   }
}
