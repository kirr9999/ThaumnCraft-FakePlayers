package thaumcraft.client.renderers.tile;

import net.minecraft.client.Minecraft;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.MathHelper;
import net.minecraftforge.client.IItemRenderer;
import net.minecraftforge.client.IItemRenderer.ItemRenderType;
import net.minecraftforge.client.IItemRenderer.ItemRendererHelper;
import org.lwjgl.opengl.GL11;
import thaumcraft.api.aspects.Aspect;
import thaumcraft.api.aspects.AspectList;
import thaumcraft.api.nodes.INode;
import thaumcraft.api.nodes.NodeModifier;
import thaumcraft.api.nodes.NodeType;
import thaumcraft.client.lib.UtilsFX;
import thaumcraft.client.renderers.tile.TileNodeRenderer;
import thaumcraft.common.config.ConfigBlocks;
import thaumcraft.common.tiles.TileNode;

public class ItemNodeRenderer implements IItemRenderer {
   AspectList aspects;

   public ItemNodeRenderer() {
      this.aspects = (new AspectList()).add(Aspect.AIR, 40).add(Aspect.FIRE, 40).add(Aspect.EARTH, 40).add(Aspect.WATER, 40);
   }

   public boolean handleRenderType(ItemStack item, ItemRenderType type) {
      return item != null && item.getItem() == Item.getItemFromBlock(ConfigBlocks.blockAiry) && (item.getItemDamage() == 0 || item.getItemDamage() == 5);
   }

   public boolean shouldUseRenderHelper(ItemRenderType type, ItemStack item, ItemRendererHelper helper) {
      return helper != ItemRendererHelper.EQUIPPED_BLOCK;
   }

   public void renderItem(ItemRenderType type, ItemStack item, Object... data) {
      if(type == ItemRenderType.ENTITY) {
         GL11.glTranslatef(-0.5F, -0.25F, -0.5F);
      } else if(type == ItemRenderType.EQUIPPED && data[1] instanceof EntityPlayer) {
         GL11.glTranslatef(0.0F, 0.0F, -0.5F);
      }

      TileNode tjf = new TileNode();
      tjf.setAspects(this.aspects);
      tjf.setNodeType(NodeType.NORMAL);
      tjf.blockType = ConfigBlocks.blockAiry;
      tjf.blockMetadata = 0;
      GL11.glPushMatrix();
      GL11.glTranslated(0.5D, 0.5D, 0.5D);
      GL11.glScaled(2.0D, 2.0D, 2.0D);
      renderItemNode(tjf);
      GL11.glRotatef(90.0F, 0.0F, 1.0F, 0.0F);
      renderItemNode(tjf);
      GL11.glRotatef(90.0F, 1.0F, 0.0F, 0.0F);
      renderItemNode(tjf);
      GL11.glPopMatrix();
      GL11.glEnable('耺');
   }

   public static void renderItemNode(INode node) {
      if(node.getAspects().size() > 0) {
         EntityLivingBase viewer = Minecraft.getMinecraft().renderViewEntity;
         float alpha = 0.5F;
         if(node.getNodeModifier() != null) {
            switch(ItemNodeRenderer.SyntheticClass_1.$SwitchMap$thaumcraft$api$nodes$NodeModifier[node.getNodeModifier().ordinal()]) {
            case 1:
               alpha *= 1.5F;
               break;
            case 2:
               alpha *= 0.66F;
               break;
            case 3:
               alpha *= MathHelper.sin((float)viewer.ticksExisted / 3.0F) * 0.25F + 0.33F;
            }
         }

         GL11.glPushMatrix();
         GL11.glAlphaFunc(516, 0.003921569F);
         GL11.glDepthMask(false);
         GL11.glDisable(2884);
         long nt = System.nanoTime();
         long time = nt / 5000000L;
         float bscale = 0.25F;
         GL11.glPushMatrix();
         float rad = 6.2831855F;
         GL11.glColor4f(1.0F, 1.0F, 1.0F, alpha);
         UtilsFX.bindTexture(TileNodeRenderer.nodetex);
         byte frames = 32;
         int i = (int)((nt / 40000000L + 1L) % (long)frames);
         int count = 0;
         float scale = 0.0F;
         float average = 0.0F;
         Aspect[] strip = node.getAspects().getAspects();
         int len$ = strip.length;

         for(int i$ = 0; i$ < len$; ++i$) {
            Aspect aspect = strip[i$];
            if(aspect.getBlend() == 771) {
               alpha = (float)((double)alpha * 1.5D);
            }

            average += (float)node.getAspects().getAmount(aspect);
            GL11.glPushMatrix();
            GL11.glEnable(3042);
            GL11.glBlendFunc(770, aspect.getBlend());
            scale = MathHelper.sin((float)viewer.ticksExisted / (14.0F - (float)count)) * bscale + bscale * 2.0F;
            scale = 0.2F + scale * ((float)node.getAspects().getAmount(aspect) / 50.0F);
            UtilsFX.renderAnimatedQuadStrip(scale, alpha / (float)node.getAspects().size(), frames, 0, i, 0.0F, aspect.getColor());
            GL11.glDisable(3042);
            GL11.glPopMatrix();
            ++count;
            if(aspect.getBlend() == 771) {
               alpha = (float)((double)alpha / 1.5D);
            }
         }

         average /= (float)node.getAspects().size();
         GL11.glPushMatrix();
         GL11.glEnable(3042);
         i = (int)((nt / 40000000L + 1L) % (long)frames);
         scale = 0.1F + average / 150.0F;
         byte var18 = 1;
         switch(ItemNodeRenderer.SyntheticClass_1.$SwitchMap$thaumcraft$api$nodes$NodeType[node.getNodeType().ordinal()]) {
         case 1:
            GL11.glBlendFunc(770, 1);
            break;
         case 2:
            GL11.glBlendFunc(770, 1);
            var18 = 6;
            break;
         case 3:
            GL11.glBlendFunc(770, 771);
            var18 = 2;
            break;
         case 4:
            GL11.glBlendFunc(770, 771);
            var18 = 5;
            break;
         case 5:
            GL11.glBlendFunc(770, 1);
            var18 = 4;
            break;
         case 6:
            scale *= 0.75F;
            GL11.glBlendFunc(770, 1);
            var18 = 3;
         }

         GL11.glColor4f(1.0F, 0.0F, 1.0F, alpha);
         UtilsFX.renderAnimatedQuadStrip(scale, alpha, frames, var18, i, 0.0F, 16777215);
         GL11.glDisable(3042);
         GL11.glPopMatrix();
         GL11.glPopMatrix();
         GL11.glEnable(2884);
         GL11.glDepthMask(true);
         GL11.glAlphaFunc(516, 0.1F);
         GL11.glPopMatrix();
      }

   }

   // $FF: synthetic class
   static class SyntheticClass_1 {
      // $FF: synthetic field
      static final int[] $SwitchMap$thaumcraft$api$nodes$NodeModifier;
      // $FF: synthetic field
      static final int[] $SwitchMap$thaumcraft$api$nodes$NodeType = new int[NodeType.values().length];

      static {
         try {
            $SwitchMap$thaumcraft$api$nodes$NodeType[NodeType.NORMAL.ordinal()] = 1;
         } catch (NoSuchFieldError var9) {
            ;
         }

         try {
            $SwitchMap$thaumcraft$api$nodes$NodeType[NodeType.UNSTABLE.ordinal()] = 2;
         } catch (NoSuchFieldError var8) {
            ;
         }

         try {
            $SwitchMap$thaumcraft$api$nodes$NodeType[NodeType.DARK.ordinal()] = 3;
         } catch (NoSuchFieldError var7) {
            ;
         }

         try {
            $SwitchMap$thaumcraft$api$nodes$NodeType[NodeType.TAINTED.ordinal()] = 4;
         } catch (NoSuchFieldError var6) {
            ;
         }

         try {
            $SwitchMap$thaumcraft$api$nodes$NodeType[NodeType.PURE.ordinal()] = 5;
         } catch (NoSuchFieldError var5) {
            ;
         }

         try {
            $SwitchMap$thaumcraft$api$nodes$NodeType[NodeType.HUNGRY.ordinal()] = 6;
         } catch (NoSuchFieldError var4) {
            ;
         }

         $SwitchMap$thaumcraft$api$nodes$NodeModifier = new int[NodeModifier.values().length];

         try {
            $SwitchMap$thaumcraft$api$nodes$NodeModifier[NodeModifier.BRIGHT.ordinal()] = 1;
         } catch (NoSuchFieldError var3) {
            ;
         }

         try {
            $SwitchMap$thaumcraft$api$nodes$NodeModifier[NodeModifier.PALE.ordinal()] = 2;
         } catch (NoSuchFieldError var2) {
            ;
         }

         try {
            $SwitchMap$thaumcraft$api$nodes$NodeModifier[NodeModifier.FADING.ordinal()] = 3;
         } catch (NoSuchFieldError var1) {
            ;
         }

      }
   }
}
