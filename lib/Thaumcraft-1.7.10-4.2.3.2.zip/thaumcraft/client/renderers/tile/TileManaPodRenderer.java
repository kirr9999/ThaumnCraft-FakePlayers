package thaumcraft.client.renderers.tile;

import cpw.mods.fml.client.FMLClientHandler;
import java.awt.Color;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityClientPlayerMP;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.client.renderer.tileentity.TileEntitySpecialRenderer;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.MathHelper;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.opengl.GL11;
import thaumcraft.api.aspects.Aspect;
import thaumcraft.client.lib.UtilsFX;
import thaumcraft.client.renderers.models.ModelManaPod;
import thaumcraft.common.tiles.TileManaPod;

public class TileManaPodRenderer extends TileEntitySpecialRenderer {
   private ModelManaPod model = new ModelManaPod();
   private static final ResourceLocation pod0tex = new ResourceLocation("thaumcraft", "textures/models/manapod_0.png");
   private static final ResourceLocation pod2tex = new ResourceLocation("thaumcraft", "textures/models/manapod_2.png");

   public void renderEntityAt(TileManaPod pod, double x, double y, double z, float fq) {
      boolean meta = false;
      boolean bright = true;
      Aspect aspect = Aspect.PLANT;
      int meta1;
      if(pod.getWorldObj() == null) {
         meta1 = 5;
      } else {
         meta1 = pod.getBlockMetadata();
         if(pod.aspect != null) {
            aspect = pod.aspect;
         }

         int bright1 = pod.getBlockType().getMixedBrightnessForBlock(pod.getWorldObj(), pod.xCoord, pod.yCoord, pod.zCoord);
      }

      if(meta1 > 1) {
         float br = 0.14509805F;
         float bg = 0.6156863F;
         float bb = 0.45882353F;
         float fr = br;
         float fg = bg;
         float fb = bb;
         float scale;
         float bs;
         if(pod.aspect != null) {
            Color mc = new Color(aspect.getColor());
            float p = (float)mc.getRed() / 255.0F;
            scale = (float)mc.getGreen() / 255.0F;
            bs = (float)mc.getBlue() / 255.0F;
            if(meta1 == 7) {
               fr = p;
               fg = scale;
               fb = bs;
            } else {
               float j = (float)(meta1 - 2);
               fr = (br + p * j) / (j + 1.0F);
               fg = (bg + scale * j) / (j + 1.0F);
               fb = (bb + bs * j) / (j + 1.0F);
            }
         }

         Minecraft mc1 = FMLClientHandler.instance().getClient();
         GL11.glPushMatrix();
         GL11.glEnable(2977);
         GL11.glEnable(3042);
         GL11.glEnable('耺');
         GL11.glBlendFunc(770, 771);
         GL11.glTranslated(x + 0.5D, y + 0.75D, z + 0.5D);
         GL11.glRotatef(180.0F, 1.0F, 0.0F, 0.0F);
         if(meta1 > 2) {
            EntityClientPlayerMP p1 = Minecraft.getMinecraft().thePlayer;
            scale = MathHelper.sin((float)(p1.ticksExisted + pod.hashCode() % 100) / 8.0F) * 0.1F + 0.9F;
            GL11.glPushMatrix();
            bs = MathHelper.sin((float)(p1.ticksExisted + pod.hashCode() % 100) / 8.0F) * 0.3F + 0.7F;
            int j1 = meta1 * 10 + (int)(150.0F * scale);
            int k = j1 % 65536;
            int l = j1 / 65536;
            OpenGlHelper.setLightmapTextureCoords(OpenGlHelper.lightmapTexUnit, (float)k / 1.0F, (float)l / 1.0F);
            GL11.glTranslated(0.0D, 0.1D, 0.0D);
            GL11.glScaled(0.125D * (double)meta1 * (double)scale, 0.125D * (double)meta1 * (double)scale, 0.125D * (double)meta1 * (double)scale);
            UtilsFX.bindTexture(pod0tex);
            this.model.pod0.render(0.0625F);
            GL11.glPopMatrix();
         }

         GL11.glScaled(0.15D * (double)meta1, 0.15D * (double)meta1, 0.15D * (double)meta1);
         GL11.glColor4f(fr, fg, fb, 0.9F);
         UtilsFX.bindTexture(pod2tex);
         this.model.pod2.render(0.0625F);
         GL11.glDisable('耺');
         GL11.glDisable(3042);
         GL11.glPopMatrix();
      }

   }

   public void renderTileEntityAt(TileEntity tileentity, double d, double d1, double d2, float f) {
      this.renderEntityAt((TileManaPod)tileentity, d, d1, d2, f);
   }
}
