package thaumcraft.client.gui;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import java.awt.Color;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.util.EnumChatFormatting;
import net.minecraft.util.StatCollector;
import org.lwjgl.opengl.GL11;
import thaumcraft.api.aspects.Aspect;
import thaumcraft.api.aspects.AspectList;
import thaumcraft.api.wands.FocusUpgradeType;
import thaumcraft.api.wands.ItemFocusBasic;
import thaumcraft.client.fx.ParticleEngine;
import thaumcraft.client.lib.UtilsFX;
import thaumcraft.common.container.ContainerFocalManipulator;
import thaumcraft.common.lib.research.ResearchManager;
import thaumcraft.common.tiles.TileFocalManipulator;

@SideOnly(Side.CLIENT)
public class GuiFocalManipulator extends GuiContainer {
   private TileFocalManipulator table;
   private float xSize_lo;
   private float ySize_lo;
   int selected = -1;
   int rank = 0;
   long time;
   long nextSparkle = 0L;
   DecimalFormat myFormatter = new DecimalFormat("#######.#");
   ArrayList<FocusUpgradeType> possibleUpgrades = new ArrayList();
   ArrayList<FocusUpgradeType> upgrades = new ArrayList();
   AspectList aspects = new AspectList();
   HashMap<Long, GuiFocalManipulator.Sparkle> sparkles = new HashMap();

   public GuiFocalManipulator(InventoryPlayer par1InventoryPlayer, TileFocalManipulator table) {
      super(new ContainerFocalManipulator(par1InventoryPlayer, table));
      this.table = table;
      this.xSize = 192;
      this.ySize = 233;
      if(table.size > 0) {
         this.gatherInfo();
         this.selected = table.upgrade;
      }

   }

   public void drawScreen(int par1, int par2, float par3) {
      super.drawScreen(par1, par2, par3);
      this.xSize_lo = (float)par1;
      this.ySize_lo = (float)par2;
      int baseX = this.guiLeft;
      int baseY = this.guiTop;
      boolean mposx = false;
      boolean mposy = false;
      int a;
      FocusUpgradeType u;
      ArrayList list;
      int var11;
      int var12;
      if(this.rank > 0) {
         for(a = 0; a < this.possibleUpgrades.size(); ++a) {
            var11 = par1 - (baseX + 48 + a * 16);
            var12 = par2 - (baseY + 104);
            if(var11 >= 0 && var12 >= 0 && var11 < 16 && var12 < 16) {
               u = (FocusUpgradeType)this.possibleUpgrades.get(a);
               list = new ArrayList();
               list.add(EnumChatFormatting.DARK_PURPLE + "" + EnumChatFormatting.UNDERLINE + u.getLocalizedName());
               list.add(u.getLocalizedText());
               this.drawHoveringTextFixed(list, baseX + this.xSize - 36, baseY + 24, this.fontRendererObj, this.width - (baseX + this.xSize - 16));
            }
         }
      }

      if(this.selected >= 0) {
         var11 = par1 - (baseX + 48);
         var12 = par2 - (baseY + 48);
         ArrayList var13;
         if(var11 >= 0 && var12 >= 0 && var11 < 36 && var12 < 36) {
            var13 = new ArrayList();
            var13.add(StatCollector.translateToLocal("wandtable.text1"));
            this.drawHoveringText(var13, par1, par2, this.fontRendererObj);
         }

         var11 = par1 - (baseX + 108);
         var12 = par2 - (baseY + 58);
         if(var11 >= 0 && var12 >= 0 && var11 < 36 && var12 < 16) {
            var13 = new ArrayList();
            var13.add(StatCollector.translateToLocal("wandtable.text2"));
            this.drawHoveringText(var13, par1, par2, this.fontRendererObj);
         }

         if(this.table.size == 0 && this.rank * 8 <= this.mc.thePlayer.experienceLevel) {
            var11 = par1 - (baseX + 48);
            var12 = par2 - (baseY + 88);
            if(var11 >= 0 && var12 >= 0 && var11 < 96 && var12 < 8) {
               var13 = new ArrayList();
               var13.add(StatCollector.translateToLocal("wandtable.text3"));
               this.drawHoveringText(var13, par1, par2, this.fontRendererObj);
            }
         }
      }

      for(a = 0; a < this.upgrades.size(); ++a) {
         var11 = par1 - (baseX + 56 + a * 16);
         var12 = par2 - (baseY + 32);
         if(var11 >= 0 && var12 >= 0 && var11 < 16 && var12 < 16) {
            u = (FocusUpgradeType)this.upgrades.get(a);
            list = new ArrayList();
            list.add(EnumChatFormatting.DARK_PURPLE + "" + EnumChatFormatting.UNDERLINE + u.getLocalizedName());
            list.add(u.getLocalizedText());
            this.drawHoveringTextFixed(list, baseX + this.xSize - 36, baseY + 24, this.fontRendererObj, this.width - (baseX + this.xSize - 16));
         }
      }

   }

   protected void drawGuiContainerBackgroundLayer(float par1, int par2, int par3) {
      this.time = System.currentTimeMillis();
      GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
      UtilsFX.bindTexture("textures/gui/gui_wandtable.png");
      int k = (this.width - this.xSize) / 2;
      int l = (this.height - this.ySize) / 2;
      GL11.glEnable(3042);
      GL11.glBlendFunc(770, 771);
      this.drawTexturedModalRect(k, l, 0, 0, this.xSize, this.ySize);
      if(this.table.getStackInSlot(0) == null || this.table.rank < 0 || this.table.reset) {
         this.rank = 0;
         this.selected = -1;
         this.possibleUpgrades.clear();
         this.upgrades.clear();
         this.aspects = new AspectList();
         this.table.reset = false;
         this.table.rank = 0;
      }

      int a;
      FocusUpgradeType u;
      if(this.rank > 0) {
         for(a = 0; a < this.possibleUpgrades.size(); ++a) {
            u = (FocusUpgradeType)this.possibleUpgrades.get(a);
            if(this.selected == u.id) {
               this.drawTexturedModalRect(k + 48 + a * 16, l + 104, 200, 0, 16, 16);
            }
         }
      }

      if(this.rank > 0 && this.selected >= 0 && this.table.getStackInSlot(0) != null) {
         a = this.rank * 8;
         if(this.table.size == 0 && a <= this.mc.thePlayer.experienceLevel) {
            this.drawTexturedModalRect(k + 48, l + 88, 8, 240, 96, 8);
         }

         this.drawTexturedModalRect(k + 108, l + 59, 200, 16, 16, 16);
         int var19 = 0;
         int q;
         int i$;
         if(this.table.aspects.size() > 0) {
            Aspect[] al = this.table.aspects.getAspectsSorted();
            q = al.length;

            for(int arr$ = 0; arr$ < q; ++arr$) {
               Aspect len$ = al[arr$];
               if(len$ != null && this.table.aspects.getAmount(len$) != 0) {
                  i$ = (int)((float)this.table.aspects.getAmount(len$) / (float)this.table.size * 96.0F);
                  Color a1 = new Color(len$.getColor());
                  GL11.glColor4f((float)a1.getRed() / 255.0F, (float)a1.getGreen() / 255.0F, (float)a1.getBlue() / 255.0F, 0.9F);
                  this.drawTexturedModalRect(k + 48 + var19, l + 88, 112 + var19, 240, i$, 8);
                  var19 += i$;
                  if(this.table.getWorldObj().rand.nextInt(66) == 0) {
                     float s = (float)(48 + var19);
                     float y = 92.0F;
                     float xx = ((float)(46 + this.rank * 16) - s) / 9.0F;
                     float yy = (38.0F - y) / 9.0F;
                     this.sparkles.put(Long.valueOf(this.time), new GuiFocalManipulator.Sparkle(s, y, xx, yy, (float)a1.getRed() / 255.0F, (float)a1.getGreen() / 255.0F, (float)a1.getBlue() / 255.0F));
                  }
               }
            }
         }

         this.fontRendererObj.drawStringWithShadow("" + a, k + 125, l + 64, a > this.mc.thePlayer.experienceLevel?16151160:10092429);
         AspectList var20 = this.aspects;
         if(this.table.size > 0) {
            var20 = this.table.aspects;
         }

         q = 0;
         Aspect[] var21 = var20.getAspectsSorted();
         int var22 = var21.length;

         for(i$ = 0; i$ < var22; ++i$) {
            Aspect var23 = var21[i$];
            if(var23 != null) {
               GL11.glPushMatrix();
               GL11.glTranslated((double)(k + 49), (double)(l + 68) - (double)var20.size() * 2.5D, 0.0D);
               GL11.glScaled(0.5D, 0.5D, 0.5D);
               this.fontRendererObj.drawStringWithShadow(var23.getName(), 0, q * 10, var23.getColor());
               String var24 = this.myFormatter.format((double)((float)var20.getAmount(var23) / 100.0F));
               this.fontRendererObj.drawStringWithShadow(var24, 48, q * 10, var23.getColor());
               GL11.glPopMatrix();
               ++q;
            }
         }
      }

      if(this.rank > 0) {
         if(this.nextSparkle < this.time) {
            this.nextSparkle = this.time + (long)(this.table.size > 0?10:500) + (long)this.table.getWorldObj().rand.nextInt(200);
            this.sparkles.put(Long.valueOf(this.time), new GuiFocalManipulator.Sparkle((float)(42 + this.rank * 16 + this.table.getWorldObj().rand.nextInt(12)), (float)(34 + this.table.getWorldObj().rand.nextInt(12)), 0.0F, 0.0F, 0.5F + this.table.getWorldObj().rand.nextFloat() * 0.4F, 1.0F - this.table.getWorldObj().rand.nextFloat() * 0.4F, 1.0F - this.table.getWorldObj().rand.nextFloat() * 0.4F));
         }

         GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);

         for(a = 0; a < this.possibleUpgrades.size(); ++a) {
            u = (FocusUpgradeType)this.possibleUpgrades.get(a);
            GL11.glPushMatrix();
            GL11.glEnable(3042);
            GL11.glBlendFunc(770, 771);
            this.mc.renderEngine.bindTexture(u.icon);
            UtilsFX.drawTexturedQuadFull(k + 48 + a * 16, l + 104, (double)this.zLevel);
            GL11.glPopMatrix();
         }
      } else if(this.rank == 0 && this.table.getStackInSlot(0) != null) {
         try {
            this.gatherInfo();
         } catch (Exception var18) {
            ;
         }
      }

      GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);

      for(a = 0; a < this.upgrades.size(); ++a) {
         u = (FocusUpgradeType)this.upgrades.get(a);
         GL11.glPushMatrix();
         GL11.glEnable(3042);
         GL11.glBlendFunc(770, 771);
         this.mc.renderEngine.bindTexture(u.icon);
         UtilsFX.drawTexturedQuadFull(k + 56 + a * 16, l + 32, (double)this.zLevel);
         GL11.glPopMatrix();
      }

      GL11.glDisable(3042);
   }

   private void gatherInfo() {
      this.possibleUpgrades.clear();
      this.upgrades.clear();
      this.aspects = new AspectList();
      ItemFocusBasic focus = (ItemFocusBasic)this.table.getStackInSlot(0).getItem();
      short[] s = focus.getAppliedUpgrades(this.table.getStackInSlot(0));
      this.rank = 1;

      int fu;
      for(fu = 0; this.rank <= 5 && s[this.rank - 1] != -1; ++this.rank) {
         this.upgrades.add(FocusUpgradeType.types[s[this.rank - 1]]);
         ++fu;
      }

      if(fu == 5) {
         this.rank = -1;
      } else {
         FocusUpgradeType[] ut = focus.getPossibleUpgradesByRank(this.table.getStackInSlot(0), this.rank);
         if(ut == null) {
            return;
         }

         for(int a = 0; a < ut.length; ++a) {
            if(focus.canApplyUpgrade(this.table.getStackInSlot(0), Minecraft.getMinecraft().thePlayer, ut[a], this.rank)) {
               this.possibleUpgrades.add(ut[a]);
            }
         }
      }

      if(this.table.size > 0) {
         this.selected = this.table.upgrade;
      }

   }

   protected void drawGuiContainerForegroundLayer(int p_146979_1_, int p_146979_2_) {
      UtilsFX.bindTexture(ParticleEngine.particleTexture);
      Long[] keys = (Long[])this.sparkles.keySet().toArray(new Long[0]);
      Long[] arr$ = keys;
      int len$ = keys.length;

      for(int i$ = 0; i$ < len$; ++i$) {
         Long key = arr$[i$];
         GuiFocalManipulator.Sparkle s = (GuiFocalManipulator.Sparkle)this.sparkles.get(key);
         this.drawSparkle((double)s.x, (double)s.y, s.frame, s.r, s.g, s.b);
         if(s.nextframe < this.time) {
            ++s.frame;
            s.nextframe = this.time + 50L;
            s.x += s.mx;
            s.y += s.my;
         }

         if(s.frame == 9) {
            this.sparkles.remove(key);
         } else {
            this.sparkles.put(key, s);
         }
      }

   }

   protected void mouseClicked(int mx, int my, int par3) {
      super.mouseClicked(mx, my, par3);
      int gx = (this.width - this.xSize) / 2;
      int gy = (this.height - this.ySize) / 2;
      int var7 = mx - (gx + 48);
      int var8 = my - (gy + 88);
      if(this.table.size == 0 && this.selected >= 0 && this.rank * 8 <= this.mc.thePlayer.experienceLevel && var7 >= 0 && var8 >= 0 && var7 < 96 && var8 < 8) {
         this.mc.playerController.sendEnchantPacket(this.inventorySlots.windowId, this.selected);
         this.playButtonClick();
      } else {
         if(this.table.size == 0) {
            for(int a = 0; a < this.possibleUpgrades.size(); ++a) {
               FocusUpgradeType u = (FocusUpgradeType)this.possibleUpgrades.get(a);
               var7 = mx - (gx + 48 + a * 16);
               var8 = my - (gy + 104);
               if(var7 >= 0 && var8 >= 0 && var7 < 16 && var8 < 16) {
                  this.aspects = new AspectList();
                  if(this.selected == u.id) {
                     this.selected = -1;
                  } else {
                     this.selected = u.id;
                     int amt = 200;

                     for(int tal = 1; tal < this.rank; ++tal) {
                        amt *= 2;
                     }

                     AspectList var16 = new AspectList();
                     Aspect[] arr$ = FocusUpgradeType.types[this.selected].aspects.getAspects();
                     int len$ = arr$.length;

                     for(int i$ = 0; i$ < len$; ++i$) {
                        Aspect as = arr$[i$];
                        var16.add(as, amt);
                     }

                     this.aspects = ResearchManager.reduceToPrimals(var16);
                  }

                  this.playButtonClick();
                  return;
               }
            }
         }

      }
   }

   private void playButtonClick() {
      this.mc.renderViewEntity.worldObj.playSound(this.mc.renderViewEntity.posX, this.mc.renderViewEntity.posY, this.mc.renderViewEntity.posZ, "thaumcraft:cameraclack", 0.4F, 1.0F, false);
   }

   private void drawSparkle(double x, double y, int frame, float r, float g, float b) {
      GL11.glPushMatrix();
      GL11.glEnable(3042);
      GL11.glBlendFunc(770, 1);
      GL11.glColor4f(r, g, b, 0.9F);
      GL11.glTranslated(x, y, 200.0D);
      Tessellator tessellator = Tessellator.instance;
      float var8 = (float)frame / 16.0F;
      float var9 = var8 + 0.0624375F;
      float var10 = 0.4375F;
      float var11 = var10 + 0.0624375F;
      tessellator.startDrawingQuads();
      tessellator.setBrightness(220);
      tessellator.setColorRGBA_F(r, g, b, 0.9F);
      tessellator.addVertexWithUV(-4.0D, 4.0D, (double)this.zLevel, (double)var9, (double)var11);
      tessellator.addVertexWithUV(4.0D, 4.0D, (double)this.zLevel, (double)var9, (double)var10);
      tessellator.addVertexWithUV(4.0D, -4.0D, (double)this.zLevel, (double)var8, (double)var10);
      tessellator.addVertexWithUV(-4.0D, -4.0D, (double)this.zLevel, (double)var8, (double)var11);
      tessellator.draw();
      GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
      GL11.glDisable(3042);
      GL11.glPopMatrix();
   }

   protected void drawHoveringTextFixed(List listin, int x, int y, FontRenderer font, int width) {
      if(!listin.isEmpty()) {
         ArrayList list = new ArrayList();
         Iterator k = listin.iterator();

         String j2;
         while(k.hasNext()) {
            Object iterator = k.next();
            j2 = (String)iterator;
            j2 = this.trimStringNewline(j2);
            List k2 = font.listFormattedStringToWidth(j2, width);
            Iterator i1 = k2.iterator();

            while(i1.hasNext()) {
               String j1 = (String)i1.next();
               list.add(j1);
            }
         }

         GL11.glDisable('耺');
         RenderHelper.disableStandardItemLighting();
         GL11.glDisable(2896);
         GL11.glDisable(2929);
         int var17 = 0;
         Iterator var18 = list.iterator();

         int var20;
         while(var18.hasNext()) {
            j2 = (String)var18.next();
            var20 = font.getStringWidth(j2);
            if(var20 > var17) {
               var17 = var20;
            }
         }

         int var19 = x + 12;
         var20 = y - 12;
         int var21 = 8;
         if(list.size() > 1) {
            var21 += 2 + (list.size() - 1) * 10;
         }

         this.zLevel = 300.0F;
         itemRender.zLevel = 300.0F;
         int var22 = -267386864;
         this.drawGradientRect(var19 - 3, var20 - 4, var19 + var17 + 3, var20 - 3, var22, var22);
         this.drawGradientRect(var19 - 3, var20 + var21 + 3, var19 + var17 + 3, var20 + var21 + 4, var22, var22);
         this.drawGradientRect(var19 - 3, var20 - 3, var19 + var17 + 3, var20 + var21 + 3, var22, var22);
         this.drawGradientRect(var19 - 4, var20 - 3, var19 - 3, var20 + var21 + 3, var22, var22);
         this.drawGradientRect(var19 + var17 + 3, var20 - 3, var19 + var17 + 4, var20 + var21 + 3, var22, var22);
         int k1 = 1347420415;
         int l1 = (k1 & 16711422) >> 1 | k1 & -16777216;
         this.drawGradientRect(var19 - 3, var20 - 3 + 1, var19 - 3 + 1, var20 + var21 + 3 - 1, k1, l1);
         this.drawGradientRect(var19 + var17 + 2, var20 - 3 + 1, var19 + var17 + 3, var20 + var21 + 3 - 1, k1, l1);
         this.drawGradientRect(var19 - 3, var20 - 3, var19 + var17 + 3, var20 - 3 + 1, k1, k1);
         this.drawGradientRect(var19 - 3, var20 + var21 + 2, var19 + var17 + 3, var20 + var21 + 3, l1, l1);

         for(int i2 = 0; i2 < list.size(); ++i2) {
            String s1 = (String)list.get(i2);
            font.drawStringWithShadow(s1, var19, var20, -1);
            if(i2 == 0) {
               var20 += 2;
            }

            var20 += 10;
         }

         this.zLevel = 0.0F;
         itemRender.zLevel = 0.0F;
         GL11.glEnable(2896);
         GL11.glEnable(2929);
         RenderHelper.enableStandardItemLighting();
         GL11.glEnable('耺');
      }

   }

   private String trimStringNewline(String p_78273_1_) {
      while(p_78273_1_ != null && p_78273_1_.endsWith("\n")) {
         p_78273_1_ = p_78273_1_.substring(0, p_78273_1_.length() - 1);
      }

      return p_78273_1_;
   }

   private class Sparkle {
      float x;
      float y;
      float mx;
      float my;
      float r;
      float g;
      float b;
      long nextframe;
      int frame;

      public Sparkle(float x, float y, float mx, float my, float r, float g, float b) {
         this.x = x;
         this.y = y;
         this.mx = mx;
         this.my = my;
         this.frame = 0;
         this.r = r;
         this.g = g;
         this.b = b;
         this.nextframe = System.currentTimeMillis() + 50L;
      }
   }
}
