package thaumcraft.client.gui;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;
import net.minecraft.block.Block;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import thaumcraft.client.gui.GuiResearchRecipe;
import thaumcraft.common.lib.research.ScanManager;

public class MappingThread implements Runnable {
   Map<String, Integer> idMappings = null;

   public MappingThread(Map<String, Integer> idMappings) {
      this.idMappings = idMappings;
   }

   public void run() {
      Iterator i$ = this.idMappings.values().iterator();

      while(i$.hasNext()) {
         Integer id = (Integer)i$.next();

         try {
            Item e = Item.getItemById(id.intValue());
            if(e != null) {
               ArrayList var8 = new ArrayList();
               e.getSubItems(e, e.getCreativeTab(), var8);
               if(var8 != null && var8.size() > 0) {
                  Iterator var9 = var8.iterator();

                  while(var9.hasNext()) {
                     ItemStack stack = (ItemStack)var9.next();
                     GuiResearchRecipe.putToCache(ScanManager.generateItemHash(e, stack.getItemDamage()), stack.copy());
                  }
               }
            } else {
               Block b = Block.getBlockById(id.intValue());

               for(int a = 0; a < 16; ++a) {
                  GuiResearchRecipe.putToCache(ScanManager.generateItemHash(Item.getItemFromBlock(b), a), new ItemStack(b, 1, a));
               }
            }
         } catch (Exception var7) {
            ;
         }
      }

   }
}
