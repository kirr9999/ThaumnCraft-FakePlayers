package thaumcraft.client.gui;

import cpw.mods.fml.common.ObfuscationReflectionHelper;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.entity.RenderItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.crafting.FurnaceRecipes;
import net.minecraft.item.crafting.IRecipe;
import net.minecraft.item.crafting.ShapedRecipes;
import net.minecraft.item.crafting.ShapelessRecipes;
import net.minecraft.nbt.NBTBase;
import net.minecraft.util.MathHelper;
import net.minecraft.util.StatCollector;
import net.minecraftforge.oredict.ShapedOreRecipe;
import net.minecraftforge.oredict.ShapelessOreRecipe;
import org.lwjgl.opengl.GL11;
import thaumcraft.api.ThaumcraftApi;
import thaumcraft.api.ThaumcraftApiHelper;
import thaumcraft.api.aspects.Aspect;
import thaumcraft.api.aspects.AspectList;
import thaumcraft.api.crafting.CrucibleRecipe;
import thaumcraft.api.crafting.IArcaneRecipe;
import thaumcraft.api.crafting.InfusionEnchantmentRecipe;
import thaumcraft.api.crafting.InfusionRecipe;
import thaumcraft.api.crafting.ShapedArcaneRecipe;
import thaumcraft.api.crafting.ShapelessArcaneRecipe;
import thaumcraft.api.research.ResearchCategories;
import thaumcraft.api.research.ResearchItem;
import thaumcraft.api.research.ResearchPage;
import thaumcraft.client.gui.GuiResearchBrowser;
import thaumcraft.client.lib.TCFontRenderer;
import thaumcraft.client.lib.UtilsFX;
import thaumcraft.common.Thaumcraft;
import thaumcraft.common.lib.crafting.ThaumcraftCraftingManager;
import thaumcraft.common.lib.utils.InventoryUtils;

@SideOnly(Side.CLIENT)
public class GuiResearchRecipe extends GuiScreen {
   protected static RenderItem itemRenderer = new RenderItem();
   public static LinkedList<Object[]> history = new LinkedList();
   protected int paneWidth = 256;
   protected int paneHeight = 181;
   protected double guiMapX;
   protected double guiMapY;
   protected int mouseX = 0;
   protected int mouseY = 0;
   private GuiButton button;
   private ResearchItem research;
   private ResearchPage[] pages = null;
   private int page = 0;
   private int maxPages = 0;
   TCFontRenderer fr = null;
   HashMap<Aspect, ArrayList<ItemStack>> aspectItems = new HashMap();
   public static ConcurrentHashMap<Integer, ItemStack> cache = new ConcurrentHashMap();
   String tex1 = "textures/gui/gui_researchbook.png";
   String tex2 = "textures/gui/gui_researchbook_overlay.png";
   private Object[] tooltip = null;
   private long lastCycle = 0L;
   ArrayList<List> reference = new ArrayList();
   private int cycle = -1;

   public static synchronized void putToCache(int key, ItemStack stack) {
      cache.put(Integer.valueOf(key), stack);
   }

   public static synchronized ItemStack getFromCache(int key) {
      return (ItemStack)cache.get(Integer.valueOf(key));
   }

   public GuiResearchRecipe(ResearchItem research, int page, double x, double y) {
      this.research = research;
      this.guiMapX = x;
      this.guiMapY = y;
      this.mc = Minecraft.getMinecraft();
      this.pages = research.getPages();
      List p1 = Arrays.asList(this.pages);
      ArrayList p2 = new ArrayList();
      Iterator aspectsKnownSorted = p1.iterator();

      while(aspectsKnownSorted.hasNext()) {
         ResearchPage list = (ResearchPage)aspectsKnownSorted.next();
         if(list == null || list.type != ResearchPage.PageType.TEXT_CONCEALED || ThaumcraftApiHelper.isResearchComplete(this.mc.thePlayer.getCommandSenderName(), list.research)) {
            p2.add(list);
         }
      }

      this.pages = (ResearchPage[])p2.toArray(new ResearchPage[0]);
      if(research.key.equals("ASPECTS")) {
         AspectList var23 = Thaumcraft.proxy.getPlayerKnowledge().getAspectsDiscovered(Minecraft.getMinecraft().thePlayer.getCommandSenderName());
         List var24 = (List)Thaumcraft.proxy.getScannedObjects().get(Minecraft.getMinecraft().thePlayer.getCommandSenderName());
         if(var24 != null && var24.size() > 0) {
            Iterator tpl = var24.iterator();

            while(tpl.hasNext()) {
               String tal = (String)tpl.next();

               try {
                  String count = tal.substring(1);
                  ItemStack arr$ = getFromCache(Integer.parseInt(count));
                  if(arr$ != null) {
                     AspectList len$ = ThaumcraftCraftingManager.getObjectTags(arr$);
                     len$ = ThaumcraftCraftingManager.getBonusTags(arr$, len$);
                     if(len$ != null && len$.size() > 0) {
                        Aspect[] i$ = len$.getAspects();
                        int aspect = i$.length;

                        for(int i$1 = 0; i$1 < aspect; ++i$1) {
                           Aspect a = i$[i$1];
                           ArrayList items = (ArrayList)this.aspectItems.get(a);
                           if(items == null) {
                              items = new ArrayList();
                           }

                           ItemStack is2 = arr$.copy();
                           is2.stackSize = len$.getAmount(a);
                           items.add(is2);
                           this.aspectItems.put(a, items);
                        }
                     }
                  }
               } catch (NumberFormatException var22) {
                  ;
               }
            }
         }

         ArrayList var25 = new ArrayList();
         ResearchPage[] var26 = research.getPages();
         int var28 = var26.length;

         for(int var29 = 0; var29 < var28; ++var29) {
            ResearchPage var31 = var26[var29];
            var25.add(var31);
         }

         AspectList var27 = new AspectList();
         if(var23 != null) {
            var28 = 0;
            Aspect[] var30 = var23.getAspectsSorted();
            int var32 = var30.length;

            for(int var33 = 0; var33 < var32; ++var33) {
               Aspect var34 = var30[var33];
               if(var28 <= 4) {
                  ++var28;
                  var27.add(var34, var23.getAmount(var34));
               }

               if(var28 == 4) {
                  var28 = 0;
                  var25.add(new ResearchPage(var27.copy()));
                  var27 = new AspectList();
               }
            }

            if(var28 > 0) {
               var25.add(new ResearchPage(var27));
            }
         }

         this.pages = (ResearchPage[])var25.toArray(this.pages);
      }

      this.maxPages = this.pages.length;
      this.fr = new TCFontRenderer(this.mc.gameSettings, TCFontRenderer.FONT_NORMAL, this.mc.renderEngine, true);
      if(page % 2 == 1) {
         --page;
      }

      this.page = page;
   }

   public void initGui() {
   }

   protected void actionPerformed(GuiButton par1GuiButton) {
      super.actionPerformed(par1GuiButton);
   }

   protected void keyTyped(char par1, int par2) {
      if(par2 != this.mc.gameSettings.keyBindInventory.getKeyCode() && par2 != 1) {
         super.keyTyped(par1, par2);
      } else {
         history.clear();
         this.mc.displayGuiScreen(new GuiResearchBrowser(this.guiMapX, this.guiMapY));
      }

   }

   public void onGuiClosed() {
      super.onGuiClosed();
   }

   public void drawScreen(int par1, int par2, float par3) {
      this.drawDefaultBackground();
      this.genResearchBackground(par1, par2, par3);
      int sw = (this.width - this.paneWidth) / 2;
      int sh = (this.height - this.paneHeight) / 2;
      if(!history.isEmpty()) {
         int mx = par1 - (sw + 118);
         int my = par2 - (sh + 189);
         if(mx >= 0 && my >= 0 && mx < 20 && my < 12) {
            this.fontRendererObj.drawStringWithShadow(StatCollector.translateToLocal("recipe.return"), par1, par2, 16777215);
         }
      }

   }

   protected void genResearchBackground(int par1, int par2, float par3) {
      int sw = (this.width - this.paneWidth) / 2;
      int sh = (this.height - this.paneHeight) / 2;
      float var10 = ((float)this.width - (float)this.paneWidth * 1.3F) / 2.0F;
      float var11 = ((float)this.height - (float)this.paneHeight * 1.3F) / 2.0F;
      GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
      UtilsFX.bindTexture(this.tex1);
      GL11.glPushMatrix();
      GL11.glTranslatef(var10, var11, 0.0F);
      GL11.glEnable(3042);
      GL11.glScalef(1.3F, 1.3F, 1.0F);
      this.drawTexturedModalRect(0, 0, 0, 0, this.paneWidth, this.paneHeight);
      GL11.glPopMatrix();
      this.reference.clear();
      this.tooltip = null;
      int current = 0;

      for(int mx1 = 0; mx1 < this.pages.length; ++mx1) {
         if((current == this.page || current == this.page + 1) && current < this.maxPages) {
            this.drawPage(this.pages[mx1], current % 2, sw, sh, par1, par2);
         }

         ++current;
         if(current > this.page + 1) {
            break;
         }
      }

      if(this.tooltip != null) {
         UtilsFX.drawCustomTooltip(this, itemRenderer, this.fontRendererObj, (List)this.tooltip[0], ((Integer)this.tooltip[1]).intValue(), ((Integer)this.tooltip[2]).intValue(), ((Integer)this.tooltip[3]).intValue());
      }

      UtilsFX.bindTexture(this.tex1);
      int var10000 = par1 - (sw + 261);
      var10000 = par2 - (sh + 189);
      var10000 = par1 - (sw - 17);
      var10000 = par2 - (sh + 189);
      float bob = MathHelper.sin((float)this.mc.thePlayer.ticksExisted / 3.0F) * 0.2F + 0.1F;
      if(!history.isEmpty()) {
         GL11.glEnable(3042);
         this.drawTexturedModalRectScaled(sw + 118, sh + 189, 38, 202, 20, 12, bob);
      }

      if(this.page > 0) {
         GL11.glEnable(3042);
         this.drawTexturedModalRectScaled(sw - 16, sh + 190, 0, 184, 12, 8, bob);
      }

      if(this.page < this.maxPages - 2) {
         GL11.glEnable(3042);
         this.drawTexturedModalRectScaled(sw + 262, sh + 190, 12, 184, 12, 8, bob);
      }

   }

   public void drawCustomTooltip(GuiScreen gui, RenderItem itemRenderer, FontRenderer fr, List var4, int par2, int par3, int subTipColor) {
      this.tooltip = new Object[]{var4, Integer.valueOf(par2), Integer.valueOf(par3), Integer.valueOf(subTipColor)};
   }

   private void drawPage(ResearchPage pageParm, int side, int x, int y, int mx, int my) {
      GL11.glPushAttrib(1048575);
      if(this.lastCycle < System.currentTimeMillis()) {
         ++this.cycle;
         this.lastCycle = System.currentTimeMillis() + 1000L;
      }

      if(this.page == 0 && side == 0) {
         this.drawTexturedModalRect(x + 4, y - 13, 24, 184, 96, 4);
         this.drawTexturedModalRect(x + 4, y + 4, 24, 184, 96, 4);
         int offset = this.fontRendererObj.getStringWidth(this.research.getName());
         if(offset <= 130) {
            this.fontRendererObj.drawString(this.research.getName(), x + 52 - offset / 2, y - 6, 3158064);
         } else {
            float vv = 130.0F / (float)offset;
            GL11.glPushMatrix();
            GL11.glTranslatef((float)(x + 52) - (float)(offset / 2) * vv, (float)y - 6.0F * vv, 0.0F);
            GL11.glScalef(vv, vv, vv);
            this.fontRendererObj.drawString(this.research.getName(), 0, 0, 3158064);
            GL11.glPopMatrix();
         }

         y += 25;
      }

      GL11.glAlphaFunc(516, 0.003921569F);
      if(pageParm.type != ResearchPage.PageType.TEXT && pageParm.type != ResearchPage.PageType.TEXT_CONCEALED) {
         if(pageParm.type == ResearchPage.PageType.ASPECTS) {
            this.drawAspectPage(side, x - 8, y - 8, mx, my, pageParm.aspects);
         } else if(pageParm.type == ResearchPage.PageType.CRUCIBLE_CRAFTING) {
            this.drawCruciblePage(side, x - 4, y - 8, mx, my, pageParm);
         } else if(pageParm.type == ResearchPage.PageType.NORMAL_CRAFTING) {
            this.drawCraftingPage(side, x - 4, y - 8, mx, my, pageParm);
         } else if(pageParm.type == ResearchPage.PageType.ARCANE_CRAFTING) {
            this.drawArcaneCraftingPage(side, x - 4, y - 8, mx, my, pageParm);
         } else if(pageParm.type == ResearchPage.PageType.COMPOUND_CRAFTING) {
            this.drawCompoundCraftingPage(side, x - 4, y - 8, mx, my, pageParm);
         } else if(pageParm.type == ResearchPage.PageType.INFUSION_CRAFTING) {
            this.drawInfusionPage(side, x - 4, y - 8, mx, my, pageParm);
         } else if(pageParm.type == ResearchPage.PageType.INFUSION_ENCHANTMENT) {
            this.drawInfusionEnchantingPage(side, x - 4, y - 8, mx, my, pageParm);
         } else if(pageParm.type == ResearchPage.PageType.SMELTING) {
            this.drawSmeltingPage(side, x - 4, y - 8, mx, my, pageParm);
         }
      } else {
         this.drawTextPage(side, x, y - 10, pageParm.getTranslatedText());
      }

      GL11.glAlphaFunc(516, 0.1F);
      GL11.glPopAttrib();
   }

   private void drawCompoundCraftingPage(int side, int x, int y, int mx, int my, ResearchPage page) {
      List r = (List)page.recipe;
      if(r != null) {
         AspectList aspects = (AspectList)r.get(0);
         int dx = ((Integer)r.get(1)).intValue();
         int dy = ((Integer)r.get(2)).intValue();
         int dz = ((Integer)r.get(3)).intValue();
         int xoff = 64 - (dx * 16 + dz * 16) / 2;
         int yoff = -dy * 25;
         List items = (List)r.get(4);
         GL11.glPushMatrix();
         int start = side * 152;
         String text = StatCollector.translateToLocal("recipe.type.construct");
         int offset = this.fontRendererObj.getStringWidth(text);
         this.fontRendererObj.drawString(text, x + start + 56 - offset / 2, y, 5263440);
         int mposx = mx;
         int mposy = my;
         int j;
         int k;
         int px;
         int py;
         if(aspects != null && aspects.size() > 0) {
            int sz = 0;
            Aspect[] count = aspects.getAspectsSortedAmount();
            j = count.length;

            Aspect i;
            for(k = 0; k < j; ++k) {
               i = count[k];
               UtilsFX.drawTag(x + start + 14 + 18 * sz + (5 - aspects.size()) * 8, y + 182, i, (float)aspects.getAmount(i), 0, 0.0D, 771, 1.0F, false);
               ++sz;
            }

            sz = 0;
            count = aspects.getAspectsSortedAmount();
            j = count.length;

            for(k = 0; k < j; ++k) {
               i = count[k];
               px = x + start + 14 + 18 * sz + (5 - aspects.size()) * 8;
               py = y + 182;
               if(mposx >= px && mposy >= py && mposx < px + 16 && mposy < py + 16) {
                  this.drawCustomTooltip(this, itemRenderer, this.fontRendererObj, Arrays.asList(new String[]{i.getName(), i.getLocalizedDescription()}), mx, my - 8, 11);
               }

               ++sz;
            }
         }

         UtilsFX.bindTexture(this.tex2);
         GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
         RenderHelper.enableGUIStandardItemLighting();
         GL11.glDisable(2896);
         if(aspects != null && aspects.size() > 0) {
            GL11.glPushMatrix();
            GL11.glColor4f(1.0F, 1.0F, 1.0F, 0.4F);
            GL11.glEnable(3042);
            GL11.glTranslatef((float)(x + start), (float)(y + 174), 0.0F);
            GL11.glScalef(2.0F, 2.0F, 1.0F);
            this.drawTexturedModalRect(0, 0, 68, 76, 12, 12);
            GL11.glPopMatrix();
         }

         GL11.glPushMatrix();
         float var29 = 0.0F;
         if(dy > 3) {
            var29 = (float)(dy - 3) * 0.2F;
            GL11.glTranslatef((float)(x + start) + (float)xoff * (1.0F + var29), (float)(y + 108) + (float)yoff * (1.0F - var29), 0.0F);
            GL11.glScalef(1.0F - var29, 1.0F - var29, 1.0F - var29);
         } else {
            GL11.glTranslatef((float)(x + start + xoff), (float)(y + 108 + yoff), 0.0F);
         }

         GL11.glPushMatrix();
         GL11.glColor4f(1.0F, 1.0F, 1.0F, 0.5F);
         GL11.glEnable(3042);
         GL11.glTranslatef((float)(-8 - xoff), (float)(-119 + Math.max(3 - dx, 3 - dz) * 8 + dx * 4 + dz * 4 + dy * 50), 0.0F);
         GL11.glScalef(2.0F, 2.0F, 1.0F);
         this.drawTexturedModalRect(0, 0, 0, 72, 64, 44);
         GL11.glPopMatrix();
         int var30 = 0;

         int var31;
         for(j = 0; j < dy; ++j) {
            for(k = dz - 1; k >= 0; --k) {
               for(var31 = dx - 1; var31 >= 0; --var31) {
                  px = var31 * 16 + k * 16;
                  py = -var31 * 8 + k * 8 + j * 50;
                  GL11.glPushMatrix();
                  GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
                  RenderHelper.enableGUIStandardItemLighting();
                  GL11.glDisable(2896);
                  GL11.glEnable(2884);
                  GL11.glTranslatef(0.0F, 0.0F, (float)(60 - j * 10));
                  if(items.get(var30) != null) {
                     itemRenderer.renderItemAndEffectIntoGUI(this.mc.fontRenderer, this.mc.renderEngine, InventoryUtils.cycleItemStack(items.get(var30)), px, py);
                     itemRenderer.renderItemOverlayIntoGUI(this.mc.fontRenderer, this.mc.renderEngine, InventoryUtils.cycleItemStack(items.get(var30)).copy().splitStack(1), px, py);
                  }

                  GL11.glEnable(2896);
                  GL11.glPopMatrix();
                  ++var30;
               }
            }
         }

         GL11.glPopMatrix();
         var30 = 0;

         for(j = 0; j < dy; ++j) {
            for(k = dz - 1; k >= 0; --k) {
               for(var31 = dx - 1; var31 >= 0; --var31) {
                  px = (int)((float)(x + start) + (float)xoff * (1.0F + var29) + (float)(var31 * 16) * (1.0F - var29) + (float)(k * 16) * (1.0F - var29));
                  py = (int)((float)(y + 108) + (float)yoff * (1.0F - var29) - (float)(var31 * 8) * (1.0F - var29) + (float)(k * 8) * (1.0F - var29) + (float)(j * 50) * (1.0F - var29));
                  if(items.get(var30) != null && mposx >= px && mposy >= py && (float)mposx < (float)px + 16.0F * (1.0F - var29) && (float)mposy < (float)py + 16.0F * (1.0F - var29)) {
                     List addtext = InventoryUtils.cycleItemStack(items.get(var30)).getTooltip(this.mc.thePlayer, this.mc.gameSettings.advancedItemTooltips);
                     Object[] ref = this.findRecipeReference(InventoryUtils.cycleItemStack(items.get(var30)));
                     if(ref != null && !((String)ref[0]).equals(this.research.key)) {
                        addtext.add("§8§o" + StatCollector.translateToLocal("recipe.clickthrough"));
                        this.reference.add(Arrays.asList(new Serializable[]{Integer.valueOf(mx), Integer.valueOf(my), (String)ref[0], (Integer)ref[1]}));
                     }

                     this.drawCustomTooltip(this, itemRenderer, this.fontRendererObj, addtext, mx, my, 11);
                  }

                  ++var30;
               }
            }
         }

         GL11.glPopMatrix();
      }

   }

   private void drawAspectPage(int side, int x, int y, int mx, int my, AspectList aspects) {
      if(aspects != null && aspects.size() > 0) {
         GL11.glPushMatrix();
         int start = side * 152;
         int mposx = mx;
         int mposy = my;
         int count = 0;
         Aspect[] arr$ = aspects.getAspectsSorted();
         int len$ = arr$.length;

         int i$;
         Aspect aspect;
         int tx;
         int ty;
         int xcount;
         for(i$ = 0; i$ < len$; ++i$) {
            aspect = arr$[i$];
            if(aspect.getImage() != null) {
               GL11.glPushMatrix();
               tx = x + start;
               ty = y + count * 50;
               if(mposx >= tx && mposy >= ty && mposx < tx + 40 && mposy < ty + 40) {
                  UtilsFX.bindTexture("textures/aspects/_back.png");
                  GL11.glPushMatrix();
                  GL11.glEnable(3042);
                  GL11.glBlendFunc(770, 771);
                  GL11.glTranslated((double)(x + start - 5), (double)(y + count * 50 - 5), 0.0D);
                  GL11.glScaled(2.5D, 2.5D, 0.0D);
                  UtilsFX.drawTexturedQuadFull(0, 0, (double)this.zLevel);
                  GL11.glDisable(3042);
                  GL11.glPopMatrix();
               }

               GL11.glScalef(2.0F, 2.0F, 2.0F);
               UtilsFX.drawTag((x + start) / 2, (y + count * 50) / 2, aspect, (float)aspects.getAmount(aspect), 0, (double)this.zLevel);
               GL11.glPopMatrix();
               String items = aspect.getName();
               xcount = this.fr.getStringWidth(items) / 2;
               this.fr.drawString(items, x + start + 16 - xcount, y + 33 + count * 50, 5263440);
               if(aspect.getComponents() != null) {
                  GL11.glPushMatrix();
                  GL11.glScalef(1.5F, 1.5F, 1.5F);
                  UtilsFX.drawTag((int)((float)(x + start + 54) / 1.5F), (int)((float)(y + 4 + count * 50) / 1.5F), aspect.getComponents()[0], 0.0F, 0, (double)this.zLevel);
                  UtilsFX.drawTag((int)((float)(x + start + 96) / 1.5F), (int)((float)(y + 4 + count * 50) / 1.5F), aspect.getComponents()[1], 0.0F, 0, (double)this.zLevel);
                  GL11.glPopMatrix();
                  items = aspect.getComponents()[0].getName();
                  xcount = this.fr.getStringWidth(items) / 2;
                  this.fr.drawString("§o" + items, x + start + 16 - xcount + 50, y + 30 + count * 50, 5263440);
                  items = aspect.getComponents()[1].getName();
                  xcount = this.fr.getStringWidth(items) / 2;
                  this.fr.drawString("§o" + items, x + start + 16 - xcount + 92, y + 30 + count * 50, 5263440);
                  this.fontRendererObj.drawString("=", x + start + 7 + 32, y + 12 + count * 50, 10066329);
                  this.fontRendererObj.drawString("+", x + start + 4 + 79, y + 12 + count * 50, 10066329);
               } else {
                  this.fr.drawString(StatCollector.translateToLocal("tc.aspect.primal"), x + start + 48, y + 12 + count * 50, 4473924);
               }
            }

            ++count;
         }

         count = 0;
         arr$ = aspects.getAspectsSorted();
         len$ = arr$.length;

         for(i$ = 0; i$ < len$; ++i$) {
            aspect = arr$[i$];
            tx = x + start;
            ty = y + count * 50;
            if(mposx >= tx && mposy >= ty && mposx < tx + 40 && mposy < ty + 40) {
               ArrayList var22 = (ArrayList)this.aspectItems.get(aspect);
               if(var22 != null && var22.size() > 0) {
                  xcount = 0;
                  int ycount = 0;
                  Iterator i$1 = var22.iterator();

                  while(i$1.hasNext()) {
                     ItemStack item = (ItemStack)i$1.next();
                     GL11.glPushMatrix();
                     GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
                     RenderHelper.enableGUIStandardItemLighting();
                     GL11.glDisable(2896);
                     GL11.glEnable(2884);
                     itemRenderer.renderItemAndEffectIntoGUI(this.mc.fontRenderer, this.mc.renderEngine, InventoryUtils.cycleItemStack(item), mposx + 8 + xcount * 17, 17 * ycount + (mposy - (4 + var22.size() / 8 * 8)));
                     itemRenderer.renderItemOverlayIntoGUI(this.mc.fontRenderer, this.mc.renderEngine, InventoryUtils.cycleItemStack(item), mposx + 8 + xcount * 17, 17 * ycount + (mposy - (4 + var22.size() / 8 * 8)));
                     GL11.glEnable(2896);
                     GL11.glPopMatrix();
                     ++xcount;
                     if(xcount >= 8) {
                        xcount = 0;
                        ++ycount;
                     }
                  }
               }
            }

            ++count;
         }

         GL11.glPopMatrix();
      }

   }

   private void drawArcaneCraftingPage(int side, int x, int y, int mx, int my, ResearchPage pageParm) {
      Object recipe = null;
      Object tr = null;
      if(pageParm.recipe instanceof Object[]) {
         try {
            tr = ((Object[])((Object[])pageParm.recipe))[this.cycle];
         } catch (Exception var22) {
            this.cycle = 0;
            tr = ((Object[])((Object[])pageParm.recipe))[this.cycle];
         }
      } else {
         tr = pageParm.recipe;
      }

      if(tr instanceof ShapedArcaneRecipe) {
         recipe = (ShapedArcaneRecipe)tr;
      } else if(tr instanceof ShapelessArcaneRecipe) {
         recipe = (ShapelessArcaneRecipe)tr;
      }

      if(recipe != null) {
         GL11.glPushMatrix();
         int start = side * 152;
         UtilsFX.bindTexture(this.tex2);
         GL11.glPushMatrix();
         GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
         GL11.glEnable(3042);
         GL11.glTranslatef((float)(x + start), (float)y, 0.0F);
         GL11.glScalef(2.0F, 2.0F, 1.0F);
         this.drawTexturedModalRect(2, 27, 112, 15, 52, 52);
         this.drawTexturedModalRect(20, 7, 20, 3, 16, 16);
         GL11.glPopMatrix();
         GL11.glPushMatrix();
         GL11.glColor4f(1.0F, 1.0F, 1.0F, 0.4F);
         GL11.glEnable(3042);
         GL11.glTranslatef((float)(x + start), (float)(y + 164), 0.0F);
         GL11.glScalef(2.0F, 2.0F, 1.0F);
         this.drawTexturedModalRect(0, 0, 68, 76, 12, 12);
         GL11.glPopMatrix();
         int mposx = mx;
         int mposy = my;
         AspectList tags = ((IArcaneRecipe)recipe).getAspects();
         int items;
         int i;
         int ref;
         int j;
         if(tags != null && tags.size() > 0) {
            int text = 0;
            Aspect[] offset = tags.getAspectsSortedAmount();
            items = offset.length;

            Aspect addtext;
            for(i = 0; i < items; ++i) {
               addtext = offset[i];
               UtilsFX.drawTag(x + start + 14 + 18 * text + (5 - tags.size()) * 8, y + 172, addtext, (float)tags.getAmount(addtext), 0, 0.0D, 771, 1.0F);
               ++text;
            }

            text = 0;
            offset = tags.getAspectsSortedAmount();
            items = offset.length;

            for(i = 0; i < items; ++i) {
               addtext = offset[i];
               ref = x + start + 14 + 18 * text + (5 - tags.size()) * 8;
               j = y + 172;
               if(mposx >= ref && mposy >= j && mposx < ref + 16 && mposy < j + 16) {
                  this.drawCustomTooltip(this, itemRenderer, this.fontRendererObj, Arrays.asList(new String[]{addtext.getName(), addtext.getLocalizedDescription()}), mx, my - 8, 11);
               }

               ++text;
            }
         }

         GL11.glPushMatrix();
         GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
         GL11.glTranslated(0.0D, 0.0D, 100.0D);
         RenderHelper.enableGUIStandardItemLighting();
         GL11.glDisable(2896);
         GL11.glEnable(2884);
         itemRenderer.renderItemAndEffectIntoGUI(this.mc.fontRenderer, this.mc.renderEngine, InventoryUtils.cycleItemStack(((IArcaneRecipe)recipe).getRecipeOutput()), x + 48 + start, y + 22);
         itemRenderer.renderItemOverlayIntoGUI(this.mc.fontRenderer, this.mc.renderEngine, InventoryUtils.cycleItemStack(((IArcaneRecipe)recipe).getRecipeOutput()), x + 48 + start, y + 22);
         GL11.glEnable(2896);
         GL11.glPopMatrix();
         if(mposx >= x + 48 + start && mposy >= y + 27 && mposx < x + 48 + start + 16 && mposy < y + 27 + 16) {
            this.drawCustomTooltip(this, itemRenderer, this.fontRendererObj, InventoryUtils.cycleItemStack(((IArcaneRecipe)recipe).getRecipeOutput()).getTooltip(this.mc.thePlayer, this.mc.gameSettings.advancedItemTooltips), mx, my, 11);
         }

         String var23 = StatCollector.translateToLocal("recipe.type.arcane");
         int var24 = this.fontRendererObj.getStringWidth(var23);
         this.fontRendererObj.drawString(var23, x + start + 56 - var24 / 2, y, 5263440);
         if(recipe != null && recipe instanceof ShapedArcaneRecipe) {
            items = ((ShapedArcaneRecipe)recipe).width;
            i = ((ShapedArcaneRecipe)recipe).height;
            Object[] var26 = ((ShapedArcaneRecipe)recipe).getInput();

            for(ref = 0; ref < items && ref < 3; ++ref) {
               for(j = 0; j < i && j < 3; ++j) {
                  if(var26[ref + j * items] != null) {
                     GL11.glPushMatrix();
                     GL11.glTranslated(0.0D, 0.0D, 100.0D);
                     GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
                     RenderHelper.enableGUIStandardItemLighting();
                     GL11.glDisable(2896);
                     GL11.glEnable(2884);
                     itemRenderer.renderItemAndEffectIntoGUI(this.mc.fontRenderer, this.mc.renderEngine, InventoryUtils.cycleItemStack(var26[ref + j * items]), x + start + 16 + ref * 32, y + 66 + j * 32);
                     itemRenderer.renderItemOverlayIntoGUI(this.mc.fontRenderer, this.mc.renderEngine, InventoryUtils.cycleItemStack(var26[ref + j * items]).copy().splitStack(1), x + start + 16 + ref * 32, y + 66 + j * 32);
                     GL11.glEnable(2896);
                     GL11.glPopMatrix();
                  }
               }
            }

            for(ref = 0; ref < items && ref < 3; ++ref) {
               for(j = 0; j < i && j < 3; ++j) {
                  if(var26[ref + j * items] != null && mposx >= x + 16 + start + ref * 32 && mposy >= y + 66 + j * 32 && mposx < x + 16 + start + ref * 32 + 16 && mposy < y + 66 + j * 32 + 16) {
                     List addtext1 = InventoryUtils.cycleItemStack(var26[ref + j * items]).getTooltip(this.mc.thePlayer, this.mc.gameSettings.advancedItemTooltips);
                     Object[] ref1 = this.findRecipeReference(InventoryUtils.cycleItemStack(var26[ref + j * items]));
                     if(ref1 != null && !((String)ref1[0]).equals(this.research.key)) {
                        addtext1.add("§8§o" + StatCollector.translateToLocal("recipe.clickthrough"));
                        this.reference.add(Arrays.asList(new Serializable[]{Integer.valueOf(mx), Integer.valueOf(my), (String)ref1[0], (Integer)ref1[1]}));
                     }

                     this.drawCustomTooltip(this, itemRenderer, this.fontRendererObj, addtext1, mx, my, 11);
                  }
               }
            }
         }

         if(recipe != null && recipe instanceof ShapelessArcaneRecipe) {
            ArrayList var25 = ((ShapelessArcaneRecipe)recipe).getInput();

            for(i = 0; i < var25.size() && i < 9; ++i) {
               if(var25.get(i) != null) {
                  GL11.glPushMatrix();
                  GL11.glTranslated(0.0D, 0.0D, 100.0D);
                  GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
                  RenderHelper.enableGUIStandardItemLighting();
                  GL11.glDisable(2896);
                  GL11.glEnable(2884);
                  itemRenderer.renderItemAndEffectIntoGUI(this.mc.fontRenderer, this.mc.renderEngine, InventoryUtils.cycleItemStack(var25.get(i)), x + start + 16 + i % 3 * 32, y + 66 + i / 3 * 32);
                  itemRenderer.renderItemOverlayIntoGUI(this.mc.fontRenderer, this.mc.renderEngine, InventoryUtils.cycleItemStack(var25.get(i)), x + start + 16 + i % 3 * 32, y + 66 + i / 3 * 32);
                  GL11.glEnable(2896);
                  GL11.glPopMatrix();
               }
            }

            for(i = 0; i < var25.size() && i < 9; ++i) {
               if(var25.get(i) != null && mposx >= x + 16 + start + i % 3 * 32 && mposy >= y + 66 + i / 3 * 32 && mposx < x + 16 + start + i % 3 * 32 + 16 && mposy < y + 66 + i / 3 * 32 + 16) {
                  List var27 = InventoryUtils.cycleItemStack(var25.get(i)).getTooltip(this.mc.thePlayer, this.mc.gameSettings.advancedItemTooltips);
                  Object[] var28 = this.findRecipeReference(InventoryUtils.cycleItemStack(var25.get(i)));
                  if(var28 != null && !((String)var28[0]).equals(this.research.key)) {
                     var27.add("§8§o" + StatCollector.translateToLocal("recipe.clickthrough"));
                     this.reference.add(Arrays.asList(new Serializable[]{Integer.valueOf(mx), Integer.valueOf(my), (String)var28[0], (Integer)var28[1]}));
                  }

                  this.drawCustomTooltip(this, itemRenderer, this.fontRendererObj, var27, mx, my, 11);
               }
            }
         }

         GL11.glPopMatrix();
      }
   }

   private void drawCraftingPage(int side, int x, int y, int mx, int my, ResearchPage pageParm) {
      Object recipe = null;
      Object tr = null;
      if(pageParm.recipe instanceof Object[]) {
         try {
            tr = ((Object[])((Object[])pageParm.recipe))[this.cycle];
         } catch (Exception var21) {
            this.cycle = 0;
            tr = ((Object[])((Object[])pageParm.recipe))[this.cycle];
         }
      } else {
         tr = pageParm.recipe;
      }

      if(tr instanceof ShapedRecipes) {
         recipe = (ShapedRecipes)tr;
      } else if(tr instanceof ShapelessRecipes) {
         recipe = (ShapelessRecipes)tr;
      } else if(tr instanceof ShapedOreRecipe) {
         recipe = (ShapedOreRecipe)tr;
      } else if(tr instanceof ShapelessOreRecipe) {
         recipe = (ShapelessOreRecipe)tr;
      }

      if(recipe != null) {
         GL11.glPushMatrix();
         int start = side * 152;
         UtilsFX.bindTexture(this.tex2);
         GL11.glPushMatrix();
         GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
         GL11.glEnable(3042);
         GL11.glTranslatef((float)(x + start), (float)y, 0.0F);
         GL11.glScalef(2.0F, 2.0F, 1.0F);
         this.drawTexturedModalRect(2, 32, 60, 15, 52, 52);
         this.drawTexturedModalRect(20, 12, 20, 3, 16, 16);
         GL11.glPopMatrix();
         int mposx = mx;
         int mposy = my;
         GL11.glPushMatrix();
         GL11.glTranslated(0.0D, 0.0D, 100.0D);
         GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
         RenderHelper.enableGUIStandardItemLighting();
         GL11.glDisable(2896);
         GL11.glEnable(2884);
         itemRenderer.renderItemAndEffectIntoGUI(this.mc.fontRenderer, this.mc.renderEngine, InventoryUtils.cycleItemStack(((IRecipe)recipe).getRecipeOutput()), x + 48 + start, y + 32);
         itemRenderer.renderItemOverlayIntoGUI(this.mc.fontRenderer, this.mc.renderEngine, InventoryUtils.cycleItemStack(((IRecipe)recipe).getRecipeOutput()), x + 48 + start, y + 32);
         GL11.glEnable(2896);
         GL11.glPopMatrix();
         if(mx >= x + 48 + start && my >= y + 32 && mx < x + 48 + start + 16 && my < y + 32 + 16) {
            this.drawCustomTooltip(this, itemRenderer, this.fontRendererObj, InventoryUtils.cycleItemStack(((IRecipe)recipe).getRecipeOutput()).getTooltip(this.mc.thePlayer, this.mc.gameSettings.advancedItemTooltips), mx, my, 11);
         }

         String text;
         int offset;
         int var23;
         if(recipe != null && (recipe instanceof ShapedRecipes || recipe instanceof ShapedOreRecipe)) {
            text = StatCollector.translateToLocal("recipe.type.workbench");
            offset = this.fontRendererObj.getStringWidth(text);
            this.fontRendererObj.drawString(text, x + start + 56 - offset / 2, y, 5263440);
            boolean items = false;
            boolean i = false;
            Object addtext = null;
            int var22;
            if(recipe instanceof ShapedRecipes) {
               var22 = ((ShapedRecipes)recipe).recipeWidth;
               var23 = ((ShapedRecipes)recipe).recipeHeight;
               addtext = ((ShapedRecipes)recipe).recipeItems;
            } else {
               var22 = ((Integer)ObfuscationReflectionHelper.getPrivateValue(ShapedOreRecipe.class, (ShapedOreRecipe)recipe, new String[]{"width"})).intValue();
               var23 = ((Integer)ObfuscationReflectionHelper.getPrivateValue(ShapedOreRecipe.class, (ShapedOreRecipe)recipe, new String[]{"height"})).intValue();
               addtext = ((ShapedOreRecipe)recipe).getInput();
            }

            int ref;
            int j;
            for(ref = 0; ref < var22 && ref < 3; ++ref) {
               for(j = 0; j < var23 && j < 3; ++j) {
                  if(((Object[])addtext)[ref + j * var22] != null) {
                     GL11.glPushMatrix();
                     GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
                     RenderHelper.enableGUIStandardItemLighting();
                     GL11.glDisable(2896);
                     GL11.glEnable(2884);
                     GL11.glTranslated(0.0D, 0.0D, 100.0D);
                     itemRenderer.renderItemAndEffectIntoGUI(this.mc.fontRenderer, this.mc.renderEngine, InventoryUtils.cycleItemStack(((Object[])addtext)[ref + j * var22]), x + start + 16 + ref * 32, y + 76 + j * 32);
                     itemRenderer.renderItemOverlayIntoGUI(this.mc.fontRenderer, this.mc.renderEngine, InventoryUtils.cycleItemStack(((Object[])addtext)[ref + j * var22]).copy().splitStack(1), x + start + 16 + ref * 32, y + 76 + j * 32);
                     GL11.glEnable(2896);
                     GL11.glPopMatrix();
                  }
               }
            }

            for(ref = 0; ref < var22 && ref < 3; ++ref) {
               for(j = 0; j < var23 && j < 3; ++j) {
                  if(((Object[])addtext)[ref + j * var22] != null && mposx >= x + 16 + start + ref * 32 && mposy >= y + 76 + j * 32 && mposx < x + 16 + start + ref * 32 + 16 && mposy < y + 76 + j * 32 + 16) {
                     List addtext1 = InventoryUtils.cycleItemStack(((Object[])addtext)[ref + j * var22]).getTooltip(this.mc.thePlayer, this.mc.gameSettings.advancedItemTooltips);
                     Object[] ref1 = this.findRecipeReference(InventoryUtils.cycleItemStack(((Object[])addtext)[ref + j * var22]));
                     if(ref1 != null && !((String)ref1[0]).equals(this.research.key)) {
                        addtext1.add("§8§o" + StatCollector.translateToLocal("recipe.clickthrough"));
                        this.reference.add(Arrays.asList(new Serializable[]{Integer.valueOf(mx), Integer.valueOf(my), (String)ref1[0], (Integer)ref1[1]}));
                     }

                     this.drawCustomTooltip(this, itemRenderer, this.fontRendererObj, addtext1, mx, my, 11);
                  }
               }
            }
         }

         if(recipe != null && (recipe instanceof ShapelessRecipes || recipe instanceof ShapelessOreRecipe)) {
            text = StatCollector.translateToLocal("recipe.type.workbenchshapeless");
            offset = this.fontRendererObj.getStringWidth(text);
            this.fontRendererObj.drawString(text, x + start + 56 - offset / 2, y, 5263440);
            Object var24 = null;
            if(recipe instanceof ShapelessRecipes) {
               var24 = ((ShapelessRecipes)recipe).recipeItems;
            } else {
               var24 = ((ShapelessOreRecipe)recipe).getInput();
            }

            for(var23 = 0; var23 < ((List)var24).size() && var23 < 9; ++var23) {
               if(((List)var24).get(var23) != null) {
                  GL11.glPushMatrix();
                  GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
                  RenderHelper.enableGUIStandardItemLighting();
                  GL11.glDisable(2896);
                  GL11.glEnable(2884);
                  GL11.glTranslated(0.0D, 0.0D, 100.0D);
                  itemRenderer.renderItemAndEffectIntoGUI(this.mc.fontRenderer, this.mc.renderEngine, InventoryUtils.cycleItemStack(((List)var24).get(var23)), x + start + 16 + var23 % 3 * 32, y + 76 + var23 / 3 * 32);
                  itemRenderer.renderItemOverlayIntoGUI(this.mc.fontRenderer, this.mc.renderEngine, InventoryUtils.cycleItemStack(((List)var24).get(var23)).copy().splitStack(1), x + start + 16 + var23 % 3 * 32, y + 76 + var23 / 3 * 32);
                  GL11.glEnable(2896);
                  GL11.glPopMatrix();
               }
            }

            for(var23 = 0; var23 < ((List)var24).size() && var23 < 9; ++var23) {
               if(((List)var24).get(var23) != null && mposx >= x + 16 + start + var23 % 3 * 32 && mposy >= y + 76 + var23 / 3 * 32 && mposx < x + 16 + start + var23 % 3 * 32 + 16 && mposy < y + 76 + var23 / 3 * 32 + 16) {
                  List var25 = InventoryUtils.cycleItemStack(((List)var24).get(var23)).getTooltip(this.mc.thePlayer, this.mc.gameSettings.advancedItemTooltips);
                  Object[] var26 = this.findRecipeReference(InventoryUtils.cycleItemStack(((List)var24).get(var23)));
                  if(var26 != null && !((String)var26[0]).equals(this.research.key)) {
                     var25.add("§8§o" + StatCollector.translateToLocal("recipe.clickthrough"));
                     this.reference.add(Arrays.asList(new Serializable[]{Integer.valueOf(mx), Integer.valueOf(my), (String)var26[0], (Integer)var26[1]}));
                  }

                  this.drawCustomTooltip(this, itemRenderer, this.fontRendererObj, var25, mx, my, 11);
               }
            }
         }

         GL11.glPopMatrix();
      }
   }

   private void drawCruciblePage(int side, int x, int y, int mx, int my, ResearchPage pageParm) {
      CrucibleRecipe rc = null;
      Object tr = null;
      if(pageParm.recipe instanceof Object[]) {
         try {
            tr = ((Object[])((Object[])pageParm.recipe))[this.cycle];
         } catch (Exception var26) {
            this.cycle = 0;
            tr = ((Object[])((Object[])pageParm.recipe))[this.cycle];
         }
      } else {
         tr = pageParm.recipe;
      }

      if(tr instanceof CrucibleRecipe) {
         rc = (CrucibleRecipe)tr;
      }

      if(rc != null) {
         GL11.glPushMatrix();
         int start = side * 152;
         String text = StatCollector.translateToLocal("recipe.type.crucible");
         int offset = this.fontRendererObj.getStringWidth(text);
         this.fontRendererObj.drawString(text, x + start + 56 - offset / 2, y, 5263440);
         UtilsFX.bindTexture(this.tex2);
         GL11.glPushMatrix();
         GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
         GL11.glEnable(3042);
         GL11.glTranslatef((float)(x + start), (float)(y + 28), 0.0F);
         GL11.glScalef(2.0F, 2.0F, 1.0F);
         this.drawTexturedModalRect(0, 0, 0, 3, 56, 17);
         GL11.glTranslatef(0.0F, 32.0F, 0.0F);
         this.drawTexturedModalRect(0, 0, 0, 20, 56, 48);
         GL11.glTranslatef(21.0F, -8.0F, 0.0F);
         this.drawTexturedModalRect(0, 0, 100, 84, 11, 13);
         GL11.glPopMatrix();
         int mposx = mx;
         int mposy = my;
         int total = 0;
         int rows = (rc.aspects.size() - 1) / 3;
         int shift = (3 - rc.aspects.size() % 3) * 10;
         int sx = x + start + 28;
         int sy = y + 96 + 32 - 10 * rows;
         Aspect[] arr$ = rc.aspects.getAspectsSorted();
         int len$ = arr$.length;

         int i$;
         Aspect tag;
         byte m;
         int vx;
         int vy;
         for(i$ = 0; i$ < len$; ++i$) {
            tag = arr$[i$];
            m = 0;
            if(total / 3 >= rows && (rows > 1 || rc.aspects.size() < 3)) {
               m = 1;
            }

            vx = sx + total % 3 * 20 + shift * m;
            vy = sy + total / 3 * 20;
            UtilsFX.drawTag(vx, vy, tag, (float)rc.aspects.getAmount(tag), 0, (double)this.zLevel);
            ++total;
         }

         GL11.glPushMatrix();
         GL11.glTranslated(0.0D, 0.0D, 100.0D);
         GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
         RenderHelper.enableGUIStandardItemLighting();
         GL11.glDisable(2896);
         GL11.glEnable(2884);
         itemRenderer.renderItemAndEffectIntoGUI(this.mc.fontRenderer, this.mc.renderEngine, rc.getRecipeOutput(), x + 48 + start, y + 36);
         itemRenderer.renderItemOverlayIntoGUI(this.mc.fontRenderer, this.mc.renderEngine, rc.getRecipeOutput(), x + 48 + start, y + 36);
         GL11.glEnable(2896);
         GL11.glPopMatrix();
         GL11.glPushMatrix();
         GL11.glTranslated(0.0D, 0.0D, 100.0D);
         GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
         RenderHelper.enableGUIStandardItemLighting();
         GL11.glDisable(2896);
         GL11.glEnable(2884);
         itemRenderer.renderItemAndEffectIntoGUI(this.mc.fontRenderer, this.mc.renderEngine, InventoryUtils.cycleItemStack(rc.catalyst), x + 26 + start, y + 72);
         itemRenderer.renderItemOverlayIntoGUI(this.mc.fontRenderer, this.mc.renderEngine, InventoryUtils.cycleItemStack(rc.catalyst).copy().splitStack(1), x + 26 + start, y + 72);
         GL11.glEnable(2896);
         GL11.glPopMatrix();
         if(mx >= x + 48 + start && my >= y + 36 && mx < x + 48 + start + 16 && my < y + 36 + 16) {
            this.drawCustomTooltip(this, itemRenderer, this.fontRendererObj, rc.getRecipeOutput().getTooltip(this.mc.thePlayer, this.mc.gameSettings.advancedItemTooltips), mx, my, 11);
         }

         if(mx >= x + 26 + start && my >= y + 72 && mx < x + 26 + start + 16 && my < y + 72 + 16) {
            List var27 = InventoryUtils.cycleItemStack(rc.catalyst).getTooltip(this.mc.thePlayer, this.mc.gameSettings.advancedItemTooltips);
            Object[] var28 = this.findRecipeReference(InventoryUtils.cycleItemStack(rc.catalyst));
            if(var28 != null && !((String)var28[0]).equals(this.research.key)) {
               var27.add("§8§o" + StatCollector.translateToLocal("recipe.clickthrough"));
               this.reference.add(Arrays.asList(new Serializable[]{Integer.valueOf(mx), Integer.valueOf(my), (String)var28[0], (Integer)var28[1]}));
            }

            this.drawCustomTooltip(this, itemRenderer, this.fontRendererObj, var27, mx, my, 11);
         }

         total = 0;
         arr$ = rc.aspects.getAspectsSorted();
         len$ = arr$.length;

         for(i$ = 0; i$ < len$; ++i$) {
            tag = arr$[i$];
            m = 0;
            if(total / 3 >= rows && (rows > 1 || rc.aspects.size() < 3)) {
               m = 1;
            }

            vx = sx + total % 3 * 20 + shift * m;
            vy = sy + total / 3 * 20;
            if(mposx >= vx && mposy >= vy && mposx < vx + 16 && mposy < vy + 16) {
               this.drawCustomTooltip(this, itemRenderer, this.fontRendererObj, Arrays.asList(new String[]{tag.getName(), tag.getLocalizedDescription()}), mx, my, 11);
            }

            ++total;
         }

         GL11.glPopMatrix();
      }

   }

   private void drawSmeltingPage(int side, int x, int y, int mx, int my, ResearchPage pageParm) {
      ItemStack in = (ItemStack)pageParm.recipe;
      ItemStack out = null;
      if(in != null) {
         out = FurnaceRecipes.smelting().getSmeltingResult(in);
      }

      if(in != null && out != null) {
         GL11.glPushMatrix();
         int start = side * 152;
         String text = StatCollector.translateToLocal("recipe.type.smelting");
         int offset = this.fontRendererObj.getStringWidth(text);
         this.fontRendererObj.drawString(text, x + start + 56 - offset / 2, y, 5263440);
         UtilsFX.bindTexture(this.tex2);
         GL11.glPushMatrix();
         GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
         GL11.glEnable(3042);
         GL11.glTranslatef((float)(x + start), (float)(y + 28), 0.0F);
         GL11.glScalef(2.0F, 2.0F, 1.0F);
         this.drawTexturedModalRect(0, 0, 0, 192, 56, 64);
         GL11.glPopMatrix();
         GL11.glPushMatrix();
         GL11.glTranslated(0.0D, 0.0D, 100.0D);
         GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
         RenderHelper.enableGUIStandardItemLighting();
         GL11.glDisable(2896);
         GL11.glEnable(2884);
         itemRenderer.renderItemAndEffectIntoGUI(this.mc.fontRenderer, this.mc.renderEngine, in, x + 48 + start, y + 64);
         itemRenderer.renderItemOverlayIntoGUI(this.mc.fontRenderer, this.mc.renderEngine, in, x + 48 + start, y + 64);
         GL11.glEnable(2896);
         GL11.glPopMatrix();
         GL11.glPushMatrix();
         GL11.glTranslated(0.0D, 0.0D, 100.0D);
         GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
         RenderHelper.enableGUIStandardItemLighting();
         GL11.glDisable(2896);
         GL11.glEnable(2884);
         itemRenderer.renderItemAndEffectIntoGUI(this.mc.fontRenderer, this.mc.renderEngine, out, x + 48 + start, y + 144);
         itemRenderer.renderItemOverlayIntoGUI(this.mc.fontRenderer, this.mc.renderEngine, out, x + 48 + start, y + 144);
         GL11.glEnable(2896);
         GL11.glPopMatrix();
         if(mx >= x + 48 + start && my >= y + 64 && mx < x + 48 + start + 16 && my < y + 64 + 16) {
            List addtext = in.getTooltip(this.mc.thePlayer, this.mc.gameSettings.advancedItemTooltips);
            Object[] ref = this.findRecipeReference(in);
            if(ref != null && !((String)ref[0]).equals(this.research.key)) {
               addtext.add("§8§o" + StatCollector.translateToLocal("recipe.clickthrough"));
               this.reference.add(Arrays.asList(new Serializable[]{Integer.valueOf(mx), Integer.valueOf(my), (String)ref[0], (Integer)ref[1]}));
            }

            this.drawCustomTooltip(this, itemRenderer, this.fontRendererObj, addtext, mx, my, 11);
         }

         if(mx >= x + 48 + start && my >= y + 144 && mx < x + 48 + start + 16 && my < y + 144 + 16) {
            this.drawCustomTooltip(this, itemRenderer, this.fontRendererObj, out.getTooltip(this.mc.thePlayer, this.mc.gameSettings.advancedItemTooltips), mx, my, 11);
         }

         GL11.glPopMatrix();
      }

   }

   private void drawInfusionPage(int side, int x, int y, int mx, int my, ResearchPage pageParm) {
      Object tr = null;
      if(pageParm.recipe instanceof Object[]) {
         try {
            tr = ((Object[])((Object[])pageParm.recipe))[this.cycle];
         } catch (Exception var33) {
            this.cycle = 0;
            tr = ((Object[])((Object[])pageParm.recipe))[this.cycle];
         }
      } else {
         tr = pageParm.recipe;
      }

      InfusionRecipe ri = (InfusionRecipe)tr;
      if(ri != null) {
         GL11.glPushMatrix();
         int start = side * 152;
         String text = StatCollector.translateToLocal("recipe.type.infusion");
         int offset = this.fontRendererObj.getStringWidth(text);
         this.fontRendererObj.drawString(text, x + start + 56 - offset / 2, y, 5263440);
         int inst = Math.min(5, ri.getInstability() / 2);
         text = StatCollector.translateToLocal("tc.inst") + " " + StatCollector.translateToLocal("tc.inst." + inst);
         offset = this.fontRendererObj.getStringWidth(text);
         this.fontRendererObj.drawString(text, x + start + 56 - offset / 2, y + 194, 5263440);
         UtilsFX.bindTexture(this.tex2);
         GL11.glPushMatrix();
         GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
         GL11.glEnable(3042);
         GL11.glTranslatef((float)(x + start), (float)(y + 20), 0.0F);
         GL11.glScalef(2.0F, 2.0F, 1.0F);
         this.drawTexturedModalRect(0, 0, 0, 3, 56, 17);
         GL11.glTranslatef(0.0F, 19.0F, 0.0F);
         this.drawTexturedModalRect(0, 0, 200, 77, 60, 44);
         GL11.glPopMatrix();
         int mposx = mx;
         int mposy = my;
         int total = 0;
         int rows = (ri.getAspects().size() - 1) / 5;
         int shift = (5 - ri.getAspects().size() % 5) * 10;
         int sx = x + start + 8;
         int sy = y + 164 - 10 * rows;
         Aspect[] idisp = ri.getAspects().getAspectsSorted();
         int le = idisp.length;

         int arr$;
         int len$;
         for(int coords = 0; coords < le; ++coords) {
            Aspect pieSlice = idisp[coords];
            byte currentRot = 0;
            if(total / 5 >= rows && (rows > 1 || ri.getAspects().size() < 5)) {
               currentRot = 1;
            }

            arr$ = sx + total % 5 * 20 + shift * currentRot;
            len$ = sy + total / 5 * 20;
            UtilsFX.drawTag(arr$, len$, pieSlice, (float)ri.getAspects().getAmount(pieSlice), 0, (double)this.zLevel);
            ++total;
         }

         idisp = null;
         ItemStack var34;
         if(ri.getRecipeOutput() instanceof ItemStack) {
            var34 = InventoryUtils.cycleItemStack((ItemStack)ri.getRecipeOutput());
         } else {
            var34 = InventoryUtils.cycleItemStack(ri.getRecipeInput()).copy();
            Object[] var35 = (Object[])((Object[])ri.getRecipeOutput());
            NBTBase var36 = (NBTBase)var35[1];
            var34.setTagInfo((String)var35[0], var36);
         }

         GL11.glPushMatrix();
         GL11.glTranslated(0.0D, 0.0D, 100.0D);
         GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
         RenderHelper.enableGUIStandardItemLighting();
         GL11.glDisable(2896);
         GL11.glEnable(2884);
         itemRenderer.renderItemAndEffectIntoGUI(this.mc.fontRenderer, this.mc.renderEngine, var34, x + 48 + start, y + 28);
         itemRenderer.renderItemOverlayIntoGUI(this.mc.fontRenderer, this.mc.renderEngine, var34, x + 48 + start, y + 28);
         GL11.glEnable(2896);
         GL11.glPopMatrix();
         GL11.glPushMatrix();
         GL11.glTranslated(0.0D, 0.0D, 100.0D);
         GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
         RenderHelper.enableGUIStandardItemLighting();
         GL11.glDisable(2896);
         GL11.glEnable(2884);
         itemRenderer.renderItemAndEffectIntoGUI(this.mc.fontRenderer, this.mc.renderEngine, InventoryUtils.cycleItemStack(ri.getRecipeInput()), x + 48 + start, y + 94);
         itemRenderer.renderItemOverlayIntoGUI(this.mc.fontRenderer, this.mc.renderEngine, InventoryUtils.cycleItemStack(ri.getRecipeInput()).copy().splitStack(1), x + 48 + start, y + 94);
         GL11.glEnable(2896);
         GL11.glPopMatrix();
         GL11.glPushMatrix();
         GL11.glTranslated(0.0D, 0.0D, 100.0D);
         GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
         RenderHelper.enableGUIStandardItemLighting();
         GL11.glDisable(2896);
         GL11.glEnable(2884);
         le = ri.getComponents().length;
         ArrayList var37 = new ArrayList();
         float var38 = (float)(360 / le);
         float var39 = -90.0F;

         int i$;
         for(arr$ = 0; arr$ < le; ++arr$) {
            len$ = (int)(MathHelper.cos(var39 / 180.0F * 3.1415927F) * 40.0F) - 8;
            i$ = (int)(MathHelper.sin(var39 / 180.0F * 3.1415927F) * 40.0F) - 8;
            var39 += var38;
            var37.add(new GuiResearchRecipe.Coord2D(len$, i$));
         }

         total = 0;
         sx = x + 56 + start;
         sy = y + 102;
         ItemStack[] var40 = ri.getComponents();
         len$ = var40.length;

         ItemStack tag;
         int m;
         int vx;
         for(i$ = 0; i$ < len$; ++i$) {
            tag = var40[i$];
            m = sx + ((GuiResearchRecipe.Coord2D)var37.get(total)).x;
            vx = sy + ((GuiResearchRecipe.Coord2D)var37.get(total)).y;
            itemRenderer.renderItemAndEffectIntoGUI(this.mc.fontRenderer, this.mc.renderEngine, InventoryUtils.cycleItemStack(tag), m, vx);
            itemRenderer.renderItemOverlayIntoGUI(this.mc.fontRenderer, this.mc.renderEngine, InventoryUtils.cycleItemStack(tag).copy().splitStack(1), m, vx);
            ++total;
         }

         GL11.glEnable(2896);
         GL11.glPopMatrix();
         if(mx >= x + 48 + start && my >= y + 28 && mx < x + 48 + start + 16 && my < y + 28 + 16) {
            this.drawCustomTooltip(this, itemRenderer, this.fontRendererObj, var34.getTooltip(this.mc.thePlayer, this.mc.gameSettings.advancedItemTooltips), mx, my, 11);
         }

         if(mx >= x + 48 + start && my >= y + 94 && mx < x + 48 + start + 16 && my < y + 94 + 16) {
            List var41 = InventoryUtils.cycleItemStack(ri.getRecipeInput()).getTooltip(this.mc.thePlayer, this.mc.gameSettings.advancedItemTooltips);
            Object[] var42 = this.findRecipeReference(InventoryUtils.cycleItemStack(ri.getRecipeInput()));
            if(var42 != null && !((String)var42[0]).equals(this.research.key)) {
               var41.add("§8§o" + StatCollector.translateToLocal("recipe.clickthrough"));
               this.reference.add(Arrays.asList(new Serializable[]{Integer.valueOf(mx), Integer.valueOf(my), (String)var42[0], (Integer)var42[1]}));
            }

            this.drawCustomTooltip(this, itemRenderer, this.fontRendererObj, var41, mx, my, 11);
         }

         total = 0;
         sx = x + 56 + start;
         sy = y + 102;
         var40 = ri.getComponents();
         len$ = var40.length;

         for(i$ = 0; i$ < len$; ++i$) {
            tag = var40[i$];
            m = sx + ((GuiResearchRecipe.Coord2D)var37.get(total)).x;
            vx = sy + ((GuiResearchRecipe.Coord2D)var37.get(total)).y;
            if(mposx >= m && mposy >= vx && mposx < m + 16 && mposy < vx + 16) {
               List vy = InventoryUtils.cycleItemStack(tag).getTooltip(this.mc.thePlayer, this.mc.gameSettings.advancedItemTooltips);
               Object[] ref = this.findRecipeReference(InventoryUtils.cycleItemStack(tag));
               if(ref != null && !((String)ref[0]).equals(this.research.key)) {
                  vy.add("§8§o" + StatCollector.translateToLocal("recipe.clickthrough"));
                  this.reference.add(Arrays.asList(new Serializable[]{Integer.valueOf(mx), Integer.valueOf(my), (String)ref[0], (Integer)ref[1]}));
               }

               this.drawCustomTooltip(this, itemRenderer, this.fontRendererObj, vy, mx, my, 11);
            }

            ++total;
         }

         total = 0;
         rows = (ri.getAspects().size() - 1) / 5;
         shift = (5 - ri.getAspects().size() % 5) * 10;
         sx = x + start + 8;
         sy = y + 164 - 10 * rows;
         Aspect[] var43 = ri.getAspects().getAspectsSorted();
         len$ = var43.length;

         for(i$ = 0; i$ < len$; ++i$) {
            Aspect var44 = var43[i$];
            byte var45 = 0;
            if(total / 5 >= rows && (rows > 1 || ri.getAspects().size() < 5)) {
               var45 = 1;
            }

            vx = sx + total % 5 * 20 + shift * var45;
            int var46 = sy + total / 5 * 20;
            if(mposx >= vx && mposy >= var46 && mposx < vx + 16 && mposy < var46 + 16) {
               this.drawCustomTooltip(this, itemRenderer, this.fontRendererObj, Arrays.asList(new String[]{var44.getName(), var44.getLocalizedDescription()}), mx, my, 11);
            }

            ++total;
         }

         GL11.glPopMatrix();
      }

   }

   private void drawInfusionEnchantingPage(int side, int x, int y, int mx, int my, ResearchPage pageParm) {
      Object tr = pageParm.recipe;
      InfusionEnchantmentRecipe ri = (InfusionEnchantmentRecipe)tr;
      if(ri != null) {
         GL11.glPushMatrix();
         int start = side * 152;
         int level = (int)(1L + System.currentTimeMillis() / 1000L % (long)ri.enchantment.getMaxLevel());
         String text = StatCollector.translateToLocal("recipe.type.infusionenchantment");
         int offset = this.fontRendererObj.getStringWidth(text);
         this.fontRendererObj.drawString(text, x + start + 56 - offset / 2, y, 5263440);
         int inst = Math.min(5, ri.instability / 2);
         text = StatCollector.translateToLocal("tc.inst") + " " + StatCollector.translateToLocal("tc.inst." + inst);
         offset = this.fontRendererObj.getStringWidth(text);
         this.fontRendererObj.drawString(text, x + start + 56 - offset / 2, y + 194, 5263440);
         text = ri.enchantment.getTranslatedName(level);
         offset = this.fontRendererObj.getStringWidth(text);
         this.fontRendererObj.drawString(text, x + start + 56 - offset / 2, y + 24, 7360656);
         int xp = ri.recipeXP * level;
         text = xp + " levels";
         offset = this.fontRendererObj.getStringWidth(text);
         this.fontRendererObj.drawString(text, x + start + 56 - offset / 2, y + 40, 5277776);
         UtilsFX.bindTexture(this.tex2);
         GL11.glPushMatrix();
         GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
         GL11.glEnable(3042);
         GL11.glTranslatef((float)(x + start), (float)(y + 20), 0.0F);
         GL11.glScalef(2.0F, 2.0F, 1.0F);
         GL11.glTranslatef(0.0F, 19.0F, 0.0F);
         this.drawTexturedModalRect(0, 0, 200, 77, 60, 44);
         GL11.glPopMatrix();
         int mposx = mx;
         int mposy = my;
         int total = 0;
         int rows = (ri.aspects.size() - 1) / 5;
         int shift = (5 - ri.aspects.size() % 5) * 10;
         int sx = x + start + 8;
         int sy = y + 164 - 10 * rows;
         Aspect[] le = ri.aspects.getAspectsSorted();
         int coords = le.length;

         int len$;
         int i$;
         for(int pieSlice = 0; pieSlice < coords; ++pieSlice) {
            Aspect currentRot = le[pieSlice];
            byte arr$ = 0;
            if(total / 5 >= rows && (rows > 1 || ri.aspects.size() < 5)) {
               arr$ = 1;
            }

            len$ = sx + total % 5 * 20 + shift * arr$;
            i$ = sy + total / 5 * 20;
            UtilsFX.drawTag(len$, i$, currentRot, (float)(ri.aspects.getAmount(currentRot) * level), 0, (double)this.zLevel);
            ++total;
         }

         GL11.glPushMatrix();
         GL11.glTranslated(0.0D, 0.0D, 100.0D);
         GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
         RenderHelper.enableGUIStandardItemLighting();
         GL11.glDisable(2896);
         GL11.glEnable(2884);
         int var34 = ri.components.length;
         ArrayList var35 = new ArrayList();
         float var36 = (float)(360 / var34);
         float var37 = -90.0F;

         for(int var38 = 0; var38 < var34; ++var38) {
            len$ = (int)(MathHelper.cos(var37 / 180.0F * 3.1415927F) * 40.0F) - 8;
            i$ = (int)(MathHelper.sin(var37 / 180.0F * 3.1415927F) * 40.0F) - 8;
            var37 += var36;
            var35.add(new GuiResearchRecipe.Coord2D(len$, i$));
         }

         total = 0;
         sx = x + 56 + start;
         sy = y + 102;
         ItemStack[] var39 = ri.components;
         len$ = var39.length;

         ItemStack tag;
         int m;
         int vx;
         for(i$ = 0; i$ < len$; ++i$) {
            tag = var39[i$];
            m = sx + ((GuiResearchRecipe.Coord2D)var35.get(total)).x;
            vx = sy + ((GuiResearchRecipe.Coord2D)var35.get(total)).y;
            itemRenderer.renderItemAndEffectIntoGUI(this.mc.fontRenderer, this.mc.renderEngine, InventoryUtils.cycleItemStack(tag), m, vx);
            itemRenderer.renderItemOverlayIntoGUI(this.mc.fontRenderer, this.mc.renderEngine, InventoryUtils.cycleItemStack(tag).copy().splitStack(1), m, vx);
            ++total;
         }

         GL11.glEnable(2896);
         GL11.glPopMatrix();
         total = 0;
         sx = x + 56 + start;
         sy = y + 102;
         var39 = ri.components;
         len$ = var39.length;

         for(i$ = 0; i$ < len$; ++i$) {
            tag = var39[i$];
            m = sx + ((GuiResearchRecipe.Coord2D)var35.get(total)).x;
            vx = sy + ((GuiResearchRecipe.Coord2D)var35.get(total)).y;
            if(mposx >= m && mposy >= vx && mposx < m + 16 && mposy < vx + 16) {
               List vy = InventoryUtils.cycleItemStack(tag).getTooltip(this.mc.thePlayer, this.mc.gameSettings.advancedItemTooltips);
               Object[] ref = this.findRecipeReference(InventoryUtils.cycleItemStack(tag));
               if(ref != null && !((String)ref[0]).equals(this.research.key)) {
                  vy.add("§8§o" + StatCollector.translateToLocal("recipe.clickthrough"));
                  this.reference.add(Arrays.asList(new Serializable[]{Integer.valueOf(mx), Integer.valueOf(my), (String)ref[0], (Integer)ref[1]}));
               }

               this.drawCustomTooltip(this, itemRenderer, this.fontRendererObj, vy, mx, my, 11);
            }

            ++total;
         }

         total = 0;
         rows = (ri.aspects.size() - 1) / 5;
         shift = (5 - ri.aspects.size() % 5) * 10;
         sx = x + start + 8;
         sy = y + 164 - 10 * rows;
         Aspect[] var40 = ri.aspects.getAspectsSorted();
         len$ = var40.length;

         for(i$ = 0; i$ < len$; ++i$) {
            Aspect var41 = var40[i$];
            byte var42 = 0;
            if(total / 5 >= rows && (rows > 1 || ri.aspects.size() < 5)) {
               var42 = 1;
            }

            vx = sx + total % 5 * 20 + shift * var42;
            int var43 = sy + total / 5 * 20;
            if(mposx >= vx && mposy >= var43 && mposx < vx + 16 && mposy < var43 + 16) {
               this.drawCustomTooltip(this, itemRenderer, this.fontRendererObj, Arrays.asList(new String[]{var41.getName(), var41.getLocalizedDescription()}), mx, my, 11);
            }

            ++total;
         }

         GL11.glPopMatrix();
      }

   }

   private void drawTextPage(int side, int x, int y, String text) {
      GL11.glPushMatrix();
      RenderHelper.enableGUIStandardItemLighting();
      GL11.glEnable(3042);
      this.fr.drawSplitString(text, x - 15 + side * 152, y, 139, 0, this);
      GL11.glPopMatrix();
   }

   protected void mouseClicked(int par1, int par2, int par3) {
      int var4 = (this.width - this.paneWidth) / 2;
      int var5 = (this.height - this.paneHeight) / 2;
      int mx = par1 - (var4 + 261);
      int my = par2 - (var5 + 189);
      if(this.page < this.maxPages - 2 && mx >= 0 && my >= 0 && mx < 14 && my < 10) {
         this.page += 2;
         this.lastCycle = 0L;
         this.cycle = -1;
         Minecraft.getMinecraft().theWorld.playSound(Minecraft.getMinecraft().thePlayer.posX, Minecraft.getMinecraft().thePlayer.posY, Minecraft.getMinecraft().thePlayer.posZ, "thaumcraft:page", 0.66F, 1.0F, false);
      }

      mx = par1 - (var4 - 17);
      my = par2 - (var5 + 189);
      if(this.page >= 2 && mx >= 0 && my >= 0 && mx < 14 && my < 10) {
         this.page -= 2;
         this.lastCycle = 0L;
         this.cycle = -1;
         Minecraft.getMinecraft().theWorld.playSound(Minecraft.getMinecraft().thePlayer.posX, Minecraft.getMinecraft().thePlayer.posY, Minecraft.getMinecraft().thePlayer.posZ, "thaumcraft:page", 0.66F, 1.0F, false);
      }

      if(!history.isEmpty()) {
         mx = par1 - (var4 + 118);
         my = par2 - (var5 + 189);
         if(mx >= 0 && my >= 0 && mx < 20 && my < 12) {
            Minecraft.getMinecraft().theWorld.playSound(Minecraft.getMinecraft().thePlayer.posX, Minecraft.getMinecraft().thePlayer.posY, Minecraft.getMinecraft().thePlayer.posZ, "thaumcraft:page", 0.66F, 1.0F, false);
            Object[] i$ = (Object[])history.pop();
            this.mc.displayGuiScreen(new GuiResearchRecipe(ResearchCategories.getResearch((String)i$[0]), ((Integer)i$[1]).intValue(), this.guiMapX, this.guiMapY));
         }
      }

      if(this.reference.size() > 0) {
         Iterator i$1 = this.reference.iterator();

         while(i$1.hasNext()) {
            List coords = (List)i$1.next();
            if(par1 >= ((Integer)coords.get(0)).intValue() && par2 >= ((Integer)coords.get(1)).intValue() && par1 < ((Integer)coords.get(0)).intValue() + 16 && par2 < ((Integer)coords.get(1)).intValue() + 16) {
               Minecraft.getMinecraft().theWorld.playSound(Minecraft.getMinecraft().thePlayer.posX, Minecraft.getMinecraft().thePlayer.posY, Minecraft.getMinecraft().thePlayer.posZ, "thaumcraft:page", 0.66F, 1.0F, false);
               history.push(new Object[]{this.research.key, Integer.valueOf(this.page)});
               this.mc.displayGuiScreen(new GuiResearchRecipe(ResearchCategories.getResearch((String)coords.get(2)), ((Integer)coords.get(3)).intValue(), this.guiMapX, this.guiMapY));
            }
         }
      }

      super.mouseClicked(par1, par2, par3);
   }

   public boolean doesGuiPauseGame() {
      return false;
   }

   public Object[] findRecipeReference(ItemStack item) {
      return ThaumcraftApi.getCraftingRecipeKey(this.mc.thePlayer, item);
   }

   public void drawTexturedModalRectScaled(int par1, int par2, int par3, int par4, int par5, int par6, float scale) {
      GL11.glPushMatrix();
      float var7 = 0.00390625F;
      float var8 = 0.00390625F;
      Tessellator var9 = Tessellator.instance;
      GL11.glTranslatef((float)par1 + (float)par5 / 2.0F, (float)par2 + (float)par6 / 2.0F, 0.0F);
      GL11.glScalef(1.0F + scale, 1.0F + scale, 1.0F);
      var9.startDrawingQuads();
      var9.addVertexWithUV((double)((float)(-par5) / 2.0F), (double)((float)par6 / 2.0F), (double)this.zLevel, (double)((float)(par3 + 0) * var7), (double)((float)(par4 + par6) * var8));
      var9.addVertexWithUV((double)((float)par5 / 2.0F), (double)((float)par6 / 2.0F), (double)this.zLevel, (double)((float)(par3 + par5) * var7), (double)((float)(par4 + par6) * var8));
      var9.addVertexWithUV((double)((float)par5 / 2.0F), (double)((float)(-par6) / 2.0F), (double)this.zLevel, (double)((float)(par3 + par5) * var7), (double)((float)(par4 + 0) * var8));
      var9.addVertexWithUV((double)((float)(-par5) / 2.0F), (double)((float)(-par6) / 2.0F), (double)this.zLevel, (double)((float)(par3 + 0) * var7), (double)((float)(par4 + 0) * var8));
      var9.draw();
      GL11.glPopMatrix();
   }

   class Coord2D {
      int x;
      int y;

      Coord2D(int x, int y) {
         this.x = x;
         this.y = y;
      }
   }
}
