package thaumcraft.client.fx.particles;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import java.util.List;
import net.minecraft.block.Block;
import net.minecraft.block.BlockLiquid;
import net.minecraft.block.material.Material;
import net.minecraft.client.particle.EntityFX;
import net.minecraft.crash.CrashReport;
import net.minecraft.crash.CrashReportCategory;
import net.minecraft.init.Blocks;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.MathHelper;
import net.minecraft.util.ReportedException;
import net.minecraft.world.World;
import thaumcraft.common.config.ConfigBlocks;

@SideOnly(Side.CLIENT)
public class FXDrop extends EntityFX {
   int bobTimer;

   public FXDrop(World par1World, double par2, double par4, double par6, float r, float g, float b) {
      super(par1World, par2, par4, par6, 0.0D, 0.0D, 0.0D);
      this.motionX = this.motionY = this.motionZ = 0.0D;
      this.particleRed = r;
      this.particleGreen = g;
      this.particleBlue = b;
      this.setParticleTextureIndex(113);
      this.particleGravity = 0.06F;
      this.bobTimer = 40;
      this.particleMaxAge = (int)(64.0D / (Math.random() * 0.8D + 0.2D));
      this.motionX = this.motionY = this.motionZ = 0.0D;
   }

   public int getBrightnessForRender(float par1) {
      return 257;
   }

   public float getBrightness(float par1) {
      return 1.0F;
   }

   public void onUpdate() {
      this.prevPosX = this.posX;
      this.prevPosY = this.posY;
      this.prevPosZ = this.posZ;
      this.motionY -= (double)this.particleGravity;
      if(this.bobTimer-- > 0) {
         this.motionX *= 0.02D;
         this.motionY *= 0.02D;
         this.motionZ *= 0.02D;
         this.setParticleTextureIndex(113);
      } else {
         this.setParticleTextureIndex(112);
      }

      this.moveEntity(this.motionX, this.motionY, this.motionZ);
      this.motionX *= 0.9800000190734863D;
      this.motionY *= 0.9800000190734863D;
      this.motionZ *= 0.9800000190734863D;
      if(this.particleMaxAge-- <= 0) {
         this.setDead();
      }

      if(this.onGround) {
         this.setParticleTextureIndex(114);
         this.motionX *= 0.699999988079071D;
         this.motionZ *= 0.699999988079071D;
      }

      Material material = this.worldObj.getBlock(MathHelper.floor_double(this.posX), MathHelper.floor_double(this.posY), MathHelper.floor_double(this.posZ)).getMaterial();
      if(material != Material.glass && (material.isLiquid() || material.isSolid())) {
         double d0 = (double)((float)(MathHelper.floor_double(this.posY) + 1) - BlockLiquid.getLiquidHeightPercent(this.worldObj.getBlockMetadata(MathHelper.floor_double(this.posX), MathHelper.floor_double(this.posY), MathHelper.floor_double(this.posZ))));
         if(this.posY < d0) {
            this.setDead();
         }
      }

   }

   public void moveEntity(double par1, double par3, double par5) {
      int x = MathHelper.floor_double(this.posX);
      int y = MathHelper.floor_double(this.posY);
      int z = MathHelper.floor_double(this.posZ);
      if(!this.noClip && this.worldObj.getBlock(x, y, z) != ConfigBlocks.blockJar) {
         this.worldObj.theProfiler.startSection("move");
         this.ySize *= 0.4F;
         double d3 = this.posX;
         double d4 = this.posY;
         double d5 = this.posZ;
         if(this.isInWeb) {
            this.isInWeb = false;
            par1 *= 0.25D;
            par3 *= 0.05000000074505806D;
            par5 *= 0.25D;
            this.motionX = 0.0D;
            this.motionY = 0.0D;
            this.motionZ = 0.0D;
         }

         double d6 = par1;
         double d7 = par3;
         double d8 = par5;
         AxisAlignedBB axisalignedbb = this.boundingBox.copy();
         boolean flag = this.onGround && this.isSneaking();
         if(flag) {
            double list;
            for(list = 0.05D; par1 != 0.0D && this.worldObj.getCollidingBoundingBoxes(this, this.boundingBox.getOffsetBoundingBox(par1, -1.0D, 0.0D)).isEmpty(); d6 = par1) {
               if(par1 < list && par1 >= -list) {
                  par1 = 0.0D;
               } else if(par1 > 0.0D) {
                  par1 -= list;
               } else {
                  par1 += list;
               }
            }

            for(; par5 != 0.0D && this.worldObj.getCollidingBoundingBoxes(this, this.boundingBox.getOffsetBoundingBox(0.0D, -1.0D, par5)).isEmpty(); d8 = par5) {
               if(par5 < list && par5 >= -list) {
                  par5 = 0.0D;
               } else if(par5 > 0.0D) {
                  par5 -= list;
               } else {
                  par5 += list;
               }
            }

            while(par1 != 0.0D && par5 != 0.0D && this.worldObj.getCollidingBoundingBoxes(this, this.boundingBox.getOffsetBoundingBox(par1, -1.0D, par5)).isEmpty()) {
               if(par1 < list && par1 >= -list) {
                  par1 = 0.0D;
               } else if(par1 > 0.0D) {
                  par1 -= list;
               } else {
                  par1 += list;
               }

               if(par5 < list && par5 >= -list) {
                  par5 = 0.0D;
               } else if(par5 > 0.0D) {
                  par5 -= list;
               } else {
                  par5 += list;
               }

               d6 = par1;
               d8 = par5;
            }
         }

         List var39 = this.worldObj.getCollidingBoundingBoxes(this, this.boundingBox.addCoord(par1, par3, par5));

         for(int flag1 = 0; flag1 < var39.size(); ++flag1) {
            par3 = ((AxisAlignedBB)var39.get(flag1)).calculateYOffset(this.boundingBox, par3);
         }

         this.boundingBox.offset(0.0D, par3, 0.0D);
         if(!this.field_70135_K && d7 != par3) {
            par5 = 0.0D;
            par3 = 0.0D;
            par1 = 0.0D;
         }

         boolean var40 = this.onGround || d7 != par3 && d7 < 0.0D;

         int j;
         for(j = 0; j < var39.size(); ++j) {
            par1 = ((AxisAlignedBB)var39.get(j)).calculateXOffset(this.boundingBox, par1);
         }

         this.boundingBox.offset(par1, 0.0D, 0.0D);
         if(!this.field_70135_K && d6 != par1) {
            par5 = 0.0D;
            par3 = 0.0D;
            par1 = 0.0D;
         }

         for(j = 0; j < var39.size(); ++j) {
            par5 = ((AxisAlignedBB)var39.get(j)).calculateZOffset(this.boundingBox, par5);
         }

         this.boundingBox.offset(0.0D, 0.0D, par5);
         if(!this.field_70135_K && d8 != par5) {
            par5 = 0.0D;
            par3 = 0.0D;
            par1 = 0.0D;
         }

         double d10;
         double d11;
         int k;
         double d12;
         if(this.stepHeight > 0.0F && var40 && (flag || this.ySize < 0.05F) && (d6 != par1 || d8 != par5)) {
            d12 = par1;
            d10 = par3;
            d11 = par5;
            par1 = d6;
            par3 = (double)this.stepHeight;
            par5 = d8;
            AxisAlignedBB throwable = this.boundingBox.copy();
            this.boundingBox.setBB(axisalignedbb);
            var39 = this.worldObj.getCollidingBoundingBoxes(this, this.boundingBox.addCoord(d6, par3, d8));

            for(k = 0; k < var39.size(); ++k) {
               par3 = ((AxisAlignedBB)var39.get(k)).calculateYOffset(this.boundingBox, par3);
            }

            this.boundingBox.offset(0.0D, par3, 0.0D);
            if(!this.field_70135_K && d7 != par3) {
               par5 = 0.0D;
               par3 = 0.0D;
               par1 = 0.0D;
            }

            for(k = 0; k < var39.size(); ++k) {
               par1 = ((AxisAlignedBB)var39.get(k)).calculateXOffset(this.boundingBox, par1);
            }

            this.boundingBox.offset(par1, 0.0D, 0.0D);
            if(!this.field_70135_K && d6 != par1) {
               par5 = 0.0D;
               par3 = 0.0D;
               par1 = 0.0D;
            }

            for(k = 0; k < var39.size(); ++k) {
               par5 = ((AxisAlignedBB)var39.get(k)).calculateZOffset(this.boundingBox, par5);
            }

            this.boundingBox.offset(0.0D, 0.0D, par5);
            if(!this.field_70135_K && d8 != par5) {
               par5 = 0.0D;
               par3 = 0.0D;
               par1 = 0.0D;
            }

            if(!this.field_70135_K && d7 != par3) {
               par5 = 0.0D;
               par3 = 0.0D;
               par1 = 0.0D;
            } else {
               par3 = (double)(-this.stepHeight);

               for(k = 0; k < var39.size(); ++k) {
                  par3 = ((AxisAlignedBB)var39.get(k)).calculateYOffset(this.boundingBox, par3);
               }

               this.boundingBox.offset(0.0D, par3, 0.0D);
            }

            if(d12 * d12 + d11 * d11 >= par1 * par1 + par5 * par5) {
               par1 = d12;
               par3 = d10;
               par5 = d11;
               this.boundingBox.setBB(throwable);
            }
         }

         this.worldObj.theProfiler.endSection();
         this.worldObj.theProfiler.startSection("rest");
         this.posX = (this.boundingBox.minX + this.boundingBox.maxX) / 2.0D;
         this.posY = this.boundingBox.minY + (double)this.yOffset - (double)this.ySize;
         this.posZ = (this.boundingBox.minZ + this.boundingBox.maxZ) / 2.0D;
         this.isCollidedHorizontally = d6 != par1 || d8 != par5;
         this.isCollidedVertically = d7 != par3;
         this.onGround = d7 != par3 && d7 < 0.0D;
         this.isCollided = this.isCollidedHorizontally || this.isCollidedVertically;
         this.updateFallState(par3, this.onGround);
         if(d6 != par1) {
            this.motionX = 0.0D;
         }

         if(d7 != par3) {
            this.motionY = 0.0D;
         }

         if(d8 != par5) {
            this.motionZ = 0.0D;
         }

         d12 = this.posX - d3;
         d10 = this.posY - d4;
         d11 = this.posZ - d5;
         if(this.canTriggerWalking() && !flag && this.ridingEntity == null) {
            int var41 = MathHelper.floor_double(this.posX);
            k = MathHelper.floor_double(this.posY - 0.20000000298023224D - (double)this.yOffset);
            int crashreport = MathHelper.floor_double(this.posZ);
            Block crashreportcategory = this.worldObj.getBlock(var41, k, crashreport);
            if(crashreportcategory.isAir(this.worldObj, var41, k, crashreport)) {
               int k1 = this.worldObj.getBlock(var41, k - 1, crashreport).getRenderType();
               if(k1 == 11 || k1 == 32 || k1 == 21) {
                  crashreportcategory = this.worldObj.getBlock(var41, k - 1, crashreport);
               }
            }

            if(crashreportcategory != Blocks.ladder) {
               d10 = 0.0D;
            }

            this.distanceWalkedModified = (float)((double)this.distanceWalkedModified + (double)MathHelper.sqrt_double(d12 * d12 + d11 * d11) * 0.6D);
            this.distanceWalkedOnStepModified = (float)((double)this.distanceWalkedOnStepModified + (double)MathHelper.sqrt_double(d12 * d12 + d10 * d10 + d11 * d11) * 0.6D);
         }

         try {
            this.func_145775_I();
         } catch (Throwable var38) {
            CrashReport var42 = CrashReport.makeCrashReport(var38, "Checking entity tile collision");
            CrashReportCategory var43 = var42.makeCategory("Entity being checked for collision");
            this.addEntityCrashInfo(var43);
            throw new ReportedException(var42);
         }

         this.worldObj.theProfiler.endSection();
      } else {
         this.boundingBox.offset(par1, par3, par5);
         this.posX = (this.boundingBox.minX + this.boundingBox.maxX) / 2.0D;
         this.posY = this.boundingBox.minY + (double)this.yOffset - (double)this.ySize;
         this.posZ = (this.boundingBox.minZ + this.boundingBox.maxZ) / 2.0D;
         x = MathHelper.floor_double(this.posX);
         y = MathHelper.floor_double(this.posY);
         y = MathHelper.floor_double(this.posY);
         if(this.worldObj.getBlock(x, y + 1, z) == ConfigBlocks.blockJar) {
            this.posX = this.prevPosX;
            this.posY = this.prevPosY;
            this.posZ = this.prevPosZ;
            this.motionY = 0.0D;
            this.onGround = true;
         }
      }

   }
}
