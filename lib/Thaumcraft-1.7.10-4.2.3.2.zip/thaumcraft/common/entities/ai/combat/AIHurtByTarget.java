package thaumcraft.common.entities.ai.combat;

import java.util.Iterator;
import java.util.List;
import net.minecraft.entity.EntityCreature;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.AxisAlignedBB;
import thaumcraft.common.entities.ai.combat.AITarget;

public class AIHurtByTarget extends AITarget {
   boolean field_75312_a;
   EntityCreature entityPathNavigate;

   public AIHurtByTarget(EntityCreature par1EntityLiving, boolean par2) {
      super(par1EntityLiving, 16.0F, false);
      this.field_75312_a = par2;
      this.setMutexBits(1);
   }

   public boolean shouldExecute() {
      return this.isSuitableTarget(this.taskOwner.getAITarget(), false);
   }

   public boolean continueExecuting() {
      return this.taskOwner.getAITarget() != null && this.taskOwner.getAITarget() != this.entityPathNavigate;
   }

   public void startExecuting() {
      this.taskOwner.setAttackTarget(this.taskOwner.getAITarget());
      if(this.field_75312_a) {
         List var1 = this.taskOwner.worldObj.getEntitiesWithinAABB(this.taskOwner.getClass(), AxisAlignedBB.getBoundingBox(this.taskOwner.posX, this.taskOwner.posY, this.taskOwner.posZ, this.taskOwner.posX + 1.0D, this.taskOwner.posY + 1.0D, this.taskOwner.posZ + 1.0D).expand((double)this.targetDistance, 4.0D, (double)this.targetDistance));
         Iterator var2 = var1.iterator();

         while(var2.hasNext()) {
            EntityLiving var3 = (EntityLiving)var2.next();
            if(this.taskOwner != var3 && var3.getAttackTarget() == null) {
               var3.setAttackTarget(this.taskOwner.getAITarget());
            }
         }
      }

      super.startExecuting();
   }

   public void resetTask() {
      if(this.taskOwner.getAttackTarget() != null && this.taskOwner.getAttackTarget() instanceof EntityPlayer && ((EntityPlayer)this.taskOwner.getAttackTarget()).capabilities.disableDamage) {
         this.taskOwner.setAttackTarget((EntityLivingBase)null);
         super.resetTask();
      }

   }
}
