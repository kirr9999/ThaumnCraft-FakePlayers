package thaumcraft.common.entities.ai.pech;

import net.minecraft.entity.ai.EntityAIBase;
import thaumcraft.common.entities.monster.EntityPech;

public class AIPechTradePlayer extends EntityAIBase {
   private EntityPech villager;

   public AIPechTradePlayer(EntityPech par1EntityVillager) {
      this.villager = par1EntityVillager;
      this.setMutexBits(5);
   }

   public boolean shouldExecute() {
      return !this.villager.isEntityAlive()?false:(this.villager.isInWater()?false:(!this.villager.isTamed()?false:(!this.villager.onGround?false:(this.villager.velocityChanged?false:this.villager.trading))));
   }

   public void startExecuting() {
      this.villager.getNavigator().clearPathEntity();
   }

   public void resetTask() {
      this.villager.trading = false;
   }
}
