package thaumcraft.common.entities.ai.pech;

import java.util.Iterator;
import java.util.List;
import net.minecraft.entity.Entity;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.EntityAIBase;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.pathfinding.PathPoint;
import thaumcraft.common.config.Config;
import thaumcraft.common.entities.monster.EntityPech;

public class AIPechItemEntityGoto extends EntityAIBase {
   private EntityPech pech;
   private Entity targetEntity;
   float maxTargetDistance = 16.0F;
   private int count;
   private int failedPathFindingPenalty;

   public AIPechItemEntityGoto(EntityPech par1EntityCreature) {
      this.pech = par1EntityCreature;
      this.setMutexBits(3);
   }

   public boolean shouldExecute() {
      if(this.pech.ticksExisted % Config.golemDelay > 0) {
         return false;
      } else if(--this.count > 0) {
         return false;
      } else {
         double range = Double.MAX_VALUE;
         List targets = this.pech.worldObj.getEntitiesWithinAABBExcludingEntity(this.pech, this.pech.boundingBox.expand((double)this.maxTargetDistance, (double)this.maxTargetDistance, (double)this.maxTargetDistance));
         if(targets.size() == 0) {
            return false;
         } else {
            Iterator i$ = targets.iterator();

            while(i$.hasNext()) {
               Entity e = (Entity)i$.next();
               if(e instanceof EntityItem && this.pech.canPickup(((EntityItem)e).getEntityItem())) {
                  NBTTagCompound itemData = ((EntityItem)e).getEntityData();
                  String username = ((EntityItem)e).func_145800_j();
                  if(username == null || !username.equals("PechDrop")) {
                     double distance = e.getDistanceSq(this.pech.posX, this.pech.posY, this.pech.posZ);
                     if(distance < range && distance <= (double)(this.maxTargetDistance * this.maxTargetDistance)) {
                        range = distance;
                        this.targetEntity = e;
                     }
                  }
               }
            }

            if(this.targetEntity == null) {
               return false;
            } else {
               return true;
            }
         }
      }
   }

   public boolean continueExecuting() {
      return this.targetEntity == null?false:(!this.targetEntity.isEntityAlive()?false:!this.pech.getNavigator().noPath() && this.targetEntity.getDistanceSqToEntity(this.pech) < (double)(this.maxTargetDistance * this.maxTargetDistance));
   }

   public void resetTask() {
      this.targetEntity = null;
   }

   public void startExecuting() {
      this.pech.getNavigator().setPath(this.pech.getNavigator().getPathToEntityLiving(this.targetEntity), this.pech.getEntityAttribute(SharedMonsterAttributes.movementSpeed).getAttributeValue() * 1.5D);
      this.count = 0;
   }

   public void updateTask() {
      this.pech.getLookHelper().setLookPositionWithEntity(this.targetEntity, 30.0F, 30.0F);
      if(this.pech.getEntitySenses().canSee(this.targetEntity) && --this.count <= 0) {
         this.count = this.failedPathFindingPenalty + 4 + this.pech.getRNG().nextInt(4);
         this.pech.getNavigator().tryMoveToEntityLiving(this.targetEntity, this.pech.getEntityAttribute(SharedMonsterAttributes.movementSpeed).getAttributeValue() * 1.5D);
         if(this.pech.getNavigator().getPath() != null) {
            PathPoint distance = this.pech.getNavigator().getPath().getFinalPathPoint();
            if(distance != null && this.targetEntity.getDistanceSq((double)distance.xCoord, (double)distance.yCoord, (double)distance.zCoord) < 1.0D) {
               this.failedPathFindingPenalty = 0;
            } else {
               this.failedPathFindingPenalty += 10;
            }
         } else {
            this.failedPathFindingPenalty += 10;
         }
      }

      double var5 = this.pech.getDistanceSq(this.targetEntity.posX, this.targetEntity.boundingBox.minY, this.targetEntity.posZ);
      if(var5 <= 1.5D) {
         this.count = 0;
         int am = ((EntityItem)this.targetEntity).getEntityItem().stackSize;
         ItemStack is = this.pech.pickupItem(((EntityItem)this.targetEntity).getEntityItem());
         if(is != null && is.stackSize > 0) {
            ((EntityItem)this.targetEntity).setEntityItemStack(is);
         } else {
            this.targetEntity.setDead();
         }

         if(is == null || is.stackSize != am) {
            this.targetEntity.worldObj.playSoundAtEntity(this.targetEntity, "random.pop", 0.2F, ((this.targetEntity.worldObj.rand.nextFloat() - this.targetEntity.worldObj.rand.nextFloat()) * 0.7F + 1.0F) * 2.0F);
         }
      }

   }
}
