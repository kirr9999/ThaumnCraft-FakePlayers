package thaumcraft.common.entities.ai.inventory;

import java.util.ArrayList;
import java.util.Iterator;
import net.minecraft.entity.ai.EntityAIBase;
import net.minecraft.entity.ai.RandomPositionGenerator;
import net.minecraft.inventory.IInventory;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.ChunkCoordinates;
import net.minecraft.util.MathHelper;
import net.minecraft.util.Vec3;
import net.minecraftforge.common.util.ForgeDirection;
import thaumcraft.common.config.Config;
import thaumcraft.common.entities.golems.EntityGolemBase;
import thaumcraft.common.entities.golems.GolemHelper;
import thaumcraft.common.entities.golems.Marker;

public class AIEmptyGoto extends EntityAIBase {
   private EntityGolemBase theGolem;
   private double movePosX;
   private double movePosY;
   private double movePosZ;
   private ChunkCoordinates dest = null;
   int count = 0;
   int prevX = 0;
   int prevY = 0;
   int prevZ = 0;

   public AIEmptyGoto(EntityGolemBase par1EntityCreature) {
      this.theGolem = par1EntityCreature;
      this.setMutexBits(3);
   }

   public boolean shouldExecute() {
      if(this.theGolem.itemCarried != null && this.theGolem.ticksExisted % Config.golemDelay <= 0) {
         ArrayList matchingColors = this.theGolem.getColorsMatching(this.theGolem.itemCarried);
         Iterator i$ = matchingColors.iterator();

         byte color;
         ArrayList markers;
         while(i$.hasNext()) {
            color = ((Byte)i$.next()).byteValue();
            markers = GolemHelper.getContainersWithRoom(this.theGolem.worldObj, this.theGolem, color);
            if(markers.size() != 0) {
               ForgeDirection i$1 = ForgeDirection.getOrientation(this.theGolem.homeFacing);
               ChunkCoordinates marker = this.theGolem.getHomePosition();
               int cX = marker.posX - i$1.offsetX;
               int cY = marker.posY - i$1.offsetY;
               int cZ = marker.posZ - i$1.offsetZ;
               int tX = 0;
               int tY = 0;
               int tZ = 0;
               double range = Double.MAX_VALUE;
               float dmod = this.theGolem.getRange();
               Iterator i$2 = markers.iterator();

               while(i$2.hasNext()) {
                  IInventory te = (IInventory)i$2.next();
                  double distance = this.theGolem.getDistanceSq((double)((TileEntity)te).xCoord + 0.5D, (double)((TileEntity)te).yCoord + 0.5D, (double)((TileEntity)te).zCoord + 0.5D);
                  if(distance < range && distance <= (double)(dmod * dmod) && (((TileEntity)te).xCoord != cX || ((TileEntity)te).yCoord != cY || ((TileEntity)te).zCoord != cZ)) {
                     range = distance;
                     tX = ((TileEntity)te).xCoord;
                     tY = ((TileEntity)te).yCoord;
                     tZ = ((TileEntity)te).zCoord;
                     this.dest = new ChunkCoordinates(tX, tY, tZ);
                  }
               }

               if(this.dest != null) {
                  this.movePosX = (double)tX;
                  this.movePosY = (double)tY;
                  this.movePosZ = (double)tZ;
                  return true;
               }
            }
         }

         i$ = matchingColors.iterator();

         while(i$.hasNext()) {
            color = ((Byte)i$.next()).byteValue();
            markers = this.theGolem.getMarkers();
            Iterator i$3 = markers.iterator();

            while(i$3.hasNext()) {
               Marker marker1 = (Marker)i$3.next();
               if((marker1.color == color || color == -1) && (this.theGolem.worldObj.getTileEntity(marker1.x, marker1.y, marker1.z) == null || !(this.theGolem.worldObj.getTileEntity(marker1.x, marker1.y, marker1.z) instanceof IInventory))) {
                  this.movePosX = (double)marker1.x;
                  this.movePosY = (double)marker1.y;
                  this.movePosZ = (double)marker1.z;
                  return true;
               }
            }
         }

         return false;
      } else {
         return false;
      }
   }

   public boolean continueExecuting() {
      return this.count > 0 && !this.theGolem.getNavigator().noPath();
   }

   public void updateTask() {
      --this.count;
      if(this.count == 0 && this.prevX == MathHelper.floor_double(this.theGolem.posX) && this.prevY == MathHelper.floor_double(this.theGolem.posY) && this.prevZ == MathHelper.floor_double(this.theGolem.posZ)) {
         Vec3 var2 = RandomPositionGenerator.findRandomTarget(this.theGolem, 2, 1);
         if(var2 != null) {
            this.count = 20;
            this.theGolem.getNavigator().tryMoveToXYZ(var2.xCoord, var2.yCoord, var2.zCoord, (double)this.theGolem.getAIMoveSpeed());
         }
      }

      super.updateTask();
   }

   public void resetTask() {
      this.count = 0;
      this.dest = null;
   }

   public void startExecuting() {
      this.count = 200;
      this.prevX = MathHelper.floor_double(this.theGolem.posX);
      this.prevY = MathHelper.floor_double(this.theGolem.posY);
      this.prevZ = MathHelper.floor_double(this.theGolem.posZ);
      this.theGolem.getNavigator().tryMoveToXYZ(this.movePosX, this.movePosY, this.movePosZ, (double)this.theGolem.getAIMoveSpeed());
   }
}
