package thaumcraft.common.entities.ai.inventory;

import java.util.ArrayList;
import java.util.Iterator;
import net.minecraft.entity.ai.EntityAIBase;
import net.minecraft.inventory.IInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.ChunkCoordinates;
import net.minecraftforge.common.util.ForgeDirection;
import thaumcraft.common.config.Config;
import thaumcraft.common.entities.golems.EntityGolemBase;
import thaumcraft.common.entities.golems.GolemHelper;
import thaumcraft.common.lib.utils.InventoryUtils;

public class AIHomeTake extends EntityAIBase {
   private EntityGolemBase theGolem;
   private int countChest = 0;
   private IInventory inv;

   public AIHomeTake(EntityGolemBase par1EntityCreature) {
      this.theGolem = par1EntityCreature;
      this.setMutexBits(3);
   }

   public boolean shouldExecute() {
      ChunkCoordinates home = this.theGolem.getHomePosition();
      if(this.theGolem.getCarried() == null && this.theGolem.ticksExisted % Config.golemDelay <= 0 && this.theGolem.getNavigator().noPath() && this.theGolem.getDistanceSq((double)((float)home.posX + 0.5F), (double)((float)home.posY + 0.5F), (double)((float)home.posZ + 0.5F)) <= 5.0D) {
         ForgeDirection facing = ForgeDirection.getOrientation(this.theGolem.homeFacing);
         int cX = home.posX - facing.offsetX;
         int cY = home.posY - facing.offsetY;
         int cZ = home.posZ - facing.offsetZ;
         Object tile = this.theGolem.worldObj.getTileEntity(cX, cY, cZ);
         boolean repeat = true;
         boolean didRepeat = false;

         while(repeat) {
            if(didRepeat) {
               repeat = false;
            }

            if(tile != null && tile instanceof IInventory) {
               ArrayList neededList = GolemHelper.getItemsNeeded(this.theGolem, this.theGolem.getUpgradeAmount(5) > 0);
               ItemStack result;
               if(neededList == null) {
                  ItemStack is1;
                  do {
                     is1 = GolemHelper.getFirstItemUsingTimeout(this.theGolem, (IInventory)tile, facing.ordinal(), false);
                     if(is1 != null && GolemHelper.validTargetForItem(this.theGolem, is1)) {
                        result = GolemHelper.getFirstItemUsingTimeout(this.theGolem, (IInventory)tile, facing.ordinal(), true);
                        this.theGolem.setCarried(result);

                        try {
                           if(Config.golemChestInteract) {
                              ((IInventory)tile).openInventory();
                           }
                        } catch (Exception var16) {
                           ;
                        }

                        this.countChest = 5;
                        this.inv = (IInventory)tile;
                        return true;
                     }
                  } while(is1 != null);

                  return false;
               }

               if(neededList.size() > 0) {
                  Iterator is = neededList.iterator();

                  while(is.hasNext()) {
                     result = (ItemStack)is.next();
                     if(GolemHelper.validTargetForItem(this.theGolem, result)) {
                        ItemStack e = result.copy();
                        e.stackSize = this.theGolem.getCarrySpace();
                        ItemStack result1 = InventoryUtils.extractStack((IInventory)tile, e, facing.ordinal(), this.theGolem.checkOreDict(), this.theGolem.ignoreDamage(), this.theGolem.ignoreNBT(), true);
                        if(result1 != null) {
                           this.theGolem.setCarried(result1);

                           try {
                              if(Config.golemChestInteract) {
                                 ((IInventory)tile).openInventory();
                              }
                           } catch (Exception var15) {
                              ;
                           }

                           this.countChest = 5;
                           this.inv = (IInventory)tile;
                           return true;
                        }
                     }
                  }
               }
            }

            if(!didRepeat && InventoryUtils.getDoubleChest((TileEntity)tile) != null) {
               tile = InventoryUtils.getDoubleChest((TileEntity)tile);
               didRepeat = true;
            } else {
               repeat = false;
            }
         }

         return false;
      } else {
         return false;
      }
   }

   public boolean continueExecuting() {
      return this.countChest > 0;
   }

   public void resetTask() {
      try {
         if(this.inv != null && Config.golemChestInteract) {
            this.inv.closeInventory();
         }
      } catch (Exception var2) {
         ;
      }

   }

   public void updateTask() {
      --this.countChest;
      super.updateTask();
   }

   public void startExecuting() {
   }
}
