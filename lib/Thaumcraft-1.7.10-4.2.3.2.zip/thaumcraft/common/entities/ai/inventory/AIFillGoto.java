package thaumcraft.common.entities.ai.inventory;

import java.util.ArrayList;
import java.util.Iterator;
import net.minecraft.entity.ai.EntityAIBase;
import net.minecraft.entity.ai.RandomPositionGenerator;
import net.minecraft.inventory.IInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.ChunkCoordinates;
import net.minecraft.util.MathHelper;
import net.minecraft.util.Vec3;
import net.minecraftforge.common.util.ForgeDirection;
import net.minecraftforge.oredict.OreDictionary;
import thaumcraft.common.config.Config;
import thaumcraft.common.entities.golems.EntityGolemBase;
import thaumcraft.common.entities.golems.GolemHelper;

public class AIFillGoto extends EntityAIBase {
   private EntityGolemBase theGolem;
   private double movePosX;
   private double movePosY;
   private double movePosZ;
   private ChunkCoordinates dest = null;
   int count = 0;
   int prevX = 0;
   int prevY = 0;
   int prevZ = 0;

   public AIFillGoto(EntityGolemBase par1EntityCreature) {
      this.theGolem = par1EntityCreature;
      this.setMutexBits(3);
   }

   public boolean shouldExecute() {
      if(this.theGolem.getCarried() == null && this.theGolem.ticksExisted % Config.golemDelay <= 0 && this.theGolem.hasSomething()) {
         ArrayList mi = GolemHelper.getMissingItems(this.theGolem);
         if(mi != null && mi.size() != 0) {
            ArrayList missingItems = new ArrayList();
            Iterator results;
            ItemStack facing;
            int cZ;
            int tX;
            if(this.theGolem.getUpgradeAmount(5) > 0) {
               results = mi.iterator();

               while(results.hasNext()) {
                  facing = (ItemStack)results.next();
                  int home = OreDictionary.getOreID(facing);
                  if(home != -1) {
                     ItemStack[] cX = (ItemStack[])OreDictionary.getOres(Integer.valueOf(home)).toArray(new ItemStack[0]);
                     ItemStack[] cY = cX;
                     cZ = cX.length;

                     for(tX = 0; tX < cZ; ++tX) {
                        ItemStack tY = cY[tX];
                        missingItems.add(tY.copy());
                     }
                  } else {
                     missingItems.add(facing.copy());
                  }
               }
            } else {
               results = mi.iterator();

               while(results.hasNext()) {
                  facing = (ItemStack)results.next();
                  missingItems.add(facing.copy());
               }
            }

            ArrayList var20 = new ArrayList();
            Iterator var21 = missingItems.iterator();

            while(var21.hasNext()) {
               ItemStack var23 = (ItemStack)var21.next();
               this.theGolem.itemWatched = var23.copy();
               ArrayList var25 = this.theGolem.getColorsMatching(this.theGolem.itemWatched);

               byte var29;
               for(Iterator var27 = var25.iterator(); var27.hasNext(); var20 = GolemHelper.getContainersWithGoods(this.theGolem.worldObj, this.theGolem, this.theGolem.itemWatched, var29)) {
                  var29 = ((Byte)var27.next()).byteValue();
               }

               if(var20.size() > 0) {
                  break;
               }
            }

            if(var20 != null && var20.size() != 0) {
               ForgeDirection var22 = ForgeDirection.getOrientation(this.theGolem.homeFacing);
               ChunkCoordinates var24 = this.theGolem.getHomePosition();
               int var26 = var24.posX - var22.offsetX;
               int var28 = var24.posY - var22.offsetY;
               cZ = var24.posZ - var22.offsetZ;
               tX = 0;
               int var30 = 0;
               int tZ = 0;
               double range = Double.MAX_VALUE;
               float dmod = this.theGolem.getRange();
               Iterator i$ = var20.iterator();

               while(i$.hasNext()) {
                  IInventory i = (IInventory)i$.next();
                  TileEntity te = (TileEntity)i;
                  double distance = this.theGolem.getDistanceSq((double)te.xCoord + 0.5D, (double)te.yCoord + 0.5D, (double)te.zCoord + 0.5D);
                  if(distance < range && distance <= (double)(dmod * dmod) && (te.xCoord != var26 || te.yCoord != var28 || te.zCoord != cZ)) {
                     range = distance;
                     tX = te.xCoord;
                     var30 = te.yCoord;
                     tZ = te.zCoord;
                     this.dest = new ChunkCoordinates(tX, var30, tZ);
                  }
               }

               if(this.dest != null) {
                  this.movePosX = (double)tX;
                  this.movePosY = (double)var30;
                  this.movePosZ = (double)tZ;
                  return true;
               } else {
                  return false;
               }
            } else {
               return false;
            }
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   public boolean continueExecuting() {
      return this.count > 0 && !this.theGolem.getNavigator().noPath();
   }

   public void updateTask() {
      --this.count;
      if(this.count == 0 && this.prevX == MathHelper.floor_double(this.theGolem.posX) && this.prevY == MathHelper.floor_double(this.theGolem.posY) && this.prevZ == MathHelper.floor_double(this.theGolem.posZ)) {
         Vec3 var2 = RandomPositionGenerator.findRandomTarget(this.theGolem, 2, 1);
         if(var2 != null) {
            this.count = 20;
            this.theGolem.getNavigator().tryMoveToXYZ(var2.xCoord, var2.yCoord, var2.zCoord, (double)this.theGolem.getAIMoveSpeed());
         }
      }

      super.updateTask();
   }

   public void resetTask() {
      this.dest = null;
      this.count = 0;
   }

   public void startExecuting() {
      this.count = 200;
      this.prevX = MathHelper.floor_double(this.theGolem.posX);
      this.prevY = MathHelper.floor_double(this.theGolem.posY);
      this.prevZ = MathHelper.floor_double(this.theGolem.posZ);
      this.theGolem.getNavigator().tryMoveToXYZ(this.movePosX, this.movePosY, this.movePosZ, (double)this.theGolem.getAIMoveSpeed());
   }
}
