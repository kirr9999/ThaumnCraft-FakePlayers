package thaumcraft.common.entities.ai.inventory;

import java.util.ArrayList;
import java.util.Iterator;
import net.minecraft.entity.ai.EntityAIBase;
import net.minecraft.inventory.IInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.ChunkCoordinates;
import net.minecraftforge.common.util.ForgeDirection;
import thaumcraft.common.config.Config;
import thaumcraft.common.entities.golems.EntityGolemBase;
import thaumcraft.common.entities.golems.GolemHelper;
import thaumcraft.common.lib.utils.InventoryUtils;

public class AIEmptyPlace extends EntityAIBase {
   private EntityGolemBase theGolem;
   private int countChest = 0;
   private IInventory inv;
   private int xx;
   private int yy;
   private int zz;
   int count = 0;

   public AIEmptyPlace(EntityGolemBase par1EntityCreature) {
      this.theGolem = par1EntityCreature;
      this.setMutexBits(3);
   }

   public boolean shouldExecute() {
      if(this.theGolem.itemCarried != null && this.theGolem.getNavigator().noPath()) {
         ChunkCoordinates home = this.theGolem.getHomePosition();
         ForgeDirection facing = ForgeDirection.getOrientation(this.theGolem.homeFacing);
         int cX = home.posX - facing.offsetX;
         int cY = home.posY - facing.offsetY;
         int cZ = home.posZ - facing.offsetZ;
         ArrayList mc = GolemHelper.getMarkedContainersAdjacentToGolem(this.theGolem.worldObj, this.theGolem);
         Iterator i$ = mc.iterator();

         while(i$.hasNext()) {
            IInventory te = (IInventory)i$.next();
            TileEntity tile = (TileEntity)te;
            if(tile != null && (tile.xCoord != cX || tile.yCoord != cY || tile.zCoord != cZ)) {
               ArrayList matchingColors = this.theGolem.getColorsMatching(this.theGolem.itemCarried);
               Iterator i$1 = matchingColors.iterator();

               label50:
               while(i$1.hasNext()) {
                  byte color = ((Byte)i$1.next()).byteValue();
                  Iterator i$2 = GolemHelper.getMarkedSides(this.theGolem, tile, color).iterator();

                  ItemStack is;
                  do {
                     Integer side;
                     if(!i$2.hasNext()) {
                        if(InventoryUtils.getDoubleChest(tile) == null) {
                           continue label50;
                        }

                        i$2 = GolemHelper.getMarkedSides(this.theGolem, tile, color).iterator();

                        do {
                           if(!i$2.hasNext()) {
                              continue label50;
                           }

                           side = (Integer)i$2.next();
                           is = InventoryUtils.placeItemStackIntoInventory(this.theGolem.itemCarried, InventoryUtils.getDoubleChest(tile), side.intValue(), false);
                        } while(!ItemStack.areItemStacksEqual(is, this.theGolem.itemCarried));

                        this.xx = tile.xCoord;
                        this.yy = tile.yCoord;
                        this.zz = tile.zCoord;
                        return true;
                     }

                     side = (Integer)i$2.next();
                     is = InventoryUtils.placeItemStackIntoInventory(this.theGolem.itemCarried, te, side.intValue(), false);
                  } while(ItemStack.areItemStacksEqual(is, this.theGolem.itemCarried));

                  this.xx = tile.xCoord;
                  this.yy = tile.yCoord;
                  this.zz = tile.zCoord;
                  return true;
               }
            }
         }

         return false;
      } else {
         return false;
      }
   }

   public boolean continueExecuting() {
      return this.count > 0 && (this.shouldExecute() || this.countChest > 0);
   }

   public void resetTask() {
      try {
         if(this.inv != null && Config.golemChestInteract) {
            this.inv.closeInventory();
         }
      } catch (Exception var2) {
         ;
      }

   }

   public void updateTask() {
      --this.countChest;
      --this.count;
      super.updateTask();
   }

   public void startExecuting() {
      this.count = 200;
      ChunkCoordinates home = this.theGolem.getHomePosition();
      ForgeDirection facing = ForgeDirection.getOrientation(this.theGolem.homeFacing);
      int cX = home.posX - facing.offsetX;
      int cY = home.posY - facing.offsetY;
      int cZ = home.posZ - facing.offsetZ;
      TileEntity tile = this.theGolem.worldObj.getTileEntity(this.xx, this.yy, this.zz);
      if(tile != null && (tile.xCoord != cX || tile.yCoord != cY || tile.zCoord != cZ)) {
         IInventory te = (IInventory)tile;
         ArrayList matchingColors = this.theGolem.getColorsMatching(this.theGolem.itemCarried);
         Iterator i$ = matchingColors.iterator();

         while(i$.hasNext()) {
            byte color = ((Byte)i$.next()).byteValue();
            Iterator e = GolemHelper.getMarkedSides(this.theGolem, tile, color).iterator();

            Integer side;
            while(e.hasNext()) {
               side = (Integer)e.next();
               this.theGolem.itemCarried = InventoryUtils.placeItemStackIntoInventory(this.theGolem.itemCarried, te, side.intValue(), true);
               this.countChest = 5;
               this.inv = (IInventory)tile;
               if(this.theGolem.itemCarried == null) {
                  break;
               }
            }

            if(InventoryUtils.getDoubleChest(tile) != null && this.theGolem.itemCarried != null) {
               e = GolemHelper.getMarkedSides(this.theGolem, tile, color).iterator();

               while(e.hasNext()) {
                  side = (Integer)e.next();
                  ItemStack is = InventoryUtils.placeItemStackIntoInventory(this.theGolem.itemCarried, InventoryUtils.getDoubleChest(tile), side.intValue(), false);
                  if(!ItemStack.areItemStacksEqual(is, this.theGolem.itemCarried)) {
                     this.theGolem.itemCarried = InventoryUtils.placeItemStackIntoInventory(this.theGolem.itemCarried, InventoryUtils.getDoubleChest(tile), side.intValue(), true);
                     this.countChest = 5;
                     this.inv = InventoryUtils.getDoubleChest(tile);
                     if(this.theGolem.itemCarried == null) {
                        break;
                     }
                  }
               }
            }

            if(this.countChest == 5) {
               try {
                  if(Config.golemChestInteract) {
                     ((IInventory)tile).openInventory();
                  }
               } catch (Exception var14) {
                  ;
               }
               break;
            }
         }
      }

      this.theGolem.updateCarried();
   }
}
