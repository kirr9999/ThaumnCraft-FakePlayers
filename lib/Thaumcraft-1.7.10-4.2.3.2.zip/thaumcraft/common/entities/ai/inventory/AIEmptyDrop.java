package thaumcraft.common.entities.ai.inventory;

import java.util.ArrayList;
import java.util.Iterator;
import net.minecraft.entity.ai.EntityAIBase;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.util.ChunkCoordinates;
import thaumcraft.common.entities.golems.EntityGolemBase;
import thaumcraft.common.entities.golems.GolemHelper;

public class AIEmptyDrop extends EntityAIBase {
   private EntityGolemBase theGolem;
   int count = 0;

   public AIEmptyDrop(EntityGolemBase par1EntityCreature) {
      this.theGolem = par1EntityCreature;
      this.setMutexBits(3);
   }

   public boolean shouldExecute() {
      if(this.theGolem.itemCarried != null && this.theGolem.getNavigator().noPath()) {
         ChunkCoordinates home = this.theGolem.getHomePosition();
         ArrayList matchingColors = this.theGolem.getColorsMatching(this.theGolem.itemCarried);
         Iterator i$ = matchingColors.iterator();

         while(i$.hasNext()) {
            byte color = ((Byte)i$.next()).byteValue();
            ArrayList mc = GolemHelper.getMarkedBlocksAdjacentToGolem(this.theGolem.worldObj, this.theGolem, color);
            Iterator i$1 = mc.iterator();

            while(i$1.hasNext()) {
               ChunkCoordinates cc = (ChunkCoordinates)i$1.next();
               if(cc != home) {
                  return true;
               }
            }
         }

         return false;
      } else {
         return false;
      }
   }

   public boolean continueExecuting() {
      return this.count > 0 && this.shouldExecute();
   }

   public void resetTask() {
   }

   public void updateTask() {
      --this.count;
      super.updateTask();
   }

   public void startExecuting() {
      this.count = 200;
      ChunkCoordinates home = this.theGolem.getHomePosition();
      ArrayList matchingColors = this.theGolem.getColorsMatching(this.theGolem.itemCarried);
      Iterator i$ = matchingColors.iterator();

      label24:
      while(i$.hasNext()) {
         byte color = ((Byte)i$.next()).byteValue();
         ArrayList mc = GolemHelper.getMarkedBlocksAdjacentToGolem(this.theGolem.worldObj, this.theGolem, color);
         Iterator i$1 = mc.iterator();

         while(i$1.hasNext()) {
            ChunkCoordinates cc = (ChunkCoordinates)i$1.next();
            if(cc != home) {
               EntityItem item = new EntityItem(this.theGolem.worldObj, this.theGolem.posX, this.theGolem.posY + (double)(this.theGolem.height / 2.0F), this.theGolem.posZ, this.theGolem.itemCarried.copy());
               if(item != null) {
                  double distance = this.theGolem.getDistance((double)cc.posX + 0.5D, (double)cc.posY + 0.5D, (double)cc.posZ + 0.5D);
                  item.motionX = ((double)cc.posX + 0.5D - this.theGolem.posX) * (distance / 3.0D);
                  item.motionY = 0.1D + ((double)cc.posY + 0.5D - (this.theGolem.posY + (double)(this.theGolem.height / 2.0F))) * (distance / 3.0D);
                  item.motionZ = ((double)cc.posZ + 0.5D - this.theGolem.posZ) * (distance / 3.0D);
                  item.delayBeforeCanPickup = 10;
                  this.theGolem.worldObj.spawnEntityInWorld(item);
                  this.theGolem.itemCarried = null;
                  this.theGolem.startActionTimer();
                  break label24;
               }
            }
         }
      }

      this.theGolem.updateCarried();
   }
}
