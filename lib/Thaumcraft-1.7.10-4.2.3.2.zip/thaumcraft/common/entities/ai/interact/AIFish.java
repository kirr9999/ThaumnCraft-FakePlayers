package thaumcraft.common.entities.ai.interact;

import java.util.Arrays;
import java.util.List;
import java.util.Random;
import net.minecraft.block.material.Material;
import net.minecraft.entity.ai.EntityAIBase;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemFishFood.FishType;
import net.minecraft.item.crafting.FurnaceRecipes;
import net.minecraft.util.MathHelper;
import net.minecraft.util.Vec3;
import net.minecraft.util.WeightedRandom;
import net.minecraft.util.WeightedRandomFishable;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;
import net.minecraftforge.common.util.ForgeDirection;
import thaumcraft.common.config.Config;
import thaumcraft.common.entities.golems.EntityGolemBase;
import thaumcraft.common.entities.golems.EntityGolemBobber;

public class AIFish extends EntityAIBase {
   private EntityGolemBase theGolem;
   private float quality;
   private float distance;
   private World theWorld;
   private int maxDelay = 1;
   private int mod = 1;
   private int count = 0;
   private Vec3 target = null;
   private EntityGolemBobber bobber = null;
   private static final List LOOTCRAP;
   private static final List LOOTRARE;
   private static final List LOOTFISH;

   public AIFish(EntityGolemBase par1EntityCreature) {
      this.theGolem = par1EntityCreature;
      this.theWorld = par1EntityCreature.worldObj;
      this.setMutexBits(3);
      this.distance = (float)MathHelper.ceiling_float_int(this.theGolem.getRange() / 2.0F);
   }

   public boolean shouldExecute() {
      if(this.target == null && this.count <= 0 && this.theGolem.ticksExisted % Config.golemDelay <= 0 && this.theGolem.getNavigator().noPath()) {
         if(this.bobber != null) {
            this.bobber.setDead();
         }

         Vec3 vv = this.findWater();
         if(vv == null) {
            return false;
         } else {
            this.target = Vec3.createVectorHelper(vv.xCoord, vv.yCoord, vv.zCoord);
            this.quality = 0.0F;
            int x = (int)this.target.xCoord;
            int y = (int)this.target.yCoord;
            int z = (int)this.target.zCoord;

            for(int a = 2; a <= 5; ++a) {
               ForgeDirection dir = ForgeDirection.getOrientation(a);
               if(this.theWorld.getBlock(x + dir.offsetX, y + dir.offsetY, z + dir.offsetZ).getMaterial() == Material.water && this.theWorld.isAirBlock(x + dir.offsetX, y + 1 + dir.offsetY, z + dir.offsetZ)) {
                  this.quality += 3.0E-5F;
                  if(this.theWorld.canBlockSeeTheSky(x + dir.offsetX, y + 1 + dir.offsetY, z + dir.offsetZ)) {
                     this.quality += 3.0E-5F;
                  }

                  for(int depth = 1; depth <= 3; ++depth) {
                     if(this.theWorld.getBlock(x + dir.offsetX, y - depth + dir.offsetY, z + dir.offsetZ).getMaterial() == Material.water) {
                        this.quality += 1.5E-5F;
                     }
                  }
               }
            }

            this.theWorld.playSoundAtEntity(this.theGolem, "random.bow", 0.5F, 0.4F / (this.theWorld.rand.nextFloat() * 0.4F + 0.8F));
            this.bobber = new EntityGolemBobber(this.theWorld, this.theGolem, x, y, z);
            return this.theWorld.spawnEntityInWorld(this.bobber);
         }
      } else {
         return false;
      }
   }

   public boolean continueExecuting() {
      return this.bobber != null && !this.bobber.isDead && this.target != null && this.count-- > 0;
   }

   public void updateTask() {
      if(this.target != null) {
         this.theGolem.getLookHelper().setLookPosition(this.target.xCoord + 0.5D, this.target.yCoord + 1.0D, this.target.zCoord + 0.5D, 30.0F, 30.0F);
         float chance = this.quality + (float)this.theGolem.getGolemStrength() * 1.5E-4F;
         if(this.theWorld.rand.nextFloat() < chance) {
            this.theGolem.startRightArmTimer();
            int qq = 1;
            if(this.theGolem.getUpgradeAmount(0) > 0 && this.theWorld.rand.nextInt(10) < this.theGolem.getUpgradeAmount(0)) {
               ++qq;
            }

            for(int a = 0; a < qq; ++a) {
               ItemStack fs = this.getFishingResult();
               if(this.theGolem.getUpgradeAmount(2) > 0) {
                  ItemStack entityitem = FurnaceRecipes.smelting().getSmeltingResult(fs);
                  if(entityitem != null) {
                     fs = entityitem.copy();
                  }
               }

               EntityItem var16 = new EntityItem(this.theWorld, this.target.xCoord + 0.5D, this.target.yCoord + 1.0D, this.target.zCoord + 0.5D, fs);
               if(this.theGolem.getUpgradeAmount(2) > 0) {
                  var16.setFire(2);
               }

               var16.delayBeforeCanPickup = 20;
               double d1 = this.theGolem.posX + (double)this.theWorld.rand.nextFloat() - (double)this.theWorld.rand.nextFloat() - this.target.xCoord + 0.5D;
               double d3 = this.theGolem.posY - this.target.yCoord + 1.0D;
               double d5 = this.theGolem.posZ + (double)this.theWorld.rand.nextFloat() - (double)this.theWorld.rand.nextFloat() - this.target.zCoord + 0.5D;
               double d7 = (double)MathHelper.sqrt_double(d1 * d1 + d3 * d3 + d5 * d5);
               double d9 = 0.1D;
               var16.motionX = d1 * d9;
               var16.motionY = d3 * d9 + (double)MathHelper.sqrt_double(d7) * 0.08D;
               var16.motionZ = d5 * d9;
               this.theWorld.spawnEntityInWorld(var16);
            }

            if(this.bobber != null) {
               this.bobber.playSound("random.splash", 0.15F, 1.0F + (this.theWorld.rand.nextFloat() - this.theWorld.rand.nextFloat()) * 0.4F);
               ((WorldServer)this.theWorld).func_147487_a("splash", this.bobber.posX, this.bobber.posY + 0.5D, this.bobber.posZ, 20 + this.theWorld.rand.nextInt(20), 0.10000000149011612D, 0.0D, 0.10000000149011612D, 0.0D);
               this.bobber.setDead();
            }

            this.target = null;
         }
      }

   }

   public void resetTask() {
      if(this.bobber != null) {
         this.bobber.setDead();
      }

      this.target = null;
      this.count = -1;
   }

   public void startExecuting() {
      this.count = 300 + this.theWorld.rand.nextInt(200);
      this.theGolem.startRightArmTimer();
   }

   private Vec3 findWater() {
      Random rand = this.theGolem.getRNG();

      for(int var2 = 0; (float)var2 < this.distance * 2.0F; ++var2) {
         int x = (int)((float)(this.theGolem.getHomePosition().posX + rand.nextInt((int)(1.0F + this.distance * 2.0F))) - this.distance);
         int y = (int)((float)(this.theGolem.getHomePosition().posY + rand.nextInt((int)(1.0F + this.distance))) - this.distance / 2.0F);
         int z = (int)((float)(this.theGolem.getHomePosition().posZ + rand.nextInt((int)(1.0F + this.distance * 2.0F))) - this.distance);
         if(this.theWorld.getBlock(x, y, z).getMaterial() == Material.water && this.theWorld.isAirBlock(x, y + 1, z)) {
            Vec3 v = Vec3.createVectorHelper((double)x, (double)y, (double)z);
            return v;
         }
      }

      return null;
   }

   private ItemStack getFishingResult() {
      float f = this.theWorld.rand.nextFloat();
      float f1 = 0.1F - (float)this.theGolem.getUpgradeAmount(5) * 0.025F;
      float f2 = 0.05F + (float)this.theGolem.getUpgradeAmount(4) * 0.0125F;
      int x = (int)this.target.xCoord;
      int y = (int)this.target.yCoord;
      int z = (int)this.target.zCoord;

      for(int f3 = 2; f3 <= 5; ++f3) {
         ForgeDirection dir = ForgeDirection.getOrientation(f3);
         if(this.theWorld.getBlock(x + dir.offsetX, y + dir.offsetY, z + dir.offsetZ).getMaterial() == Material.water && this.theWorld.isAirBlock(x + dir.offsetX, y + 1 + dir.offsetY, z + dir.offsetZ)) {
            f1 -= 0.005F;
            f2 += 0.00125F;
            if(this.theWorld.canBlockSeeTheSky(x + dir.offsetX, y + 1 + dir.offsetY, z + dir.offsetZ)) {
               f1 -= 0.005F;
               f2 += 0.00125F;
            }

            for(int depth = 1; depth <= 3; ++depth) {
               if(this.theWorld.getBlock(x + dir.offsetX, y - depth + dir.offsetY, z + dir.offsetZ).getMaterial() == Material.water) {
                  f2 += 0.001F;
               }
            }
         }
      }

      f1 = MathHelper.clamp_float(f1, 0.0F, 1.0F);
      f2 = MathHelper.clamp_float(f2, 0.0F, 1.0F);
      if(f < f1) {
         return ((WeightedRandomFishable)WeightedRandom.getRandomItem(this.theWorld.rand, LOOTCRAP)).func_150708_a(this.theWorld.rand);
      } else {
         f -= f1;
         if(f < f2) {
            return ((WeightedRandomFishable)WeightedRandom.getRandomItem(this.theWorld.rand, LOOTRARE)).func_150708_a(this.theWorld.rand);
         } else {
            float var10000 = f - f2;
            return ((WeightedRandomFishable)WeightedRandom.getRandomItem(this.theWorld.rand, LOOTFISH)).func_150708_a(this.theWorld.rand);
         }
      }
   }

   static {
      LOOTCRAP = Arrays.asList(new WeightedRandomFishable[]{(new WeightedRandomFishable(new ItemStack(Items.leather_boots), 10)).func_150709_a(0.9F), new WeightedRandomFishable(new ItemStack(Items.leather), 10), new WeightedRandomFishable(new ItemStack(Items.bone), 10), new WeightedRandomFishable(new ItemStack(Items.potionitem), 10), new WeightedRandomFishable(new ItemStack(Items.string), 5), (new WeightedRandomFishable(new ItemStack(Items.fishing_rod), 2)).func_150709_a(0.9F), new WeightedRandomFishable(new ItemStack(Items.bowl), 10), new WeightedRandomFishable(new ItemStack(Items.stick), 5), new WeightedRandomFishable(new ItemStack(Items.dye, 10, 0), 5), new WeightedRandomFishable(new ItemStack(Blocks.tripwire_hook), 10), new WeightedRandomFishable(new ItemStack(Items.rotten_flesh), 10)});
      LOOTRARE = Arrays.asList(new WeightedRandomFishable[]{new WeightedRandomFishable(new ItemStack(Blocks.waterlily), 1), new WeightedRandomFishable(new ItemStack(Items.name_tag), 1), new WeightedRandomFishable(new ItemStack(Items.saddle), 1), (new WeightedRandomFishable(new ItemStack(Items.bow), 1)).func_150709_a(0.25F).func_150707_a(), (new WeightedRandomFishable(new ItemStack(Items.fishing_rod), 1)).func_150709_a(0.25F).func_150707_a(), (new WeightedRandomFishable(new ItemStack(Items.book), 1)).func_150707_a()});
      LOOTFISH = Arrays.asList(new WeightedRandomFishable[]{new WeightedRandomFishable(new ItemStack(Items.fish, 1, FishType.COD.func_150976_a()), 60), new WeightedRandomFishable(new ItemStack(Items.fish, 1, FishType.SALMON.func_150976_a()), 25), new WeightedRandomFishable(new ItemStack(Items.fish, 1, FishType.CLOWNFISH.func_150976_a()), 2), new WeightedRandomFishable(new ItemStack(Items.fish, 1, FishType.PUFFERFISH.func_150976_a()), 13)});
   }
}
