package thaumcraft.common.entities;

import cpw.mods.fml.common.registry.IEntityAdditionalSpawnData;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import io.netty.buffer.ByteBuf;
import java.util.Iterator;
import java.util.List;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.DamageSource;
import net.minecraft.util.MathHelper;
import net.minecraft.world.World;
import thaumcraft.api.aspects.Aspect;
import thaumcraft.common.items.wands.ItemWandCasting;
import thaumcraft.common.lib.utils.InventoryUtils;

public class EntityAspectOrb extends Entity implements IEntityAdditionalSpawnData {
   public int orbAge = 0;
   public int orbMaxAge = 150;
   public int orbCooldown;
   private int orbHealth = 5;
   private Aspect aspect;
   private int aspectValue;
   private EntityPlayer closestPlayer;

   public boolean isInRangeToRenderDist(double par1) {
      double d1 = 0.5D;
      d1 *= 64.0D * this.renderDistanceWeight;
      return par1 < d1 * d1;
   }

   public EntityAspectOrb(World par1World, double par2, double par4, double par6, Aspect aspect, int par8) {
      super(par1World);
      this.setSize(0.125F, 0.125F);
      this.yOffset = this.height / 2.0F;
      this.setPosition(par2, par4, par6);
      this.rotationYaw = (float)(Math.random() * 360.0D);
      this.motionX = (double)((float)(Math.random() * 0.20000000298023224D - 0.10000000149011612D) * 2.0F);
      this.motionY = (double)((float)(Math.random() * 0.2D) * 2.0F);
      this.motionZ = (double)((float)(Math.random() * 0.20000000298023224D - 0.10000000149011612D) * 2.0F);
      this.aspectValue = par8;
      this.setAspect(aspect);
   }

   protected boolean canTriggerWalking() {
      return false;
   }

   public EntityAspectOrb(World par1World) {
      super(par1World);
      this.setSize(0.125F, 0.125F);
      this.yOffset = this.height / 2.0F;
   }

   protected void entityInit() {
   }

   @SideOnly(Side.CLIENT)
   public int getBrightnessForRender(float par1) {
      float f1 = 0.5F;
      if(f1 < 0.0F) {
         f1 = 0.0F;
      }

      if(f1 > 1.0F) {
         f1 = 1.0F;
      }

      int i = super.getBrightnessForRender(par1);
      int j = i & 255;
      int k = i >> 16 & 255;
      j += (int)(f1 * 15.0F * 16.0F);
      if(j > 240) {
         j = 240;
      }

      return j | k << 16;
   }

   public void onUpdate() {
      super.onUpdate();
      if(this.orbCooldown > 0) {
         --this.orbCooldown;
      }

      this.prevPosX = this.posX;
      this.prevPosY = this.posY;
      this.prevPosZ = this.posZ;
      this.motionY -= 0.029999999329447746D;
      if(this.worldObj.getBlock(MathHelper.floor_double(this.posX), MathHelper.floor_double(this.posY), MathHelper.floor_double(this.posZ)).getMaterial() == Material.lava) {
         this.motionY = 0.20000000298023224D;
         this.motionX = (double)((this.rand.nextFloat() - this.rand.nextFloat()) * 0.2F);
         this.motionZ = (double)((this.rand.nextFloat() - this.rand.nextFloat()) * 0.2F);
         this.playSound("random.fizz", 0.4F, 2.0F + this.rand.nextFloat() * 0.4F);
      }

      this.func_145771_j(this.posX, (this.boundingBox.minY + this.boundingBox.maxY) / 2.0D, this.posZ);
      double d0 = 8.0D;
      if(this.ticksExisted % 5 == 0 && this.closestPlayer == null) {
         List f = this.worldObj.getEntitiesWithinAABB(EntityPlayer.class, AxisAlignedBB.getBoundingBox(this.posX, this.posY, this.posZ, this.posX, this.posY, this.posZ).expand(d0, d0, d0));
         if(f.size() > 0) {
            double i = Double.MAX_VALUE;
            Iterator i$ = f.iterator();

            while(i$.hasNext()) {
               Entity d3 = (Entity)i$.next();
               double d = ((EntityPlayer)d3).getDistanceSqToEntity(this);
               if(d < i && InventoryUtils.isWandInHotbarWithRoom(this.getAspect(), this.aspectValue, (EntityPlayer)d3) >= 0) {
                  i = d;
                  this.closestPlayer = (EntityPlayer)d3;
               }
            }
         }
      }

      if(this.closestPlayer != null) {
         double var13 = (this.closestPlayer.posX - this.posX) / d0;
         double d2 = (this.closestPlayer.posY + (double)this.closestPlayer.getEyeHeight() - this.posY) / d0;
         double var16 = (this.closestPlayer.posZ - this.posZ) / d0;
         double d4 = Math.sqrt(var13 * var13 + d2 * d2 + var16 * var16);
         double d5 = 1.0D - d4;
         if(d5 > 0.0D) {
            d5 *= d5;
            this.motionX += var13 / d4 * d5 * 0.1D;
            this.motionY += d2 / d4 * d5 * 0.1D;
            this.motionZ += var16 / d4 * d5 * 0.1D;
         }
      }

      this.moveEntity(this.motionX, this.motionY, this.motionZ);
      float var14 = 0.98F;
      if(this.onGround) {
         var14 = 0.58800006F;
         Block var15 = this.worldObj.getBlock(MathHelper.floor_double(this.posX), MathHelper.floor_double(this.boundingBox.minY) - 1, MathHelper.floor_double(this.posZ));
         if(!var15.isAir(this.worldObj, MathHelper.floor_double(this.posX), MathHelper.floor_double(this.boundingBox.minY) - 1, MathHelper.floor_double(this.posZ))) {
            var14 = var15.slipperiness * 0.98F;
         }
      }

      this.motionX *= (double)var14;
      this.motionY *= 0.9800000190734863D;
      this.motionZ *= (double)var14;
      if(this.onGround) {
         this.motionY *= -0.8999999761581421D;
      }

      ++this.orbAge;
      if(this.orbAge >= this.orbMaxAge) {
         this.setDead();
      }

   }

   public boolean handleWaterMovement() {
      return this.worldObj.handleMaterialAcceleration(this.boundingBox, Material.water, this);
   }

   protected void dealFireDamage(int par1) {
      this.attackEntityFrom(DamageSource.inFire, (float)par1);
   }

   public boolean attackEntityFrom(DamageSource par1DamageSource, float par2) {
      if(this.isEntityInvulnerable()) {
         return false;
      } else {
         this.setBeenAttacked();
         this.orbHealth = (int)((float)this.orbHealth - par2);
         if(this.orbHealth <= 0) {
            this.setDead();
         }

         return false;
      }
   }

   public void writeEntityToNBT(NBTTagCompound par1NBTTagCompound) {
      par1NBTTagCompound.setShort("Health", (short)((byte)this.orbHealth));
      par1NBTTagCompound.setShort("Age", (short)this.orbAge);
      par1NBTTagCompound.setShort("Value", (short)this.aspectValue);
      par1NBTTagCompound.setString("Aspect", this.getAspect().getTag());
   }

   public void readEntityFromNBT(NBTTagCompound par1NBTTagCompound) {
      this.orbHealth = par1NBTTagCompound.getShort("Health") & 255;
      this.orbAge = par1NBTTagCompound.getShort("Age");
      this.aspectValue = par1NBTTagCompound.getShort("Value");
      this.setAspect(Aspect.getAspect(par1NBTTagCompound.getString("Aspect")));
   }

   public void onCollideWithPlayer(EntityPlayer par1EntityPlayer) {
      if(!this.worldObj.isRemote) {
         int slot = InventoryUtils.isWandInHotbarWithRoom(this.getAspect(), this.aspectValue, par1EntityPlayer);
         if(this.orbCooldown == 0 && par1EntityPlayer.xpCooldown == 0 && this.getAspect().isPrimal() && slot >= 0) {
            ItemWandCasting wand = (ItemWandCasting)par1EntityPlayer.inventory.mainInventory[slot].getItem();
            wand.addVis(par1EntityPlayer.inventory.mainInventory[slot], this.getAspect(), this.aspectValue, true);
            par1EntityPlayer.xpCooldown = 2;
            this.playSound("random.orb", 0.1F, 0.5F * ((this.rand.nextFloat() - this.rand.nextFloat()) * 0.7F + 1.8F));
            this.setDead();
         }
      }

   }

   public void writeSpawnData(ByteBuf data) {
      if(this.getAspect() != null) {
         data.writeShort(this.getAspect().getTag().length());
         char[] arr$ = this.getAspect().getTag().toCharArray();
         int len$ = arr$.length;

         for(int i$ = 0; i$ < len$; ++i$) {
            char c = arr$[i$];
            data.writeChar(c);
         }
      }

   }

   public void readSpawnData(ByteBuf data) {
      try {
         short e = data.readShort();
         StringBuilder s = new StringBuilder();

         for(int var4 = 0; var4 < e; ++var4) {
            s.append(data.readChar());
         }

         this.setAspect(Aspect.getAspect(s.toString()));
      } catch (Exception var5) {
         ;
      }

   }

   public int getAspectValue() {
      return this.aspectValue;
   }

   public boolean canAttackWithItem() {
      return false;
   }

   public Aspect getAspect() {
      return this.aspect;
   }

   public void setAspect(Aspect aspect) {
      this.aspect = aspect;
   }
}
