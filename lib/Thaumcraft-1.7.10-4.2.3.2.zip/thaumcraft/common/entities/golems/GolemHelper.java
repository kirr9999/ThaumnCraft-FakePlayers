package thaumcraft.common.entities.golems;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import net.minecraft.block.Block;
import net.minecraft.inventory.IInventory;
import net.minecraft.inventory.ISidedInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.ChunkCoordinates;
import net.minecraft.util.Vec3;
import net.minecraft.world.World;
import net.minecraftforge.common.util.ForgeDirection;
import net.minecraftforge.fluids.BlockFluidBase;
import net.minecraftforge.fluids.FluidContainerRegistry;
import net.minecraftforge.fluids.FluidRegistry;
import net.minecraftforge.fluids.FluidStack;
import net.minecraftforge.fluids.IFluidHandler;
import thaumcraft.api.aspects.IEssentiaTransport;
import thaumcraft.common.config.Config;
import thaumcraft.common.entities.golems.EntityGolemBase;
import thaumcraft.common.entities.golems.Marker;
import thaumcraft.common.lib.utils.InventoryUtils;
import thaumcraft.common.tiles.TileEssentiaReservoir;
import thaumcraft.common.tiles.TileJarFillable;
import thaumcraft.common.tiles.TileJarFillableVoid;

public class GolemHelper {
   public static final double ADJACENT_RANGE = 4.0D;
   static HashMap<String, TileJarFillable> jarlist = new HashMap();
   private static ArrayList<Integer> reggedLiquids = null;
   static ArrayList<GolemHelper.SortingItemTimeout> itemTimeout = new ArrayList();

   public static ArrayList<IInventory> getMarkedContainers(World world, EntityGolemBase golem) {
      ArrayList results = new ArrayList();
      Iterator i$ = golem.getMarkers().iterator();

      while(i$.hasNext()) {
         Marker marker = (Marker)i$.next();
         TileEntity te = world.getTileEntity(marker.x, marker.y, marker.z);
         if(marker.dim == world.provider.dimensionId && te != null && te instanceof IInventory) {
            results.add((IInventory)te);
            if(InventoryUtils.getDoubleChest(te) != null) {
               results.add(InventoryUtils.getDoubleChest(te));
            }
         }
      }

      return results;
   }

   public static ArrayList<IInventory> getMarkedContainersAdjacentToGolem(World world, EntityGolemBase golem) {
      ArrayList results = new ArrayList();
      Iterator i$ = getMarkedContainers(world, golem).iterator();

      while(i$.hasNext()) {
         IInventory inventory = (IInventory)i$.next();
         TileEntity te = (TileEntity)inventory;
         if(golem.getDistanceSq((double)te.xCoord + 0.5D, (double)te.yCoord + 0.5D, (double)te.zCoord + 0.5D) < 4.0D) {
            results.add(inventory);
            if(InventoryUtils.getDoubleChest(te) != null) {
               results.add(InventoryUtils.getDoubleChest(te));
            }
         }
      }

      return results;
   }

   public static ArrayList<ChunkCoordinates> getMarkedBlocksAdjacentToGolem(World world, EntityGolemBase golem, byte color) {
      ArrayList results = new ArrayList();
      ArrayList markers = golem.getMarkers();
      Iterator i$ = markers.iterator();

      while(i$.hasNext()) {
         Marker marker = (Marker)i$.next();
         if((marker.color == color || color == -1) && (golem.worldObj.getTileEntity(marker.x, marker.y, marker.z) == null || !(golem.worldObj.getTileEntity(marker.x, marker.y, marker.z) instanceof IInventory)) && golem.getDistanceSq((double)marker.x + 0.5D, (double)marker.y + 0.5D, (double)marker.z + 0.5D) < 4.0D) {
            results.add(new ChunkCoordinates(marker.x, marker.y, marker.z));
         }
      }

      return results;
   }

   public static ArrayList<IInventory> getContainersWithRoom(World world, EntityGolemBase golem, byte color) {
      ArrayList results = new ArrayList();
      Iterator i$ = getMarkedContainers(world, golem).iterator();

      while(i$.hasNext()) {
         IInventory inventory = (IInventory)i$.next();
         boolean hasRoom = false;
         Iterator i$1 = getMarkedSides(golem, (TileEntity)inventory, color).iterator();

         while(i$1.hasNext()) {
            Integer side = (Integer)i$1.next();
            ItemStack result = InventoryUtils.placeItemStackIntoInventory(golem.getCarried(), inventory, side.intValue(), false);
            if(!ItemStack.areItemStacksEqual(result, golem.itemCarried)) {
               results.add(inventory);
               break;
            }

            if(InventoryUtils.getDoubleChest((TileEntity)inventory) != null) {
               result = InventoryUtils.placeItemStackIntoInventory(golem.getCarried(), InventoryUtils.getDoubleChest((TileEntity)inventory), side.intValue(), false);
               if(!ItemStack.areItemStacksEqual(result, golem.itemCarried)) {
                  results.add(InventoryUtils.getDoubleChest((TileEntity)inventory));
               }
            }
         }
      }

      return results;
   }

   public static ArrayList<IInventory> getContainersWithRoom(World world, EntityGolemBase golem, byte color, ItemStack itemToMatch) {
      ArrayList results = new ArrayList();
      Iterator i$ = getMarkedContainers(world, golem).iterator();

      while(i$.hasNext()) {
         IInventory inventory = (IInventory)i$.next();
         boolean hasRoom = false;
         Iterator i$1 = getMarkedSides(golem, (TileEntity)inventory, color).iterator();

         while(i$1.hasNext()) {
            Integer side = (Integer)i$1.next();
            ItemStack result = InventoryUtils.placeItemStackIntoInventory(itemToMatch, inventory, side.intValue(), false);
            if(!ItemStack.areItemStacksEqual(result, itemToMatch)) {
               results.add(inventory);
               break;
            }

            if(InventoryUtils.getDoubleChest((TileEntity)inventory) != null) {
               result = InventoryUtils.placeItemStackIntoInventory(itemToMatch, InventoryUtils.getDoubleChest((TileEntity)inventory), side.intValue(), false);
               if(!ItemStack.areItemStacksEqual(result, itemToMatch)) {
                  results.add(InventoryUtils.getDoubleChest((TileEntity)inventory));
               }
            }
         }
      }

      return results;
   }

   public static List<Integer> getMarkedSides(EntityGolemBase golem, TileEntity tile, byte color) {
      return getMarkedSides(golem, tile.xCoord, tile.yCoord, tile.zCoord, tile.getWorldObj().provider.dimensionId, color);
   }

   public static List<Integer> getMarkedSides(EntityGolemBase golem, int x, int y, int z, int dim, byte color) {
      ArrayList out = new ArrayList();
      ArrayList gm = golem.getMarkers();
      if(gm != null && gm.size() != 0) {
         for(int a = 0; a < 6; ++a) {
            Marker marker = new Marker(x, y, z, dim, (byte)a, color);
            if(contained(gm, marker)) {
               out.add(Integer.valueOf(a));
            }
         }

         return out;
      } else {
         return out;
      }
   }

   public static boolean contained(ArrayList<Marker> l, Marker m) {
      Iterator i$ = l.iterator();

      Marker mark;
      do {
         if(!i$.hasNext()) {
            return false;
         }

         mark = (Marker)i$.next();
      } while(!m.equalsFuzzy(mark));

      return true;
   }

   public static ArrayList<IInventory> getContainersWithGoods(World world, EntityGolemBase golem, ItemStack goods, byte color) {
      ArrayList results = new ArrayList();
      Iterator i$ = getMarkedContainers(world, golem).iterator();

      while(i$.hasNext()) {
         IInventory inventory = (IInventory)i$.next();

         try {
            Iterator e = getMarkedSides(golem, (TileEntity)inventory, color).iterator();

            while(e.hasNext()) {
               Integer side = (Integer)e.next();
               if(InventoryUtils.extractStack(inventory, goods, side.intValue(), golem.checkOreDict(), golem.ignoreDamage(), golem.ignoreNBT(), false) != null) {
                  results.add(inventory);
                  break;
               }

               if(InventoryUtils.getDoubleChest((TileEntity)inventory) != null && InventoryUtils.extractStack(InventoryUtils.getDoubleChest((TileEntity)inventory), goods, side.intValue(), golem.checkOreDict(), golem.ignoreDamage(), golem.ignoreNBT(), false) != null) {
                  results.add(InventoryUtils.getDoubleChest((TileEntity)inventory));
                  break;
               }
            }
         } catch (Exception var9) {
            ;
         }
      }

      return results;
   }

   public static ArrayList<ItemStack> getMissingItems(EntityGolemBase golem) {
      ForgeDirection facing = ForgeDirection.getOrientation(golem.homeFacing);
      ChunkCoordinates home = golem.getHomePosition();
      int cX = home.posX - facing.offsetX;
      int cY = home.posY - facing.offsetY;
      int cZ = home.posZ - facing.offsetZ;
      int slotCount = golem.inventory.slotCount;
      ItemStack toCheck;
      if(golem.getToggles()[0]) {
         ArrayList var17 = new ArrayList();

         for(int var18 = 0; var18 < slotCount; ++var18) {
            ItemStack var19 = golem.inventory.inventory[var18];
            if(var19 != null) {
               toCheck = var19.copy();
               var17.add(toCheck);
            }
         }

         return var17;
      } else {
         Object tile = golem.worldObj.getTileEntity(cX, cY, cZ);
         if(tile == null) {
            return null;
         } else {
            ArrayList qr = new ArrayList();

            label103:
            for(int q = 0; q < slotCount; ++q) {
               toCheck = golem.inventory.inventory[q];
               if(toCheck != null) {
                  int foundAmount = 0;
                  boolean repeat = true;
                  boolean didRepeat = false;

                  while(true) {
                     if(repeat) {
                        label119: {
                           if(didRepeat) {
                              repeat = false;
                           }

                           if(tile instanceof ISidedInventory && facing.ordinal() > -1) {
                              ISidedInventory var21 = (ISidedInventory)tile;
                              int[] var22 = var21.getAccessibleSlotsFromSide(facing.ordinal());

                              for(int j = 0; j < var22.length; ++j) {
                                 if(InventoryUtils.areItemStacksEqual(((ISidedInventory)tile).getStackInSlot(var22[j]), toCheck, golem.checkOreDict(), golem.ignoreDamage(), golem.ignoreNBT())) {
                                    foundAmount += ((ISidedInventory)tile).getStackInSlot(var22[j]).stackSize;
                                    if(foundAmount >= golem.inventory.getAmountNeededSmart(((ISidedInventory)tile).getStackInSlot(var22[j]), golem.getUpgradeAmount(5) > 0)) {
                                       continue label103;
                                    }
                                 }
                              }
                           } else {
                              if(!(tile instanceof IInventory)) {
                                 break label119;
                              }

                              int ret = ((IInventory)tile).getSizeInventory();

                              for(int l = 0; l < ret; ++l) {
                                 if(InventoryUtils.areItemStacksEqual(((IInventory)tile).getStackInSlot(l), toCheck, golem.checkOreDict(), golem.ignoreDamage(), golem.ignoreNBT())) {
                                    foundAmount += ((IInventory)tile).getStackInSlot(l).stackSize;
                                    if(foundAmount >= golem.inventory.getAmountNeededSmart(((IInventory)tile).getStackInSlot(l), golem.getUpgradeAmount(5) > 0)) {
                                       continue label103;
                                    }
                                 }
                              }
                           }

                           if(!didRepeat && InventoryUtils.getDoubleChest((TileEntity)tile) != null) {
                              tile = InventoryUtils.getDoubleChest((TileEntity)tile);
                              didRepeat = true;
                              continue;
                           }

                           repeat = false;
                           continue;
                        }
                     }

                     ItemStack var20 = toCheck.copy();
                     var20.stackSize -= foundAmount;
                     qr.add(var20);
                     break;
                  }
               }
            }

            return qr;
         }
      }
   }

   public static ChunkCoordinates findJarWithRoom(EntityGolemBase golem) {
      ChunkCoordinates dest = null;
      World world = golem.worldObj;
      float dmod = golem.getRange();
      dmod *= dmod;
      ArrayList jars = new ArrayList();
      ArrayList others = new ArrayList();
      Iterator dist = golem.getMarkers().iterator();

      while(dist.hasNext()) {
         Marker jar = (Marker)dist.next();
         TileEntity i$ = world.getTileEntity(jar.x, jar.y, jar.z);
         if(jar.dim == world.provider.dimensionId && i$ != null && i$ instanceof TileJarFillable) {
            if(i$.getDistanceFrom((double)golem.getHomePosition().posX, (double)golem.getHomePosition().posY, (double)golem.getHomePosition().posZ) <= (double)dmod) {
               jars.add((TileJarFillable)i$);
            }
         } else if(jar.dim == world.provider.dimensionId && i$ != null && i$ instanceof TileEssentiaReservoir) {
            TileEssentiaReservoir jar4 = (TileEssentiaReservoir)i$;
            if(jar4.getSuctionAmount(jar4.facing) > 0 && (jar4.getSuctionType(jar4.facing) == null || jar4.getSuctionType(jar4.facing) == golem.essentia) && i$.getDistanceFrom((double)golem.getHomePosition().posX, (double)golem.getHomePosition().posY, (double)golem.getHomePosition().posZ) <= (double)dmod) {
               others.add(i$);
            }
         } else if(jar.dim == world.provider.dimensionId && i$ != null && i$ instanceof IEssentiaTransport) {
            IEssentiaTransport jar1 = (IEssentiaTransport)i$;
            if(golem.essentia != null && golem.essentiaAmount > 0 && jar1.canInputFrom(ForgeDirection.getOrientation(jar.side)) && jar1.getSuctionAmount(ForgeDirection.getOrientation(jar.side)) > 0 && (jar1.getSuctionType(ForgeDirection.getOrientation(jar.side)) == null || jar1.getSuctionType(ForgeDirection.getOrientation(jar.side)) == golem.essentia) && i$.getDistanceFrom((double)golem.getHomePosition().posX, (double)golem.getHomePosition().posY, (double)golem.getHomePosition().posZ) <= (double)dmod) {
               others.add(i$);
            }
         }
      }

      TileEntity jar2;
      if(jars.size() > 0) {
         jarlist.clear();
         dist = jars.iterator();

         while(dist.hasNext()) {
            jar2 = (TileEntity)dist.next();
            jarlist.put(jar2.xCoord + ":" + jar2.yCoord + ":" + jar2.zCoord, (TileJarFillable)jar2);
            getConnectedJars((TileJarFillable)jar2);
         }
      } else if(others.size() == 0) {
         return null;
      }

      jars = new ArrayList();
      dist = others.iterator();

      while(dist.hasNext()) {
         jar2 = (TileEntity)dist.next();
         jars.add(jar2);
      }

      dist = jarlist.values().iterator();

      TileJarFillable jar3;
      while(dist.hasNext()) {
         jar3 = (TileJarFillable)dist.next();
         if(jar3.aspect != null && jar3.amount > 0 && jar3.amount < jar3.maxAmount && jar3.aspectFilter != null && golem.essentia != null && golem.essentiaAmount > 0 && jar3.aspect.equals(golem.essentia) && jar3.doesContainerAccept(golem.essentia)) {
            jars.add(jar3);
         }
      }

      if(jars.size() == 0) {
         dist = jarlist.values().iterator();

         while(dist.hasNext()) {
            jar3 = (TileJarFillable)dist.next();
            if((jar3.aspect == null || jar3.amount == 0) && jar3.aspectFilter != null && jar3.doesContainerAccept(golem.essentia)) {
               jars.add(jar3);
            }
         }
      }

      if(jars.size() == 0) {
         dist = jarlist.values().iterator();

         while(dist.hasNext()) {
            jar3 = (TileJarFillable)dist.next();
            if(jar3.aspect != null && jar3.amount >= jar3.maxAmount && jar3 instanceof TileJarFillableVoid && jar3.aspectFilter != null && golem.essentia != null && golem.essentiaAmount > 0 && jar3.aspect.equals(golem.essentia) && jar3.doesContainerAccept(golem.essentia)) {
               jars.add(jar3);
            }
         }
      }

      if(jars.size() == 0) {
         dist = jarlist.values().iterator();

         while(dist.hasNext()) {
            jar3 = (TileJarFillable)dist.next();
            if(jar3.aspect != null && jar3.amount > 0 && jar3.amount < jar3.maxAmount && jar3.aspectFilter == null && golem.essentia != null && golem.essentiaAmount > 0 && jar3.aspect.equals(golem.essentia) && jar3.doesContainerAccept(golem.essentia)) {
               jars.add(jar3);
            }
         }
      }

      if(jars.size() == 0) {
         dist = jarlist.values().iterator();

         while(dist.hasNext()) {
            jar3 = (TileJarFillable)dist.next();
            if((jar3.aspect == null || jar3.amount == 0) && jar3.aspectFilter == null && !(jar3 instanceof TileJarFillableVoid) && jar3.doesContainerAccept(golem.essentia)) {
               jars.add(jar3);
            }
         }
      }

      if(jars.size() == 0) {
         dist = jarlist.values().iterator();

         while(dist.hasNext()) {
            jar3 = (TileJarFillable)dist.next();
            if(jar3.aspect != null && jar3 instanceof TileJarFillableVoid && jar3.aspectFilter == null && golem.essentia != null && golem.essentiaAmount > 0 && jar3.aspect.equals(golem.essentia) && jar3.doesContainerAccept(golem.essentia)) {
               jars.add(jar3);
            }
         }
      }

      if(jars.size() == 0) {
         dist = jarlist.values().iterator();

         while(dist.hasNext()) {
            jar3 = (TileJarFillable)dist.next();
            if((jar3.aspect == null || jar3.amount == 0) && jar3.aspectFilter == null && jar3 instanceof TileJarFillableVoid && jar3.doesContainerAccept(golem.essentia)) {
               jars.add(jar3);
            }
         }
      }

      double dist1 = Double.MAX_VALUE;
      Iterator i$1 = jars.iterator();

      while(i$1.hasNext()) {
         TileEntity jar5 = (TileEntity)i$1.next();
         double d = jar5.getDistanceFrom((double)golem.getHomePosition().posX, (double)golem.getHomePosition().posY, (double)golem.getHomePosition().posZ);
         if(jar5 instanceof TileJarFillableVoid) {
            d += (double)dmod;
         }

         if(d < dist1) {
            dist1 = d;
            dest = new ChunkCoordinates(jar5.xCoord, jar5.yCoord, jar5.zCoord);
         }
      }

      jarlist.clear();
      return dest;
   }

   private static void getConnectedJars(TileJarFillable jar) {
      World world = jar.getWorldObj();

      for(int dir = 0; dir < 6; ++dir) {
         ForgeDirection fd = ForgeDirection.getOrientation(dir);
         int xx = jar.xCoord + fd.offsetX;
         int yy = jar.yCoord + fd.offsetY;
         int zz = jar.zCoord + fd.offsetZ;
         if(!jarlist.containsKey(xx + ":" + yy + ":" + zz)) {
            TileEntity te = world.getTileEntity(xx, yy, zz);
            if(te != null && te instanceof TileJarFillable) {
               jarlist.put(te.xCoord + ":" + te.yCoord + ":" + te.zCoord, (TileJarFillable)te);
               getConnectedJars((TileJarFillable)te);
            }
         }
      }

   }

   public static ArrayList<Integer> getReggedLiquids() {
      if(reggedLiquids == null) {
         reggedLiquids = new ArrayList();
         Iterator i$ = FluidRegistry.getRegisteredFluidIDs().values().iterator();

         while(i$.hasNext()) {
            Integer f = (Integer)i$.next();
            reggedLiquids.add(f);
         }
      }

      return reggedLiquids;
   }

   public static ArrayList<FluidStack> getMissingLiquids(EntityGolemBase golem) {
      ArrayList out = new ArrayList();
      ForgeDirection facing = ForgeDirection.getOrientation(golem.homeFacing);
      ChunkCoordinates home = golem.getHomePosition();
      int cX = home.posX - facing.offsetX;
      int cY = home.posY - facing.offsetY;
      int cZ = home.posZ - facing.offsetZ;
      TileEntity tile = golem.worldObj.getTileEntity(cX, cY, cZ);
      if(tile != null && tile instanceof IFluidHandler) {
         IFluidHandler fluidhandler = (IFluidHandler)tile;
         Iterator i$ = getReggedLiquids().iterator();

         while(i$.hasNext()) {
            Integer id = (Integer)i$.next();
            if((golem.fluidCarried == null || golem.fluidCarried.amount <= 0 || golem.fluidCarried.fluidID == id.intValue()) && fluidhandler.canFill(facing, FluidRegistry.getFluid(id.intValue()))) {
               FluidStack fs = new FluidStack(FluidRegistry.getFluid(id.intValue()), Integer.MAX_VALUE);
               if(golem.inventory.hasSomething()) {
                  FluidStack fis = null;
                  boolean found = false;

                  for(int a = 0; a < golem.inventory.slotCount; ++a) {
                     fis = FluidContainerRegistry.getFluidForFilledItem(golem.inventory.getStackInSlot(a));
                     if(fis != null && fis.isFluidEqual(fs)) {
                        found = true;
                        break;
                     }
                  }

                  if(!found) {
                     continue;
                  }
               }

               out.add(new FluidStack(id.intValue(), Integer.MAX_VALUE));
            }
         }
      }

      return out;
   }

   public static Vec3 findPossibleLiquid(FluidStack ls, EntityGolemBase golem) {
      ForgeDirection facing = ForgeDirection.getOrientation(golem.homeFacing);
      ChunkCoordinates home = golem.getHomePosition();
      int var10000 = home.posX - facing.offsetX;
      var10000 = home.posY - facing.offsetY;
      var10000 = home.posZ - facing.offsetZ;
      float dmod = golem.getRange();
      ChunkCoordinates v = null;
      ArrayList fluidhandlers = getMarkedFluidHandlers(ls, golem.worldObj, golem);
      double dd = Double.MAX_VALUE;
      double d;
      if(fluidhandlers != null) {
         Iterator inworld = fluidhandlers.iterator();

         while(inworld.hasNext()) {
            IFluidHandler i$ = (IFluidHandler)inworld.next();
            if(i$ != null) {
               TileEntity coord = (TileEntity)i$;
               d = golem.getDistanceSq((double)coord.xCoord + 0.5D, (double)coord.yCoord + 0.5D, (double)coord.zCoord + 0.5D);
               if(d <= (double)(dmod * dmod) && d < dd) {
                  dd = d;
                  v = new ChunkCoordinates(coord.xCoord, coord.yCoord, coord.zCoord);
               }
            }
         }
      }

      if(v == null) {
         ArrayList inworld1 = getMarkedFluidBlocks(ls, golem.worldObj, golem);
         dd = Double.MAX_VALUE;
         if(inworld1 != null) {
            Iterator i$1 = inworld1.iterator();

            while(i$1.hasNext()) {
               ChunkCoordinates coord1 = (ChunkCoordinates)i$1.next();
               if(coord1 != null) {
                  d = golem.getDistanceSq((double)coord1.posX + 0.5D, (double)coord1.posY + 0.5D, (double)coord1.posZ + 0.5D);
                  if(d <= (double)(dmod * dmod) && d < dd) {
                     dd = d;
                     v = new ChunkCoordinates(coord1.posX, coord1.posY, coord1.posZ);
                  }
               }
            }
         }
      }

      return v != null?Vec3.createVectorHelper((double)v.posX, (double)v.posY, (double)v.posZ):null;
   }

   public static ArrayList<Marker> getMarkedFluidHandlersAdjacentToGolem(FluidStack ls, World world, EntityGolemBase golem) {
      ArrayList results = new ArrayList();
      Iterator i$ = golem.getMarkers().iterator();

      while(i$.hasNext()) {
         Marker marker = (Marker)i$.next();
         TileEntity te = world.getTileEntity(marker.x, marker.y, marker.z);
         if(marker.dim == world.provider.dimensionId && te != null && te instanceof IFluidHandler && golem.getDistanceSq((double)te.xCoord + 0.5D, (double)te.yCoord + 0.5D, (double)te.zCoord + 0.5D) < 4.0D) {
            FluidStack fs = ((IFluidHandler)te).drain(ForgeDirection.getOrientation(marker.side), new FluidStack(ls.getFluid(), 1), false);
            if(fs != null && fs.amount > 0) {
               results.add(marker);
            }
         }
      }

      return results;
   }

   public static ArrayList<IFluidHandler> getMarkedFluidHandlers(FluidStack ls, World world, EntityGolemBase golem) {
      ArrayList results = new ArrayList();
      Iterator i$ = golem.getMarkers().iterator();

      while(i$.hasNext()) {
         Marker marker = (Marker)i$.next();
         TileEntity te = world.getTileEntity(marker.x, marker.y, marker.z);
         if(marker.dim == world.provider.dimensionId && te != null && te instanceof IFluidHandler) {
            FluidStack fs = ((IFluidHandler)te).drain(ForgeDirection.getOrientation(marker.side), new FluidStack(ls.getFluid(), 1), false);
            if(fs != null && fs.amount > 0) {
               results.add((IFluidHandler)te);
            }
         }
      }

      return results;
   }

   public static ArrayList<ChunkCoordinates> getMarkedFluidBlocks(FluidStack ls, World world, EntityGolemBase golem) {
      ArrayList results = new ArrayList();
      Iterator i$ = golem.getMarkers().iterator();

      while(i$.hasNext()) {
         Marker marker = (Marker)i$.next();
         Block bi = world.getBlock(marker.x, marker.y, marker.z);
         if(marker.dim == world.provider.dimensionId && FluidRegistry.getFluid(ls.fluidID).getBlock() == bi) {
            if(bi instanceof BlockFluidBase && ((BlockFluidBase)bi).canDrain(world, marker.x, marker.y, marker.z)) {
               results.add(new ChunkCoordinates(marker.x, marker.y, marker.z));
            } else if(ls.fluidID == FluidRegistry.WATER.getID() || ls.fluidID == FluidRegistry.LAVA.getID()) {
               int wmd = world.getBlockMetadata(marker.x, marker.y, marker.z);
               if((FluidRegistry.lookupFluidForBlock(bi) == FluidRegistry.WATER && ls.fluidID == FluidRegistry.WATER.getID() || FluidRegistry.lookupFluidForBlock(bi) == FluidRegistry.LAVA && ls.fluidID == FluidRegistry.LAVA.getID()) && wmd == 0) {
                  results.add(new ChunkCoordinates(marker.x, marker.y, marker.z));
               }
            }
         }
      }

      return results;
   }

   public static ArrayList<ItemStack> getItemsNeeded(EntityGolemBase golem, boolean fuzzy) {
      ArrayList needed = null;
      switch(golem.getCore()) {
      case 1:
         needed = golem.inventory.getItemsNeeded(golem.getUpgradeAmount(5) > 0);
         if(needed.size() == 0) {
            return null;
         }

         return filterEmptyCore(golem, needed);
      case 8:
         needed = golem.inventory.getItemsNeeded(golem.getUpgradeAmount(5) > 0);
         if(needed.size() == 0) {
            return null;
         }

         return filterUseCore(golem, needed);
      case 10:
         needed = getItemsInHomeContainer(golem);
         return filterSortCore(golem, needed);
      default:
         return needed;
      }
   }

   private static ArrayList<ItemStack> filterEmptyCore(EntityGolemBase golem, ArrayList<ItemStack> in) {
      ArrayList out = new ArrayList();
      Iterator i$ = in.iterator();

      while(i$.hasNext()) {
         ItemStack itemToMatch = (ItemStack)i$.next();
         if(!isOnTimeOut(golem, itemToMatch) && findSomethingEmptyCore(golem, itemToMatch)) {
            out.add(itemToMatch);
         }
      }

      return out;
   }

   private static ArrayList<ItemStack> filterUseCore(EntityGolemBase golem, ArrayList<ItemStack> in) {
      ArrayList out = new ArrayList();
      Iterator i$ = in.iterator();

      while(i$.hasNext()) {
         ItemStack itemToMatch = (ItemStack)i$.next();
         if(!isOnTimeOut(golem, itemToMatch) && findSomethingUseCore(golem, itemToMatch)) {
            out.add(itemToMatch);
         }
      }

      return out;
   }

   private static ArrayList<ItemStack> filterSortCore(EntityGolemBase golem, ArrayList<ItemStack> in) {
      ArrayList out = new ArrayList();
      Iterator i$ = in.iterator();

      while(i$.hasNext()) {
         ItemStack itemToMatch = (ItemStack)i$.next();
         if(!isOnTimeOut(golem, itemToMatch) && findSomethingSortCore(golem, itemToMatch)) {
            out.add(itemToMatch);
         }
      }

      return out;
   }

   public static boolean findSomethingUseCore(EntityGolemBase golem, ItemStack itemToMatch) {
      ArrayList matchingColors = golem.getColorsMatching(itemToMatch);
      Iterator i$ = matchingColors.iterator();

      while(i$.hasNext()) {
         byte col = ((Byte)i$.next()).byteValue();
         ArrayList markers = golem.getMarkers();
         Iterator i$1 = markers.iterator();

         while(i$1.hasNext()) {
            Marker marker = (Marker)i$1.next();
            if((marker.color == col || col == -1) && (!golem.getToggles()[0] || golem.worldObj.isAirBlock(marker.x, marker.y, marker.z)) && (golem.getToggles()[0] || !golem.worldObj.isAirBlock(marker.x, marker.y, marker.z))) {
               ForgeDirection opp = ForgeDirection.getOrientation(marker.side);
               if(golem.worldObj.isAirBlock(marker.x + opp.offsetX, marker.y + opp.offsetY, marker.z + opp.offsetZ)) {
                  return true;
               }
            }
         }
      }

      itemTimeout.add(new GolemHelper.SortingItemTimeout(golem.getEntityId(), itemToMatch.copy(), System.currentTimeMillis() + (long)Config.golemIgnoreDelay));
      return false;
   }

   public static boolean findSomethingEmptyCore(EntityGolemBase golem, ItemStack itemToMatch) {
      ArrayList matchingColors = golem.getColorsMatching(itemToMatch);
      Iterator i$ = matchingColors.iterator();

      while(true) {
         ArrayList markers;
         do {
            byte color;
            if(!i$.hasNext()) {
               i$ = matchingColors.iterator();

               while(i$.hasNext()) {
                  color = ((Byte)i$.next()).byteValue();
                  markers = golem.getMarkers();
                  Iterator i$31 = markers.iterator();

                  while(i$31.hasNext()) {
                     Marker marker11 = (Marker)i$31.next();
                     if((marker11.color == color || color == -1) && (golem.worldObj.getTileEntity(marker11.x, marker11.y, marker11.z) == null || !(golem.worldObj.getTileEntity(marker11.x, marker11.y, marker11.z) instanceof IInventory))) {
                        return true;
                     }
                  }
               }

               itemTimeout.add(new GolemHelper.SortingItemTimeout(golem.getEntityId(), itemToMatch.copy(), System.currentTimeMillis() + (long)Config.golemIgnoreDelay));
               return false;
            }

            color = ((Byte)i$.next()).byteValue();
            markers = getContainersWithRoom(golem.worldObj, golem, color, itemToMatch);
         } while(markers.size() == 0);

         ForgeDirection i$3 = ForgeDirection.getOrientation(golem.homeFacing);
         ChunkCoordinates marker1 = golem.getHomePosition();
         int cX = marker1.posX - i$3.offsetX;
         int cY = marker1.posY - i$3.offsetY;
         int cZ = marker1.posZ - i$3.offsetZ;
         double range = Double.MAX_VALUE;
         float dmod = golem.getRange();
         Iterator i$2 = markers.iterator();

         while(i$2.hasNext()) {
            IInventory te = (IInventory)i$2.next();
            double distance = golem.getDistanceSq((double)((TileEntity)te).xCoord + 0.5D, (double)((TileEntity)te).yCoord + 0.5D, (double)((TileEntity)te).zCoord + 0.5D);
            if(distance < range && distance <= (double)(dmod * dmod) && (((TileEntity)te).xCoord != cX || ((TileEntity)te).yCoord != cY || ((TileEntity)te).zCoord != cZ)) {
               return true;
            }
         }
      }
   }

   public static boolean findSomethingSortCore(EntityGolemBase golem, ItemStack itemToMatch) {
      ArrayList markers = getContainersWithRoom(golem.worldObj, golem, (byte)-1, itemToMatch);
      if(markers.size() != 0) {
         ForgeDirection i$1 = ForgeDirection.getOrientation(golem.homeFacing);
         ChunkCoordinates marker = golem.getHomePosition();
         int cX = marker.posX - i$1.offsetX;
         int cY = marker.posY - i$1.offsetY;
         int cZ = marker.posZ - i$1.offsetZ;
         double range = Double.MAX_VALUE;
         float dmod = golem.getRange();
         Iterator i$2 = markers.iterator();

         while(i$2.hasNext()) {
            IInventory te = (IInventory)i$2.next();
            double distance = golem.getDistanceSq((double)((TileEntity)te).xCoord + 0.5D, (double)((TileEntity)te).yCoord + 0.5D, (double)((TileEntity)te).zCoord + 0.5D);
            if(distance < range && distance <= (double)(dmod * dmod) && (((TileEntity)te).xCoord != cX || ((TileEntity)te).yCoord != cY || ((TileEntity)te).zCoord != cZ)) {
               Iterator i$ = getMarkedSides(golem, (TileEntity)te, (byte)-1).iterator();

               while(i$.hasNext()) {
                  int side = ((Integer)i$.next()).intValue();
                  if(InventoryUtils.inventoryContains(te, itemToMatch, side, golem.checkOreDict(), golem.ignoreDamage(), golem.ignoreNBT())) {
                     return true;
                  }
               }
            }
         }
      }

      itemTimeout.add(new GolemHelper.SortingItemTimeout(golem.getEntityId(), itemToMatch.copy(), System.currentTimeMillis() + (long)Config.golemIgnoreDelay));
      return false;
   }

   public static boolean isOnTimeOut(EntityGolemBase golem, ItemStack stack) {
      GolemHelper.SortingItemTimeout tos = new GolemHelper.SortingItemTimeout(golem.getEntityId(), stack, 0L);
      if(itemTimeout.contains(tos)) {
         int q = itemTimeout.indexOf(tos);
         GolemHelper.SortingItemTimeout tos2 = (GolemHelper.SortingItemTimeout)itemTimeout.get(q);
         if(System.currentTimeMillis() < tos2.time) {
            return true;
         }

         itemTimeout.remove(q);
      }

      return false;
   }

   public static boolean validTargetForItem(EntityGolemBase golem, ItemStack stack) {
      if(isOnTimeOut(golem, stack)) {
         return false;
      } else {
         ForgeDirection facing = ForgeDirection.getOrientation(golem.homeFacing);
         ChunkCoordinates home = golem.getHomePosition();
         int cX = home.posX - facing.offsetX;
         int cY = home.posY - facing.offsetY;
         int cZ = home.posZ - facing.offsetZ;
         switch(golem.getCore()) {
         case 1:
            return findSomethingEmptyCore(golem, stack);
         case 8:
            return findSomethingUseCore(golem, stack);
         case 10:
            return findSomethingSortCore(golem, stack);
         default:
            golem.worldObj.getTileEntity(cX, cY, cZ);
            ArrayList neededList = getItemsNeeded(golem, golem.getUpgradeAmount(5) > 0);
            if(neededList != null && neededList.size() > 0) {
               Iterator i$ = neededList.iterator();

               while(i$.hasNext()) {
                  ItemStack ss = (ItemStack)i$.next();
                  if(InventoryUtils.areItemStacksEqual(ss, golem.itemCarried, golem.checkOreDict(), golem.ignoreDamage(), golem.ignoreNBT())) {
                     return true;
                  }
               }
            }

            itemTimeout.add(new GolemHelper.SortingItemTimeout(golem.getEntityId(), stack.copy(), System.currentTimeMillis() + (long)Config.golemIgnoreDelay));
            return false;
         }
      }
   }

   public static ItemStack getFirstItemUsingTimeout(EntityGolemBase golem, IInventory inventory, int side, boolean doit) {
      ItemStack stack1 = null;
      if(inventory instanceof ISidedInventory && side > -1) {
         ISidedInventory var8 = (ISidedInventory)inventory;
         int[] var9 = var8.getAccessibleSlotsFromSide(side);

         for(int j = 0; j < var9.length; ++j) {
            if(stack1 == null && inventory.getStackInSlot(var9[j]) != null) {
               if(isOnTimeOut(golem, inventory.getStackInSlot(var9[j]))) {
                  continue;
               }

               stack1 = inventory.getStackInSlot(var9[j]).copy();
               stack1.stackSize = golem.getCarrySpace();
            }

            if(stack1 != null) {
               stack1 = InventoryUtils.attemptExtraction(inventory, stack1, var9[j], side, false, false, false, doit);
            }

            if(stack1 != null) {
               break;
            }
         }
      } else {
         int k = inventory.getSizeInventory();

         for(int l = 0; l < k; ++l) {
            if(stack1 == null && inventory.getStackInSlot(l) != null) {
               if(isOnTimeOut(golem, inventory.getStackInSlot(l))) {
                  continue;
               }

               stack1 = inventory.getStackInSlot(l).copy();
               stack1.stackSize = golem.getCarrySpace();
            }

            if(stack1 != null) {
               stack1 = InventoryUtils.attemptExtraction(inventory, stack1, l, side, false, false, false, doit);
            }

            if(stack1 != null) {
               break;
            }
         }
      }

      if(stack1 != null && stack1.stackSize != 0) {
         return stack1.copy();
      } else {
         if(doit) {
            inventory.markDirty();
         }

         return null;
      }
   }

   public static ArrayList<ItemStack> getItemsInHomeContainer(EntityGolemBase golem) {
      ForgeDirection facing = ForgeDirection.getOrientation(golem.homeFacing);
      ChunkCoordinates home = golem.getHomePosition();
      int cX = home.posX - facing.offsetX;
      int cY = home.posY - facing.offsetY;
      int cZ = home.posZ - facing.offsetZ;
      TileEntity tile = golem.worldObj.getTileEntity(cX, cY, cZ);
      if(tile != null && tile instanceof IInventory) {
         Object aint = null;
         ArrayList out = new ArrayList();
         IInventory inv = (IInventory)tile;
         int j;
         int[] var11;
         if(tile instanceof ISidedInventory && facing.ordinal() > -1) {
            var11 = ((ISidedInventory)inv).getAccessibleSlotsFromSide(facing.ordinal());
         } else {
            var11 = new int[inv.getSizeInventory()];

            for(j = 0; j < inv.getSizeInventory(); var11[j] = j++) {
               ;
            }
         }

         if(var11 != null && var11.length > 0) {
            for(j = 0; j < var11.length; ++j) {
               if(inv.getStackInSlot(var11[j]) != null) {
                  out.add(inv.getStackInSlot(var11[j]).copy());
               }
            }
         }

         return out;
      } else {
         return null;
      }
   }

   public static class SortingItemTimeout implements Comparable {
      ItemStack stack = null;
      int golemId = 0;
      long time = 0L;

      public SortingItemTimeout(int golemId, ItemStack stack, long time) {
         this.stack = stack;
         this.golemId = golemId;
         this.time = time;
      }

      public int compareTo(Object arg0) {
         return this.equals(arg0)?0:-1;
      }

      public boolean equals(Object obj) {
         if(obj instanceof GolemHelper.SortingItemTimeout) {
            GolemHelper.SortingItemTimeout t = (GolemHelper.SortingItemTimeout)obj;
            if(this.golemId != t.golemId) {
               return false;
            }

            if(!this.stack.isItemEqual(t.stack)) {
               return false;
            }

            if(!ItemStack.areItemStackTagsEqual(this.stack, t.stack)) {
               return false;
            }
         }

         return true;
      }
   }
}
