package thaumcraft.common.entities;

import net.minecraft.item.ItemStack;
import net.minecraft.world.World;
import thaumcraft.common.entities.EntitySpecialItem;

public class EntityPermanentItem extends EntitySpecialItem {
   public EntityPermanentItem(World par1World) {
      super(par1World);
   }

   public EntityPermanentItem(World par1World, double par2, double par4, double par6, ItemStack par8ItemStack) {
      super(par1World);
      this.setSize(0.25F, 0.25F);
      this.yOffset = this.height / 2.0F;
      this.setPosition(par2, par4, par6);
      this.setEntityItemStack(par8ItemStack);
      this.rotationYaw = (float)(Math.random() * 360.0D);
      this.motionX = (double)((float)(Math.random() * 0.20000000298023224D - 0.10000000149011612D));
      this.motionY = 0.20000000298023224D;
      this.motionZ = (double)((float)(Math.random() * 0.20000000298023224D - 0.10000000149011612D));
   }

   public void onUpdate() {
      super.onUpdate();
      if(this.age + 5 >= this.lifespan) {
         this.age = 0;
      }

   }
}
